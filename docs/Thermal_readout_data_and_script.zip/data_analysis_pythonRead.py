#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Dec 13 19:27:48 2020

@author: crow104

This script exists to 
"""
import numpy as np
from matplotlib import pyplot as plt
import glob
from scipy import optimize as opt
plt.rcParams.update({'font.size': 13})
import scipy.io as io
from tkinter import Tk
import tkinter as tki
from tkinter.filedialog import askopenfilename, asksaveasfilename, asksaveasfile
from scipy.special import factorial
from scipy.optimize import fsolve

#kappa = 2 * np.pi * 0.841 # dissipation rate in MHz
#chi = 2 * np.pi * np.abs(5.6743-5.6861)/2 * 1e3 # dispersive coupling constant in MHz
#omega_c = 2 * np.pi * 5.6861 * 1e3 # cavity frequency with qubit in g in MHz
#omega_c_e =  2 * np.pi * 5.6743 * 1e3
#omega_q = 2 * np.pi * 5.12487 * 1e3 # qubit frequency in MHz
#omega_q_f = 2 * np.pi * (5.12487+4.80788) * 1e3
#kb = 1.3806488e-23
#hbar = 1.054571817e-34
#echarge = 1.60217662 * 1e-19
#Delta = 200 * 1e-6 * echarge # in unit of J
#
#delta = omega_c-omega_q
#g = np.sqrt(delta*chi)
#ncrit = delta**2/(4*g**2) # ncrit about 24


kappa = 2 * np.pi * 0.53 # dissipation rate in MHz
chi = 2 * np.pi * np.abs(5.606-5.6185)/2 * 1e3 # dispersive coupling constant in MHz
omega_c = 2 * np.pi * 5.6185 * 1e3 # cavity frequency with qubit in g in MHz
omega_c_e =  2 * np.pi * 5.606 * 1e3
omega_q = 2 * np.pi * 5.122 * 1e3 # qubit frequency in MHz
#omega_q_f = 2 * np.pi * (5.12487+4.80788) * 1e3
kb = 1.3806488e-23
hbar = 1.054571817e-34
echarge = 1.60217662 * 1e-19
Delta = 200 * 1e-6 * echarge # in unit of J

delta = omega_c-omega_q
g = np.sqrt(delta*chi)
ncrit = delta**2/(4*g**2) # ncrit about 24


def calculate_work_cost():
    p = np.linspace(0.001,0.999,100)
    n_p = 10
    T = 0.05
    
    E_c = 1e6 * hbar * omega_c * (1-p) * n_p
#    E_c_e = kb * T * p * 10
    
    
    E_t = 1e6 * hbar * omega_c * (1-p) * n_p/2 + 1e6 * hbar * omega_c_e * p * n_p/2
    E_s = 1e6 * hbar * omega_c_e * p
    
    E_q = 1e6 * hbar * omega_q * p
    
    
   
    E_m = - kb * T * (p*np.log(p)+(1-p)*np.log(1-p))
    
    beta = 1/(kb * T)

    plt.rcParams.update({'font.size': 14})
    plt.figure(figsize=(5,3.5))
    
    plt.plot(p, beta * E_c, 'b')
#    plt.plot(p, beta * E_c_e, 'b--')
    plt.plot(p, beta * E_t, 'r')
    plt.plot(p, beta * E_s, 'y')
    plt.plot(p, beta * E_m, 'm--')
    
    plt.plot(p, beta * E_q, 'k-.')
    plt.xlabel('$p$')
    plt.yscale('log')
    plt.ylabel('$\\langle W \\rangle / k_B T_D$')
    
    plt.xlim([0,1])
    
#    plt.legend(['coherent','thermal','single-photon','lower bound','qubit'],
#               loc='lower left',bbox_to_anchor=(1,0))
    
    plt.legend(['coherent','thermal','single-photon','lower bound','qubit'],
               bbox_to_anchor=(0.05, 0.01, 0.9, .05), loc='lower left',
               ncol=2, mode="expand", borderaxespad=0, frameon=False)
    
    plt.savefig('03_work_cost.pdf',dpi=300,bbox_inches='tight')
    

  
    

def calculate_photon(t2):
    n_photon = 1/t2 * (kappa**2 + 4 * chi**2)/(4 * kappa*chi**2)
    print('photon number = ' + str(n_photon))

def pop_correction(pe,fid_g,fid_e):
    
    correctMatrix = np.array([[fid_g,1-fid_e],[1-fid_g,fid_e]])
    
    dim = np.size(np.shape(pe))
    
    if dim == 1:
        pe_c = pe*np.array([0])
        print(np.shape(pe))
        print(np.shape(pe_c))
        for k in np.arange(np.size(pe)):
            [_,pe_c[k]] = np.matmul(np.linalg.inv(correctMatrix),[[1-pe[k]],[pe[k]]])
            
    if dim == 2:
        pe_c = pe**np.array([0])
        for k in np.arange(np.shape(pe)[0]):
            for m in np.arange(np.shape(pe)[1]):
                [_,pe_c[k,m]] = np.matmul(np.linalg.inv(correctMatrix),[[1-pe[k,m]],[pe[k,m]]])
            
    return pe_c

def rotate_iq(angle_deg=0., rec=[None, None]):
    rec_rotated = [None, None]
    
    ch_cmplx = rec[0] + 1j*rec[1]
    ch_cmplx_rot = abs(ch_cmplx)*np.exp(1j*np.angle(ch_cmplx))*np.exp(1j*np.pi*angle_deg/180)
    rec_rotated[0] = np.real(ch_cmplx_rot)
    rec_rotated[1] = np.imag(ch_cmplx_rot)
    rec_rotated = np.array(rec_rotated)
    return rec_rotated

def plot_single_stateTrans():
    fname = getsinglefile('035*')
    data = np.loadtxt(fname)
    xdata = data[:,0]
    fdata = data[:,1]
    
    fdata = pop_correction(fdata,0.93,0.94)
    
    plt.figure()
    plt.plot(xdata, fdata, 'k.-')
    plt.xlabel('Time ($\mu$s)')
    plt.ylabel('$P_e$')
    
    fitfunc = ExpDecay
    startpoint = [np.ptp(fdata), np.max(xdata)/3, np.min(fdata)]
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    perr = np.sqrt(np.diag(pcov))
    
    xd = np.linspace(0, np.max(xdata), 100)
    plt.plot(xd, fitfunc(xd, *para), 'r-')
    print(para)
    print(perr)
    
def plot_single_twotoneSpectrum():
    fname = getsinglefile('092*')
    data = np.loadtxt(fname)
    xdata = np.linspace(5,5.2,201)
    fdata = data[:]
    
    plt.figure()
    plt.plot(xdata, fdata, 'k.-')
    plt.xlabel('Frequency (GHz)')
    plt.ylabel('S21 (dB)')
    plt.xlim([5,5.15])
#    plt.ylim([-110,-75])
    plt.plot([5.12487, 5.12487], plt.gca().get_ylim(),'--')
    
def plot_multiple_twotoneSpectrum():
    fileno = [36,37,38,39,40,41]
    
    
    plt.figure()
    for k in np.arange(np.size(fileno)):
        fname = getsinglefile('{no:03d}*'.format(no=fileno[k]))
        data = np.loadtxt(fname)
        xdata = np.linspace(5,5.2,201)
        fdata = data[:]
        
        
        plt.plot(xdata, fdata)
    plt.xlabel('Frequency (GHz)')
    plt.ylabel('S21 (dB)')    
    plt.xlim([5,5.15])


def plot_f0toe1_transition(fileno=66, ifplot=0):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = data = io.loadmat(fname)
    prob_g = data['prob_g']
    prob_g = prob_g.flatten()
    prob_e = data['prob_e']
    prob_e = prob_e.flatten()
    prob_f = data['prob_f']
    prob_f = prob_f.flatten()
    time = data['sweepparam']
    time = time.flatten()
    
    
    
    plt.figure()
    plt.plot(time, prob_g, 'r')
    plt.plot(time, prob_e, 'b')
    plt.plot(time, prob_f, 'g')
#    plt.plot(time, prob_g + prob_e + prob_f, 'k')
    
    plt.legend(['$P_g$','$P_e$','$P_f$'], loc='lower left',bbox_to_anchor=(1,0))
    plt.xlabel('Time (ns)')
    plt.ylabel('Population')
    
def plot_Gaussian_squarePulse():
    amp = 2
    
    sweep_time = 500
    
    sigma = 200
    file_length = 3000
    arbsequence_ch3 = np.zeros(file_length)
    width = 500
    
    tdata = np.arange(sweep_time+width*2)
    I_t = np.zeros(sweep_time+width*2)
    I_t[0:width] = amp * np.exp(-(tdata[0:width] - width)**2/(2*sigma**2))
    duration = sweep_time
    I_t[width:(width+duration)] = amp * (np.zeros(duration)+1)
    I_t[(width+duration):(width*2+duration)] = amp * np.exp(
            -(tdata[width+duration:width*2+duration] - (width+duration))**2/(2*sigma**2))
    starttime = 500
    arbsequence_ch3[starttime:starttime+sweep_time+width*2] = I_t[:]
    time = np.arange(file_length)
    
    plt.figure()
    plt.plot(time, arbsequence_ch3, 'k')
    plt.xlabel('Time (ns)')
    plt.ylabel('Amplitude')
   
    
    
def plot_f0toe1_transition_offsetscan(fileno=319):
    fname = getsinglefile('{}*'.format(fileno))
    data = data = io.loadmat(fname)
    totprob = data['totprob']
    offset = data['offset']
    offset = offset.flatten()
    time = data['time']
    time = time.flatten()
    
    plt.figure()
    x = time
    y = offset
    print([np.size(time), np.size(offset)])
    xd = np.append(x-(x[1]-x[0])/2,x[-1]+(x[1]-x[0])/2)
    yd = np.append(y-(y[1]-y[0])/2,y[-1]+(y[1]-y[0])/2)
    X, Y = np.meshgrid(xd, yd)

    plt.pcolormesh(X, Y, totprob)
    plt.ylabel('Offset (GHz)')
    plt.xlabel('Time ($\mu$s)')
    plt.colorbar()
    
    
#    index = np.whe1 offset)
    
    
def plot_powerSweep_stateTrans(ifplot=0):
    fname = getsinglefile('025*')
    data = data = io.loadmat(fname)
    prob = data['prob']
    prob = pop_correction(prob,0.93,0.94)
    power = data['power']
    sweepparam = data['sweepparam']
    
    
    
    tau = np.zeros(np.size(power))
    bg = np.zeros(np.size(power))
    tauerr = np.zeros(np.size(power))
    bgerr = np.zeros(np.size(power))
    for k in np.arange(np.size(power)):
        xdata = sweepparam[k,:]
        fdata = prob[k,:]
        
        
        fitfunc = ExpDecay
        startpoint = [-np.ptp(fdata), np.max(xdata)/3, np.min(fdata)]
        para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
        perr = np.sqrt(np.diag(pcov))
        
        if ifplot:
            plt.figure()
            plt.plot(xdata, fdata, 'k.-')
            plt.xlabel('Time ($\mu$s)')
            plt.ylabel('$P_e$')
            
            xd = np.linspace(0, np.max(xdata), 100)
            plt.plot(xd, fitfunc(xd, *para), 'r-')
            plt.title('power {} dB'.format(power[0,k]))
            plt.show()
        
        tau[k] = para[1]
        tauerr[k] = perr[1]
        bg[k] = para[2]
        bgerr[k] = perr[2]
        
    plt.figure()
    powerconvert = 10**(power[0,:]/10)
    powerconvert = power[0,:]
    
    plt.plot(powerconvert[2:], tau[2:], 'ko-')
    
    
    plt.xlabel('Relative power (dB)')
    plt.ylabel('Equilibrium time ($\mu$s)')
    
    plt.figure()
    plt.plot(powerconvert[2:], bg[2:], 'ko-')
    
#    plt.gca().set_ylim(bottom=0)
#    plt.gca().set_xlim(left=0)
    
    plt.xlabel('Relative power  ')
    plt.ylabel('Equilibrium $P_e$')
    
def plot_powerSweep_stateTrans_data32(ifplot=0):
    fname = getsinglefile('034*')
    data = io.loadmat(fname)
    prob = data['prob']
    prob = pop_correction(prob,0.93,0.94)
    power = data['power']
    sweepparam = data['sweepparam']
    
    
    
    tau = np.zeros(np.size(power))
    bg = np.zeros(np.size(power))
    tauerr = np.zeros(np.size(power))
    bgerr = np.zeros(np.size(power))
    for k in np.arange(np.size(power)):
        xdata = sweepparam[k,:]
        fdata = prob[k,:]
        
        
        fitfunc = ExpDecay
        startpoint = [-np.ptp(fdata), np.max(xdata)/3, np.min(fdata)]
        para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
        perr = np.sqrt(np.diag(pcov))
        
        if ifplot:
            plt.figure()
            plt.plot(xdata, fdata, 'k.-')
            plt.xlabel('Time ($\mu$s)')
            plt.ylabel('$P_e$')
            
            xd = np.linspace(0, np.max(xdata), 100)
            plt.plot(xd, fitfunc(xd, *para), 'r-')
            plt.title('power {} dB'.format(power[0,k]))
            plt.show()
        
        tau[k] = para[1]
        tauerr[k] = perr[1]
        bg[k] = para[2]
        bgerr[k] = perr[2]
        
    plt.figure()
    powerconvert = 10**(power[0,:]/10)
    powerconvert = power[0,:]
    
    plt.plot(powerconvert[:], tau[:], 'ko-')
    
    
    plt.xlabel('Relative power (dB)')
    plt.ylabel('Equilibrium time ($\mu$s)')
    
    plt.figure()
    plt.plot(powerconvert[:], bg[:], 'ko-')
    
#    plt.gca().set_ylim(bottom=0)
#    plt.gca().set_xlim(left=0)
    
    plt.xlabel('Relative power  ')
    plt.ylabel('Equilibrium $P_e$')

def plot_powerSweep_ramsey(ifplot=0):
    fname = getsinglefile('027*')
    data = np.loadtxt(fname)
    xdata = data[:,0]
    fdata = data[:,1]
    
    fig = plt.figure()
    plt.plot(xdata, fdata, 'o')
    fitfunc = ExpDecay
    startpoint = [np.ptp(fdata), np.max(xdata)/3, np.min(fdata)]
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(0,np.max(xdata),200)
    plt.plot(xd, fitfunc(xd, *para), 'r-')
    plt.show()
    T20 = para[1]
    
    fname = getsinglefile('026*')
    data = io.loadmat(fname)
    prob = data['prob']
    prob = pop_correction(prob,0.93,0.94)
    power = data['power']
    sweepparam = data['sweepparam']
    
    prob = np.reshape(prob,[14,101])
    sweepparam = np.reshape(sweepparam,[14,101])
    
    tau = np.zeros(np.size(power))
    bg = np.zeros(np.size(power))
    tauerr = np.zeros(np.size(power))
    bgerr = np.zeros(np.size(power))
    
    for k in np.arange(np.size(power)):
        xdata = sweepparam[k,:]
        fdata = prob[k,:]
        
        
        fitfunc = ExpDecay
        startpoint = [np.ptp(fdata), np.max(xdata)/3, np.min(fdata)]
        para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
        perr = np.sqrt(np.diag(pcov))
        
        if ifplot:
            plt.figure()
            plt.plot(xdata, fdata, 'k.-')
            plt.xlabel('Time ($\mu$s)')
            plt.ylabel('$P_e$')
            
            xd = np.linspace(0, np.max(xdata), 100)
            plt.plot(xd, fitfunc(xd, *para), 'r-')
            plt.title('power {} dB'.format(power[0,k]))
            plt.show()
        
        tau[k] = para[1]
        tauerr[k] = perr[1]
        bg[k] = para[2]
        bgerr[k] = perr[2]
        
    plt.figure()
    powerconvert = 10**(power[0,:]/10)
    powerconvert = power[0,:]
    
    plt.plot(powerconvert[0:-2], np.abs(tau[0:-2]), 'ko-')
    plt.errorbar(powerconvert[0:-2], np.abs(tau[0:-2]), np.abs(tauerr[0:-2]), fmt='ko-')
    
    plt.xlabel('Relative power (dB)')
    plt.ylabel('Equilibrium time ($\mu$s)')
    
    plt.yscale('log')
    
    plt.show()
    
    T2photon = 1/(1/tau[0:-2]-1/T20)
    n_photon = 1/T2photon * (kappa**2 + 4 * chi**2)/(4 * kappa*chi**2)
    
    plt.figure()
    plt.plot(powerconvert[0:-2], n_photon, 'ko-')
    
    xdata = powerconvert[0:-2]
    fdata = n_photon
    
    fitfunc = photonnum
    startpoint = [1]
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(-30,0,200)
    plt.plot(xd, fitfunc(xd, *para), 'r-')
    plt.yscale('log')
    
    plt.xlabel('Relative power (dB)')
    plt.ylabel('photon number')
    
    plt.show()


def plot_powerSweep_ramsey_data33(ifplot=0):
    fname = getsinglefile('027*')
    data = np.loadtxt(fname)
    xdata = data[:,0]
    fdata = data[:,1]
    
    fig = plt.figure()
    plt.plot(xdata, fdata, 'o')
    fitfunc = ExpDecay
    startpoint = [np.ptp(fdata), np.max(xdata)/3, np.min(fdata)]
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(0,np.max(xdata),200)
    plt.plot(xd, fitfunc(xd, *para), 'r-')
    plt.show()
    T20 = para[1]
    
    fname = getsinglefile('033*')
    data = io.loadmat(fname)
    prob = data['prob']
    prob = pop_correction(prob,0.93,0.94)
    power = data['power']
    sweepparam = data['sweepparam']
    
    
    tau = np.zeros(np.size(power))
    bg = np.zeros(np.size(power))
    tauerr = np.zeros(np.size(power))
    bgerr = np.zeros(np.size(power))
    
    for k in np.arange(np.size(power)):
        xdata = sweepparam[k,:]
        fdata = prob[k,:]
        
        
        fitfunc = ExpDecay
        startpoint = [np.ptp(fdata), np.max(xdata)/3, np.min(fdata)]
        para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
        perr = np.sqrt(np.diag(pcov))
        
        if ifplot:
            plt.figure()
            plt.plot(xdata, fdata, 'k.-')
            plt.xlabel('Time ($\mu$s)')
            plt.ylabel('$P_e$')
            
            xd = np.linspace(0, np.max(xdata), 100)
            plt.plot(xd, fitfunc(xd, *para), 'r-')
            plt.title('power {} dB'.format(power[0,k]))
            plt.show()
        
        tau[k] = para[1]
        tauerr[k] = perr[1]
        bg[k] = para[2]
        bgerr[k] = perr[2]
        
    plt.figure()
    powerconvert = 10**(power[0,:]/10)
    powerconvert = power[0,:]
    
    plt.plot(powerconvert[0:-2], np.abs(tau[0:-2]), 'ko-')
    plt.errorbar(powerconvert[0:-2], np.abs(tau[0:-2]), np.abs(tauerr[0:-2]), fmt='ko-')
    
    plt.xlabel('Relative power (dB)')
    plt.ylabel('Equilibrium time ($\mu$s)')
    
    plt.yscale('log')
    
    plt.show()
    
    T2photon = 1/(1/tau[0:-2]-1/T20)
    n_photon = 1/T2photon * (kappa**2 + 4 * chi**2)/(4 * kappa*chi**2)
    
    plt.figure()
    plt.plot(powerconvert[0:-2], n_photon, 'ko-')
    
    xdata = powerconvert[0:-2]
    fdata = n_photon
    
    fitfunc = photonnum
    startpoint = [1]
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(-40,0,200)
    plt.plot(xd, fitfunc(xd, *para), 'r-')
    plt.yscale('log')
    
    plt.xlabel('Relative power (dB)')
    plt.ylabel('photon number')
    
    plt.show()
        





def plot_powersweep_SNR(fileno=64, ifplot=0, ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    totxdata = data['totxdata']
    tothistg = data['tothistg']
    tothiste = data['tothiste']
    power = data['power']
    
    ave =  data['ave']
    ave = ave[0,0]
    power =np.reshape(power,[np.size(power)])
    
    
#    print(10*np.log10(power))
    
    SNR = np.zeros([ave,np.size(totxdata,1)])
    
    
    for m in np.arange(ave):
        for k in np.arange(np.size(totxdata,1)):
            
            xdata = totxdata[m,k,:]
            ydata_g = tothistg[m,k,:]
            ydata_e = tothiste[m,k,:]
            
            
            
            startpoint = [np.max(ydata_g), 0, np.ptp(xdata)/4]
            fitfunc = Gaussian;
            para_g, pcov_g = opt.curve_fit(fitfunc, xdata, ydata_g, startpoint)
            perr_g = np.sqrt(np.diag(pcov_g))
            
            startpoint = [np.max(ydata_e), 0, np.ptp(xdata)/4]
            para_e, pcov_e = opt.curve_fit(fitfunc, xdata, ydata_e, startpoint)
            perr_e = np.sqrt(np.diag(pcov_e))
            
            if ifplot:
                plt.figure()
                plt.plot(xdata, ydata_g, 'b.')
                plt.plot(xdata, ydata_e, 'r.')
                plt.plot(xdata, fitfunc(xdata,*para_g), 'b-')
                plt.plot(xdata, fitfunc(xdata,*para_e), 'r-')
                
                plt.show()
            
            SNR[m,k] = np.abs((para_e[1]-para_g[1]))/((np.abs(para_g[2])+np.abs(para_e[2]))/2)
        
    
    power = power/np.max(power)
    amp = np.sqrt(power)
    meanSNR = np.mean(SNR,axis=0)
    stdSNR = np.std(SNR, axis=0)
    
#    for k in np.arange(ave):
#        plt.plot(power, SNR[k,:],'o')
    
    
    
    startpoint = [0.1]
    ydata = meanSNR
    xdata = amp
    fitfunc = Linear;
    para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(0,np.max(xdata)*1.5,100)
    slope = para[0]
    
    print('slope is {}'.format(para[0]))
    
    if ifplotfinal:
        plt.figure()
        plt.errorbar(amp, meanSNR, stdSNR, fmt='x')
        plt.plot(xd, fitfunc(xd,*para), 'k-')
        
        
        plt.ylabel('SNR')
        plt.xlabel('Drive amplitude')
        plt.ylim([0, np.max(SNR)*1.1])
        plt.xlim([0, np.max(amp)*1.1])
    #    plt.xlim([0, 0.4])
        autoscale_y(plt.gca())
    
    return slope



def plot_powersweep_SNR_thermal_photonNumber(fileno=29, ifplot=0, ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    totxdata = data['totvoltage']
    tothistg = data['tothist_g']
    tothiste = data['tothist_e']
    att = data['att']
    att = att.flatten()
    power = 10**(-att/10)
    
    ave =  data['ave']
    ave = ave[0,0]
#    power =np.reshape(power,[np.size(power)])
    print(att)
    
#    print(10*np.log10(power))
    
    SNR = np.zeros([ave,np.size(totxdata,1)])
    
    
    for m in np.arange(ave):
        for k in np.arange(np.size(totxdata,1)):
            
            xdata = totxdata[m,k,:]
            ydata_g = tothistg[m,k,:]
            ydata_e = tothiste[m,k,:]
            
            
            
            startpoint = [np.max(ydata_g), 0, np.ptp(xdata)/4]
            fitfunc = Gaussian;
            para_g, pcov_g = opt.curve_fit(fitfunc, xdata, ydata_g, startpoint)
            perr_g = np.sqrt(np.diag(pcov_g))
            
            startpoint = [np.max(ydata_e), 0, np.ptp(xdata)/4]
            para_e, pcov_e = opt.curve_fit(fitfunc, xdata, ydata_e, startpoint)
            perr_e = np.sqrt(np.diag(pcov_e))
            
            if ifplot:
                plt.figure()
                plt.plot(xdata, ydata_g, 'b.')
                plt.plot(xdata, ydata_e, 'r.')
                plt.plot(xdata, fitfunc(xdata,*para_g), 'b-')
                plt.plot(xdata, fitfunc(xdata,*para_e), 'r-')
                
                plt.show()
            
            SNR[m,k] = np.abs((para_e[1]-para_g[1]))/((np.abs(para_g[2])+np.abs(para_e[2]))/2)
        
    
    
    meanSNR = np.mean(SNR,axis=0)
    stdSNR = np.std(SNR, axis=0)

    para, fitfunc = plot_photon_vs_power_thermal(ifplot=0)
    photonnum = fitfunc(power,*para)
    
    if ifplotfinal:
        plt.figure()
        plt.errorbar(2*photonnum, meanSNR, stdSNR, fmt = 'x')
        
        
        plt.ylabel('SNR')
        plt.xlabel('Photon number')
#        plt.ylim([0, np.max(meanSNR)*1.1])
#        plt.xlim([0, 12])
#        plt.ylim([0, 0.4])
        autoscale_y(plt.gca())
        
        plt.figure()
        plt.errorbar(-att, meanSNR, stdSNR, fmt = 'x')
        plt.ylim(plt.gca().get_ylim())
        
        
        plt.ylabel('SNR')
        plt.xlabel('Attenuation')
#        plt.ylim([0, np.max(meanSNR)*1.1])
        plt.xlim([-30, -10])
#        plt.ylim([0, 0.4])
        autoscale_y(plt.gca())
        plt.plot(np.array([1,1])*-15, plt.gca().get_ylim(), '--')
    
    return photonnum, meanSNR, stdSNR



def plot_ampsweep_SNR(fileno=298, ifplot=0, ifplotamp=0, ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    totxdata = data['totxdata']
    tothistg = data['tothistg']
    tothiste = data['tothiste']
    
    totxdata_amp = data['totxdata_amp']
    tothistg_amp = data['tothistg_amp']
    tothiste_amp = data['tothiste_amp']
    
    amp = data['amp']
    
    ave =  data['ave']
    ave = ave[0,0]
    amp =np.reshape(amp,[np.size(amp)])
    
    
#    print(10*np.log10(power))
    
    SNR = np.zeros([ave,np.size(totxdata,1)])
    SNR_amp = np.zeros([ave,np.size(totxdata,1)])
    
    
    for m in np.arange(ave):
        for k in np.arange(np.size(totxdata,1)):
            
            xdata = totxdata[m,k,:]
            ydata_g = tothistg[m,k,:]
            ydata_e = tothiste[m,k,:]
            
            index = np.argmax(ydata_g)
            startpoint = [np.max(ydata_g), xdata[index], np.ptp(xdata)/4]
            fitfunc = Gaussian;
            para_g, pcov_g = opt.curve_fit(fitfunc, xdata, ydata_g, startpoint)
            perr_g = np.sqrt(np.diag(pcov_g))
            
            index = np.argmax(ydata_e)
            startpoint = [np.max(ydata_e), xdata[index], np.ptp(xdata)/4]
            para_e, pcov_e = opt.curve_fit(fitfunc, xdata, ydata_e, startpoint)
            perr_e = np.sqrt(np.diag(pcov_e))
            
            if ifplot:
                plt.figure()
                plt.plot(xdata, ydata_g, 'b.')
                plt.plot(xdata, ydata_e, 'r.')
                plt.plot(xdata, fitfunc(xdata,*para_g), 'b-')
                plt.plot(xdata, fitfunc(xdata,*para_e), 'r-')
                
                plt.show()
            
            SNR[m,k] = np.abs((para_e[1]-para_g[1]))/((np.abs(para_g[2])+np.abs(para_e[2]))/2)
        
    for m in np.arange(ave):
        for k in np.arange(np.size(totxdata,1)):
            
            xdata = totxdata_amp[m,k,:]
            ydata_g = tothistg_amp[m,k,:]
            ydata_e = tothiste_amp[m,k,:]
            
            index = np.argmax(ydata_g)
            startpoint = [np.max(ydata_g), xdata[index], np.ptp(xdata)/4]
            fitfunc = Gaussian;
            para_g, pcov_g = opt.curve_fit(fitfunc, xdata, ydata_g, startpoint)
            perr_g = np.sqrt(np.diag(pcov_g))
            
            index = np.argmax(ydata_e)
            startpoint = [np.max(ydata_e), xdata[index], np.ptp(xdata)/4]
            para_e, pcov_e = opt.curve_fit(fitfunc, xdata, ydata_e, startpoint)
            perr_e = np.sqrt(np.diag(pcov_e))
            
            if ifplotamp:
                plt.figure()
                plt.plot(xdata, ydata_g, 'b.')
                plt.plot(xdata, ydata_e, 'r.')
                plt.plot(xdata, fitfunc(xdata,*para_g), 'b-')
                plt.plot(xdata, fitfunc(xdata,*para_e), 'r-')
                
                plt.show()
            
            SNR_amp[m,k] = np.abs((para_e[1]-para_g[1]))/((np.abs(para_g[2])+np.abs(para_e[2]))/2)
        
    
    
    meanSNR = np.mean(SNR,axis=0)
    stdSNR = np.std(SNR, axis=0)
    
    meanSNR_amp = np.mean(SNR_amp,axis=0)
    stdSNR_amp = np.std(SNR_amp, axis=0)
    
#    for k in np.arange(ave):
#        plt.plot(power, SNR[k,:],'o')
    
    
    
#    startpoint = [0.1]
#    ydata = meanSNR
#    xdata = amp
#    fitfunc = Linear;
#    para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
#    perr = np.sqrt(np.diag(pcov))
#    xd = np.linspace(0,np.max(xdata)*1.5,100)
#    slope = para[0]
    
#    print('slope is {}'.format(para[0]))
    para = plot_alpha_vs_amp(ifplot=0)
    alpha = alphamodel(amp, *para)
    n = alpha**2
    
    if ifplotfinal:
        plt.figure()
#        plt.errorbar(amp, meanSNR, stdSNR, fmt='x',color='r')
#        plt.errorbar(amp, meanSNR_amp, stdSNR_amp, fmt='s',color='b',mfc='w')
        plt.plot(amp, meanSNR, 'x',color='r')
        plt.plot(amp, meanSNR_amp, 's',color='b',mfc='w')
#        plt.plot(xd, fitfunc(xd,*para), 'k-')
        
        plt.legend(['ch2 reading','amplitude reading'])
        plt.ylabel('SNR')
        plt.xlabel('Drive amplitude')
        plt.ylim([0, np.max(SNR)*1.1])
        plt.xlim([0, np.max(amp)*1.1])
    #    plt.xlim([0, 0.4])
        autoscale_y(plt.gca())
    
        
        
        
        plt.figure()
        
#        alpha = alphamodel(amp, *para)
        
        plt.plot(alpha, meanSNR, 'x',color='r')
        plt.plot(alpha, meanSNR_amp, 's',color='b',mfc='w')
        
        plt.legend(['ch2 reading','amplitude reading'])
        plt.ylabel('SNR')
        plt.xlabel('$\\alpha$')
        
        plt.figure()
        
#        alpha = alphamodel(amp, *para)
#        n = alpha**2
        plt.plot(n, meanSNR, 'x',color='r')
        plt.plot(n, meanSNR_amp, 's',color='b',mfc='w')
        
        plt.legend(['ch2 reading','amplitude reading'],loc='lower right')
        plt.ylabel('SNR')
        plt.xlabel('photon number')
#    return slope
    
        
    return n, meanSNR, meanSNR_amp


def plot_ampsweep_SNR_coherent(fileno=32, ifplot=0, ifplotamp=0, ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    totxdata = data['totvoltage']
    tothistg = data['tothist_g']
    tothiste = data['tothist_e']
    
    print(np.shape(tothistg))
    amp = data['amp']
    
    ave =  data['ave']
    ave = ave[0,0]
    amp =np.reshape(amp,[np.size(amp)])
    
#    tot_cangle = data['tot_cangle']
    
#    print(10*np.log10(power))
    
    SNR = np.zeros([ave,np.size(totxdata,1)])
    
    
    for m in np.arange(ave):
        for k in np.arange(np.size(totxdata,1)):
            
            xdata = totxdata[m,k,:]
            ydata_g = tothistg[m,k,:]
            ydata_e = tothiste[m,k,:]
            
            index = np.argmax(ydata_g)
            startpoint = [np.max(ydata_g), xdata[index], np.ptp(xdata)/4]
            fitfunc = Gaussian;
            para_g, pcov_g = opt.curve_fit(fitfunc, xdata, ydata_g, startpoint)
            perr_g = np.sqrt(np.diag(pcov_g))
            
            index = np.argmax(ydata_e)
            startpoint = [np.max(ydata_e), xdata[index], np.ptp(xdata)/4]
            para_e, pcov_e = opt.curve_fit(fitfunc, xdata, ydata_e, startpoint)
            perr_e = np.sqrt(np.diag(pcov_e))
            
            if ifplot:
                plt.figure()
                plt.plot(xdata, ydata_g, 'b.')
                plt.plot(xdata, ydata_e, 'r.')
                plt.plot(xdata, fitfunc(xdata,*para_g), 'b-')
                plt.plot(xdata, fitfunc(xdata,*para_e), 'r-')
                
                plt.show()
            
            SNR[m,k] = np.abs((para_e[1]-para_g[1]))/((np.abs(para_g[2])+np.abs(para_e[2]))/2)
        
    
    
    meanSNR = np.mean(SNR,axis=0)
    stdSNR = np.std(SNR, axis=0)
    #    for k in np.arange(ave):
#        plt.plot(power, SNR[k,:],'o')
    
    
    
#    startpoint = [0.1]
#    ydata = meanSNR
#    xdata = amp
#    fitfunc = Linear;
#    para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
#    perr = np.sqrt(np.diag(pcov))
#    xd = np.linspace(0,np.max(xdata)*1.5,100)
#    slope = para[0]
    
#    print('slope is {}'.format(para[0]))
    para, fitfunc = plot_alpha_vs_amp(fileno=31, ifplot=0)
    photon = fitfunc(amp,*para)
    
    if ifplotfinal:
        plt.figure()
        plt.errorbar(photon, meanSNR, stdSNR, fmt='rx')
#        plt.errorbar(amp, meanSNR_amp, stdSNR_amp, fmt='s',color='b',mfc='w')
#        plt.plot(amp, meanSNR, 'x',color='r')
#        plt.plot(amp, meanSNR_amp, 's',color='b',mfc='w')
#        plt.plot(xd, fitfunc(xd,*para), 'k-')
        
#        plt.legend(['ch2 reading','amplitude reading'])
        plt.ylabel('SNR')
        plt.xlabel('Photon number')
#        plt.ylim([0, np.max(SNR)*1.1])
#        plt.xlim([0, np.max(amp)*1.1])
    #    plt.xlim([0, 0.4])
        autoscale_y(plt.gca())
    
        
    return photon, meanSNR, stdSNR

        
def plot_ampsweep_SNR_thermalState(fileno=33, ifplot=0, ifplotamp=0, ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    totxdata = data['totvoltage_amp']
    tothistg = data['tothist_g_amp']
    tothiste = data['tothist_e_amp']
    
    totxdata_correct = data['totvoltage_correct']
    tothistg_correct = data['tothist_g_correct']
    tothiste_correct = data['tothist_e_correct']
    
    n = data['photonnum']
    
    ave =  data['ave']
    ave = ave[0,0]
    n =np.reshape(n,[np.size(n)])
    
    
#    print(10*np.log10(power))
    
    SNR = np.zeros([ave,np.size(totxdata,1)])
    SNR_correct = np.zeros([ave,np.size(totxdata,1)])
    
    
    for m in np.arange(ave):
        for k in np.arange(np.size(totxdata,1)):
            
            xdata = totxdata[m,k,:]
            ydata_g = tothistg[m,k,:]
            ydata_e = tothiste[m,k,:]
            
            index = np.argmax(ydata_g)
            startpoint = [np.max(ydata_g), xdata[index], np.ptp(xdata)/4]
            fitfunc = Gaussian;
            para_g, pcov_g = opt.curve_fit(fitfunc, xdata, ydata_g, startpoint)
            perr_g = np.sqrt(np.diag(pcov_g))
            
            index = np.argmax(ydata_e)
            startpoint = [np.max(ydata_e), xdata[index], np.ptp(xdata)/4]
            para_e, pcov_e = opt.curve_fit(fitfunc, xdata, ydata_e, startpoint)
            perr_e = np.sqrt(np.diag(pcov_e))
            
            if ifplot:
                plt.figure()
                plt.plot(xdata, ydata_g, 'b.')
                plt.plot(xdata, ydata_e, 'r.')
                plt.plot(xdata, fitfunc(xdata,*para_g), 'b-')
                plt.plot(xdata, fitfunc(xdata,*para_e), 'r-')
                
                plt.show()
            
            SNR[m,k] = np.abs((para_e[1]-para_g[1]))/((np.abs(para_g[2])+np.abs(para_e[2]))/2)
        
    for m in np.arange(ave):
        for k in np.arange(np.size(totxdata,1)):
            
            xdata = totxdata_correct[m,k,:]
            ydata_g = tothistg_correct[m,k,:]
            ydata_e = tothiste_correct[m,k,:]
            
            index = np.argmax(ydata_g)
            startpoint = [np.max(ydata_g), xdata[index], np.ptp(xdata)/4]
            fitfunc = Gaussian;
            para_g, pcov_g = opt.curve_fit(fitfunc, xdata, ydata_g, startpoint)
            perr_g = np.sqrt(np.diag(pcov_g))
            
            index = np.argmax(ydata_e)
            startpoint = [np.max(ydata_e), xdata[index], np.ptp(xdata)/4]
            para_e, pcov_e = opt.curve_fit(fitfunc, xdata, ydata_e, startpoint)
            perr_e = np.sqrt(np.diag(pcov_e))
            
            if ifplotamp:
                plt.figure()
                plt.plot(xdata, ydata_g, 'b.')
                plt.plot(xdata, ydata_e, 'r.')
                plt.plot(xdata, fitfunc(xdata,*para_g), 'b-')
                plt.plot(xdata, fitfunc(xdata,*para_e), 'r-')
                
                plt.show()
            
            SNR_correct[m,k] = np.abs((para_e[1]-para_g[1]))/((np.abs(para_g[2])+np.abs(para_e[2]))/2)
        
    
    
    meanSNR = np.mean(SNR,axis=0)
    stdSNR = np.std(SNR, axis=0)
    
    meanSNR_correct = np.mean(SNR_correct,axis=0)
    stdSNR_correct = np.std(SNR_correct, axis=0)
    
#    for k in np.arange(ave):
#        plt.plot(power, SNR[k,:],'o')
    
    
    
#    startpoint = [0.1]
#    ydata = meanSNR
#    xdata = amp
#    fitfunc = Linear;
#    para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
#    perr = np.sqrt(np.diag(pcov))
#    xd = np.linspace(0,np.max(xdata)*1.5,100)
#    slope = para[0]
    
#    print('slope is {}'.format(para[0]))
    
    if ifplotfinal:
        plt.figure()
        plt.errorbar(n, meanSNR, stdSNR, fmt='x',color='r')
        plt.errorbar(n, meanSNR_correct, stdSNR_correct, fmt='s',color='b',mfc='w')
#        plt.plot(n, meanSNR, 'x',color='r')
#        plt.plot(n, meanSNR_correct, 's',color='b',mfc='w')
#        plt.plot(xd, fitfunc(xd,*para), 'k-')
        
        plt.legend(['before correction','after correction'])
        plt.ylabel('SNR')
        plt.xlabel('Photon number')
#        plt.ylim([0, np.max(SNR)*1.1])
#        plt.xlim([0, np.max(n)*1.1])
    #    plt.xlim([0, 0.4])
        autoscale_y(plt.gca())
    
    
    return n, meanSNR, stdSNR, meanSNR_correct, stdSNR_correct
#    return slope
    

def plot_ampsweep_SNR_monothermalState_FTmethod(fileno=37, ifplot=0, ifplotamp=0, ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    totxdata = data['totvoltage']
    tothistg = data['tothist_g']
    tothiste = data['tothist_e']
    
    
    n = data['photonnum']
    
    ave =  data['ave']
    ave = ave[0,0]
    n =np.reshape(n,[np.size(n)])
    
    
#    print(10*np.log10(power))
    
    SNR = np.zeros([ave,np.size(totxdata,1)])
    
    
    for m in np.arange(ave):
        for k in np.arange(np.size(totxdata,1)):
            
            xdata = totxdata[m,k,:]
            ydata_g = tothistg[m,k,:]
            ydata_e = tothiste[m,k,:]
            
            index = np.argmax(ydata_g)
            startpoint = [np.max(ydata_g), xdata[index], np.ptp(xdata)/4]
            fitfunc = Gaussian;
            para_g, pcov_g = opt.curve_fit(fitfunc, xdata, ydata_g, startpoint)
            perr_g = np.sqrt(np.diag(pcov_g))
            
            index = np.argmax(ydata_e)
            startpoint = [np.max(ydata_e), xdata[index], np.ptp(xdata)/4]
            para_e, pcov_e = opt.curve_fit(fitfunc, xdata, ydata_e, startpoint)
            perr_e = np.sqrt(np.diag(pcov_e))
            
            if ifplot:
                plt.figure()
                plt.plot(xdata, ydata_g, 'b.')
                plt.plot(xdata, ydata_e, 'r.')
                plt.plot(xdata, fitfunc(xdata,*para_g), 'b-')
                plt.plot(xdata, fitfunc(xdata,*para_e), 'r-')
                
                plt.show()
            
            SNR[m,k] = np.abs((para_e[1]-para_g[1]))/((np.abs(para_g[2])+np.abs(para_e[2]))/2)

    
    
    meanSNR = np.mean(SNR,axis=0)
    stdSNR = np.std(SNR, axis=0)
    
    
    if ifplotfinal:
        plt.figure()
        plt.errorbar(n, meanSNR, stdSNR, fmt='x',color='r')
#        plt.plot(n, meanSNR, 'x',color='r')
#        plt.plot(n, meanSNR_correct, 's',color='b',mfc='w')
#        plt.plot(xd, fitfunc(xd,*para), 'k-')
        
        plt.legend(['before correction','after correction'])
        plt.ylabel('SNR')
        plt.xlabel('Photon number')
#        plt.ylim([0, np.max(SNR)*1.1])
#        plt.xlim([0, np.max(n)*1.1])
    #    plt.xlim([0, 0.4])
        autoscale_y(plt.gca())
    
    
    return n, meanSNR, stdSNR


def compare_thermal_coherent():
    
    plt.figure()
    n, meanSNR, meanSNR_correct = plot_ampsweep_SNR_thermalState(
            fileno=299, ifplot=0, ifplotamp=0, ifplotfinal=0)
    
    plt.plot(n, meanSNR, 's',color='r')
    plt.plot(n, meanSNR_correct, 'x',color='g',mfc='w')
    
    n, meanSNR, meanSNR_amp = plot_ampsweep_SNR(
            fileno=298, ifplot=0, ifplotamp=0, ifplotfinal=0)
    
    plt.plot(n, meanSNR, 'o',color='y',mfc='w')
#    plt.plot(n, meanSNR_amp, 's',color='c',mfc='w')
    
#    plt.legend(['T:amplitude','T:corrected','C: normal','C:amplitude'],
#               loc='lower right', bbox_to_anchor=(1,0))
    
    n, meanSNR = plot_powersweep_SNR_thermal_photonNumber(
            fileno=309, ifplot=0, ifplotfinal=0)
    
    plt.plot(n*2, meanSNR, 's',color='b',mfc='w')
    
    plt.legend(['T: amplitude', 'T: corrected','C','T: broadband'],
               loc='lower right', bbox_to_anchor=(1,0))
    
    
    
    plt.xlabel('Photon number')
    plt.ylabel('SNR')
    
    
def compare_coherent_SNR():
    
    plt.figure()
     
    n, meanSNR, meanSNR_amp = plot_ampsweep_SNR(
            fileno=298, ifplot=0, ifplotamp=0, ifplotfinal=0)
    
    plt.plot(n, meanSNR, 'o',color='y',mfc='w')
    plt.xlabel('Photon number')
    plt.ylabel('SNR')
    
    xdata = n
    ydata = meanSNR
    startpoint = [1]
    fitfunc = sqrtmodel;
    para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
    perr = np.sqrt(np.diag(pcov))
    
    nd = np.linspace(0,np.max(n)*1.1,100)
    plt.plot(nd, fitfunc(nd, *para), 'r')

def sqrtmodel(x,a):
    return a*np.sqrt(x)
    
    
    
def plot_ampsweep_dephaseAmp(fileno=18,ifplot=0,ifplotfinal=1):
    
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    amp = data['amp']
    amp = amp.flatten()
    totprob = data['totprob']
    print(np.shape(totprob))
    ave = np.size(totprob,0)
    
    dephaseAmp = np.zeros([ave, np.size(totprob,1)])
    
    for m in np.arange(ave):
        for k in np.arange(np.size(totprob,1)):
#            print(k)
            xdata = sweepparam.flatten()
            ydata = totprob[m,k,:]
            
            
            startpoint = [np.ptp(ydata), np.pi, 0.5]
            fitfunc = Osc;
            para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
            perr = np.sqrt(np.diag(pcov))
                     
            if ifplot:
                plt.figure()
                plt.plot(xdata, ydata, 'k.')
                plt.plot(xdata, fitfunc(xdata,*para), 'r-')
                plt.show()
            
            dephaseAmp[m,k] = np.abs(para[0])
    print(np.shape(dephaseAmp))
    meanamp = np.mean(dephaseAmp,axis=0)
    stdamp = np.std(dephaseAmp, axis=0)
#    para = plot_alpha_vs_amp(ifplot=0)
#    alpha = alphamodel(amp, *para)
#    n = alpha**2
    if ifplotfinal:        
        plt.figure()
       
        
        plt.errorbar(amp, meanamp, 2*stdamp, fmt='x')        
        
        plt.ylabel('Osc amp')
        plt.xlabel('Drive amplitude')
        
        
        
        
#        plt.figure()    
#        plt.plot(n, meanamp, 'x')        
        
#        plt.ylabel('Osc amp')
#        plt.xlabel('Photon number')
        
    return amp, meanamp, stdamp


def plot_ampsweep_dephaseAmp_noAve(fileno=300,ifplot=0,ifplotfinal=1):
    
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    amp = data['amp']
    amp = amp.flatten()
    totprob = data['totprob']
    print(np.shape(totprob))
    
    dephaseAmp = np.zeros(np.size(totprob,0))
    
    for k in np.arange(np.size(totprob,0)):
        
        xdata = sweepparam.flatten()
        ydata = totprob[k,:]
        
        
        startpoint = [np.ptp(ydata), np.pi, 0.5]
        fitfunc = Osc;
        para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
        perr = np.sqrt(np.diag(pcov))
                 
        if ifplot:
            plt.figure()
            plt.plot(xdata, ydata, 'k.')
            plt.plot(xdata, fitfunc(xdata,*para), 'r-')
            plt.show()
        
        dephaseAmp[k] = np.abs(para[0])
            
    meanamp = dephaseAmp
#    para = plot_alpha_vs_amp(ifplot=0)
#    alpha = alphamodel(amp, *para)
    n = amp**2
    
    if ifplotfinal:        
        plt.figure()
       
        
        plt.plot(amp, meanamp, 'x')        
        
        plt.ylabel('Osc amp')
        plt.xlabel('Drive amplitude')
        
        
        
        
        plt.figure()    
        plt.plot(n, meanamp, 'x')        
        
        plt.ylabel('Osc amp')
        plt.xlabel('Photon number')
        
    return amp, meanamp

def plot_timesweep_dephaseAmp(fileno=5,ifplot=0,ifplotfinal=1):
    
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    sweepparam = sweepparam.flatten()
    sweeptime = data['sweeptime']
    sweeptime = sweeptime.flatten()
    totprob_noPi = data['totprobGE']
    totprob_Pi = data['totprobGF']
    print(np.shape(totprob_Pi))
    print(np.shape(sweeptime))
    
    dephaseAmp_noPi = np.zeros( np.size(totprob_Pi,0))
    dephaseAmp_Pi = np.zeros( np.size(totprob_Pi,0))
    
    for k in np.arange(np.size(totprob_Pi,0)):
#    for k in np.arange(1):
        
        xdata = sweepparam
        ydata = totprob_noPi[k,:]

        startpoint = [np.ptp(ydata), np.pi, 0.5]
        fitfunc = Osc;
        para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
        perr = np.sqrt(np.diag(pcov))
                 
        if ifplot:
            plt.figure()
            plt.plot(xdata, ydata, 'k.')
            plt.plot(xdata, fitfunc(xdata,*para), 'r-')
            plt.show()
            
        dephaseAmp_noPi[k] = np.abs(para[0])
        
        xdata = sweepparam
        ydata = totprob_Pi[k,:]

        startpoint = [np.ptp(ydata), np.pi, 0.5]
        fitfunc = Osc;
        para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
        perr = np.sqrt(np.diag(pcov))
                 
        if ifplot:
            plt.figure()
            plt.plot(xdata, ydata, 'k.')
            plt.plot(xdata, fitfunc(xdata,*para), 'r-')
            plt.show()
        
        dephaseAmp_Pi[k] = np.abs(para[0])
    
    totamp = dephaseAmp_Pi + dephaseAmp_noPi
    print(np.shape(totamp))
    if ifplotfinal:        
        plt.figure()
       
        
        plt.plot(sweeptime, totamp, 'ko-') 
        plt.plot(sweeptime, dephaseAmp_Pi, 'ro-') 
        plt.plot(sweeptime, dephaseAmp_noPi, 'bo-') 
        
        plt.legend(['total coherence','gf coherence','ge coherence'], loc='lower left',bbox_to_anchor=(1,0))
       
        
        plt.ylabel('Osc amp')
        plt.xlabel('Sweep time')
        
#        data = {'sweepparam':sweepparam, 'totprobGF':totprobGF,
#                'totprobGE':totprobGE, 'actualAngle':actualAngle}
        
def plot_anglesweep_dephaseAmp(fileno=66,ifplot=0,ifplotfinal=1):
    
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    sweepparam = sweepparam.flatten()
    angle = data['actualAngle']
    angle = angle.flatten()
    totprob_noPi = data['totprobGE']
    totprob_Pi = data['totprobGF']
    print(np.shape(totprob_Pi))
    
#    pi_ef_time = 46
#    rotduration = np.zeros(np.size(angle))
#    for k in np.arange(np.size(angle)):
#        rotduration[k] = np.int(pi_ef_time*angle[k]/np.pi)
#    angle = rotduration / pi_ef_time * np.pi
    
    
    dephaseAmp_noPi = np.zeros( np.size(totprob_Pi,0))
    dephaseAmp_Pi = np.zeros( np.size(totprob_Pi,0))
    
    for k in np.arange(np.size(totprob_Pi,0)):
#    for k in np.arange(1):
        
        xdata = sweepparam
        ydata = totprob_noPi[k,:]

        startpoint = [np.ptp(ydata), np.pi, 0.5]
        fitfunc = Osc;
        para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
        perr = np.sqrt(np.diag(pcov))
                 
        if ifplot:
            plt.figure()
            plt.plot(xdata, ydata, 'k.')
            plt.plot(xdata, fitfunc(xdata,*para), 'r-')
            plt.show()
            
        dephaseAmp_noPi[k] = np.abs(para[0])
        
        xdata = sweepparam
        ydata = totprob_Pi[k,:]

        startpoint = [np.ptp(ydata), np.pi, 0.5]
        fitfunc = Osc;
        para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
        perr = np.sqrt(np.diag(pcov))
                 
        if ifplot:
            plt.figure()
            plt.plot(xdata, ydata, 'k.')
            plt.plot(xdata, fitfunc(xdata,*para), 'r-')
            plt.show()
        
        dephaseAmp_Pi[k] = np.abs(para[0])
    
    totamp = dephaseAmp_Pi + dephaseAmp_noPi
    print(np.shape(totamp))
    if ifplotfinal:        
        plt.figure()
       
        
        plt.plot(angle, totamp, 'ko-') 
        plt.plot(angle, dephaseAmp_Pi, 'ro-') 
        plt.plot(angle, dephaseAmp_noPi, 'bo-') 
        
        plt.legend(['total coherence','gf coherence','ge coherence'], loc='lower left',bbox_to_anchor=(1,0))
        
        plt.ylabel('Osc amp')
        plt.xlabel('Rotation angle')
        
        
        plt.figure()
       
        p = np.cos(angle/2)
#        plt.plot(angle, totamp, 'ko-') 
#        plt.plot(angle, dephaseAmp_Pi, 'ro-') 
        plt.plot(p, dephaseAmp_noPi, 'bo-') 
        
#        plt.legend(['total coherence','gf coherence','ge coherence'], loc='lower left',bbox_to_anchor=(1,0))
        
        plt.ylabel('Osc amp')
        plt.xlabel('photon num')
        
        
    return angle, dephaseAmp_Pi, dephaseAmp_noPi


def plot_anglesweep_dephaseAmp_withave(fileno=67,ifplot=0,ifplotfinal=1):
    
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    sweepparam = sweepparam.flatten()
    angle = data['actualAngle']
    angle = angle.flatten()
    totprob_noPi = data['totprobGE']
    totprob_Pi = data['totprobGF']
    print(np.shape(totprob_Pi))
    
    
    ave = np.shape(totprob_noPi)[0]
#    pi_ef_time = 46
#    rotduration = np.zeros(np.size(angle))
#    for k in np.arange(np.size(angle)):
#        rotduration[k] = np.int(pi_ef_time*angle[k]/np.pi)
#    angle = rotduration / pi_ef_time * np.pi
    
    
    dephaseAmp_noPi = np.zeros([ave, np.size(totprob_Pi,1)])
    dephaseAmp_Pi = np.zeros( [ave, np.size(totprob_Pi,1)])
    
    for l in np.arange(ave):
        for k in np.arange(np.size(totprob_Pi,1)):
    #    for k in np.arange(1):
            
            xdata = sweepparam
            ydata = totprob_noPi[l,k,:]
    
            startpoint = [np.ptp(ydata), np.pi, 0.5]
            fitfunc = Osc;
            para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
            perr = np.sqrt(np.diag(pcov))
                     
            if ifplot:
                plt.figure()
                plt.plot(xdata, ydata, 'k.')
                plt.plot(xdata, fitfunc(xdata,*para), 'r-')
                plt.show()
                
            dephaseAmp_noPi[l,k] = np.abs(para[0])
            
            xdata = sweepparam
            ydata = totprob_Pi[l,k,:]
    
            startpoint = [np.ptp(ydata), np.pi, 0.5]
            fitfunc = Osc;
            para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
            perr = np.sqrt(np.diag(pcov))
                     
            if ifplot:
                plt.figure()
                plt.plot(xdata, ydata, 'k.')
                plt.plot(xdata, fitfunc(xdata,*para), 'r-')
                plt.show()
            
            dephaseAmp_Pi[l,k] = np.abs(para[0])
    
    totamp = dephaseAmp_Pi + dephaseAmp_noPi
    print(np.shape(totamp))
    
    mean_totamp = np.mean(totamp, axis=0)
    std_totamp = np.std(totamp, axis=0)
    mean_dephaseAmp_Pi = np.mean(dephaseAmp_Pi, axis=0)
    std_dephaseAmp_Pi = np.std(dephaseAmp_Pi, axis=0)
    mean_dephaseAmp_noPi = np.mean(dephaseAmp_noPi, axis=0)
    std_dephaseAmp_noPi = np.std(dephaseAmp_noPi, axis=0)
    
    print(np.shape(totamp))
    if ifplotfinal:        
        plt.figure()
       
        
        plt.errorbar(angle, mean_totamp, std_totamp, fmt='ko-') 
        plt.errorbar(angle, mean_dephaseAmp_Pi, std_dephaseAmp_Pi, fmt='ro-') 
        plt.errorbar(angle, mean_dephaseAmp_noPi, std_dephaseAmp_noPi, fmt='bo-') 
        
        plt.legend(['total coherence','gf coherence','ge coherence'], loc='lower left',bbox_to_anchor=(1,0))
        
        plt.ylabel('Osc amp')
        plt.xlabel('Rotation angle')
        plt.show()
        
#        plt.figure()
#        for l in np.arange(ave):
#            
#            plt.plot(angle, totamp[l,:], 'ko-') 
#            plt.plot(angle, dephaseAmp_Pi[l,:], 'ro-') 
#            plt.plot(angle, dephaseAmp_noPi[l,:], 'bo-') 
        
    
        
#        plt.figure()
#       
#        p = np.cos(angle/2)
##        plt.plot(angle, totamp, 'ko-') 
##        plt.plot(angle, dephaseAmp_Pi, 'ro-') 
#        plt.plot(p, dephaseAmp_noPi, 'bo-') 
#        
##        plt.legend(['total coherence','gf coherence','ge coherence'], loc='lower left',bbox_to_anchor=(1,0))
#        
#        plt.ylabel('Osc amp')
#        plt.xlabel('photon num')
        
        
    return angle, mean_dephaseAmp_noPi, std_dephaseAmp_noPi

def plot_anglesweep_dephaseAmp_old(fileno=373,ifplot=0,ifplotfinal=1):
    
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    time = data['time']
    time = time.flatten()
    angle = data['angle']
    angle = angle.flatten()
    totprob_noPi = data['totprob_noPi']
    totprob_Pi = data['totprob_Pi']
    print(np.shape(totprob_Pi))
    
    pi_ef_time = 46
    rotduration = np.zeros(np.size(angle))
    for k in np.arange(np.size(angle)):
        rotduration[k] = np.int(pi_ef_time*angle[k]/np.pi)
    angle = rotduration / pi_ef_time * np.pi
    
    
    dephaseAmp_noPi = np.zeros( np.size(totprob_Pi,0))
    dephaseAmp_Pi = np.zeros( np.size(totprob_Pi,0))
    
    for k in np.arange(np.size(totprob_Pi,0)):
#    for k in np.arange(1):
        
        xdata = time
        ydata = totprob_noPi[k,:]

        startpoint = [np.ptp(ydata), np.pi, 0.5]
        fitfunc = Osc;
        para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
        perr = np.sqrt(np.diag(pcov))
                 
        if ifplot:
            plt.figure()
            plt.plot(xdata, ydata, 'k.')
            plt.plot(xdata, fitfunc(xdata,*para), 'r-')
            plt.show()
            
        dephaseAmp_noPi[k] = np.abs(para[0])
        
        xdata = time
        ydata = totprob_Pi[k,:]

        startpoint = [np.ptp(ydata), np.pi, 0.5]
        fitfunc = Osc;
        para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
        perr = np.sqrt(np.diag(pcov))
                 
        if ifplot:
            plt.figure()
            plt.plot(xdata, ydata, 'k.')
            plt.plot(xdata, fitfunc(xdata,*para), 'r-')
            plt.show()
        
        dephaseAmp_Pi[k] = np.abs(para[0])
    
    totamp = dephaseAmp_Pi + dephaseAmp_noPi
    print(np.shape(totamp))
    if ifplotfinal:        
        plt.figure()
       
        
        plt.plot(angle, totamp, 'ko-') 
        plt.plot(angle, dephaseAmp_Pi, 'ro-') 
        plt.plot(angle, dephaseAmp_noPi, 'bo-') 
        
        plt.legend(['total coherence','gf coherence','ge coherence'], loc='lower left',bbox_to_anchor=(1,0))
        
        plt.ylabel('Osc amp')
        plt.xlabel('Rotation angle')
        
        
    return angle, dephaseAmp_Pi, dephaseAmp_noPi    
    
def plot_ampsweep_dephaseAmp_thermal(fileno=26, ifplot=0, ifplotfinal=1):
    
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    att = data['att']
    att = att.flatten()
    power = 10**(-att/10)
    totprob = data['totprob']
    print(np.shape(totprob))
    ave = np.size(totprob,0)
    
    dephaseAmp = np.zeros([ave, np.size(totprob,1)])
    
    for m in np.arange(ave):
        for k in np.arange(np.size(totprob,1)):
            
            xdata = sweepparam.flatten()
            ydata = totprob[m,k,:]
            
            
            startpoint = [np.ptp(ydata), np.pi, 0.5]
            fitfunc = Osc;
            para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
            perr = np.sqrt(np.diag(pcov))
                     
            if ifplot:
                plt.figure()
                plt.plot(xdata, ydata, 'k.')
                plt.plot(xdata, fitfunc(xdata,*para), 'r-')
                plt.xlabel('Phase')
                plt.ylabel('P$_e$')
                plt.show()
            
            dephaseAmp[m,k] = np.abs(para[0])
    
    meanamp = np.mean(dephaseAmp,axis=0)
    stdamp = np.std(dephaseAmp,axis=0)
    
    if ifplotfinal:    
        plt.figure()
        
        
        plt.errorbar(np.sqrt(power), meanamp, 2*stdamp, fmt = 'x')        
        
        plt.ylabel('Osc amp')
        plt.xlabel('Amplitude')
        
        plt.figure()
        
        
        plt.errorbar(att, meanamp, 2*stdamp, fmt = 'x')        
        
        plt.ylabel('Osc amp')
        plt.xlabel('Amplitude')
    
    return power, meanamp, stdamp





def plot_ampsweep_dephaseAmp_monothermal_justamp(fileno=18, ifplot=0, ifplotfinal=1):
    # "just amp" means we use the probability distribution of the coherent 
    # state to make a monochromatic thermal state
    
    
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    amp = data['amp']
    amp = amp.flatten()
    totprob = data['totprob']
    print(np.shape(totprob))
    ave = np.size(totprob,0)
    
    
    para, fitfunc = plot_alpha_vs_amp(ifplot=0)
    photon = fitfunc(amp,*para)
    alpha = np.sqrt(photon)
    step = np.zeros(np.size(alpha))
    for l in np.arange(np.size(alpha)):
        if l == 0:
            step[l] = alpha[0] + (alpha[1]-alpha[0])/2
        elif l > 0 and l < np.size(alpha)-1:
            step[l] = (alpha[l+1]-alpha[l-1])/2
        elif l == np.size(alpha)-1:
            step[l] = (alpha[l]-alpha[l-1])

    n_plot = np.linspace(0.01,8,20)
    prob_plot = np.zeros([ave, np.size(n_plot),np.size(totprob,2)])
    
    dephaseAmp = np.zeros([ave, np.size(n_plot)])
    for kl in np.arange(ave):
        for k in np.arange(np.size(n_plot)):
            
               
            distribution = np.exp(-alpha**2/n_plot[k]) * (alpha) * step
            distribution = distribution/np.sum(distribution)
#            print(np.sum(distribution))
            for m in np.arange(np.size(totprob,1)): 
                prob_plot[kl, k,:] = prob_plot[kl, k,:] + distribution[m]*totprob[kl,m,:]
        
            xdata = sweepparam.flatten()
            ydata = prob_plot[kl,k,:]
            
            startpoint = [np.ptp(ydata), np.pi, 0.5]
            fitfunc = Osc;
            para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
            perr = np.sqrt(np.diag(pcov))
                     
            if ifplot:
                plt.figure()
                plt.plot(xdata, ydata, 'k.')
                plt.plot(xdata, fitfunc(xdata,*para), 'r-')
                plt.show()
            
            dephaseAmp[kl, k] = np.abs(para[0])    
    
    meanamp = np.mean(dephaseAmp, axis = 0)
    stdamp = np.std(dephaseAmp, axis = 0)
    if ifplotfinal:    
        plt.figure()
        
        
        plt.errorbar(n_plot, meanamp, stdamp,  fmt = 'x')        
        
        plt.ylabel('Osc amp')
        plt.xlabel('Photon number')
        
    return  n_plot, meanamp, stdamp
    
    
def compare_dephase_amp_coherent_thermal():
    plt.figure()
    
    n, amp = plot_ampsweep_dephaseAmp_thermal(fileno=301, ifplot=0, ifplotfinal=0)
    plt.plot(n, amp, 'rx')
    
    n, amp = plot_ampsweep_dephaseAmp(fileno=300, ifplot=0, ifplotfinal=0)
    plt.plot(n, amp, 'bs')
    
    plt.legend(['Thermal','Coherent'])
    plt.ylabel('Osc amp')
    plt.xlabel('Photon number')
    
    
def compare_dephase_amp_coherent_thermal_justamp():
    plt.figure()
    
    n, amp = plot_ampsweep_dephaseAmp_thermal_justamp(fileno=302, ifplot=0, ifplotfinal=0)
    plt.plot(n, amp, 'rx')
    
    n, amp = plot_ampsweep_dephaseAmp(fileno=300, ifplot=0, ifplotfinal=0)
    plt.plot(n, amp, 'bs')
    
    plt.legend(['Thermal','Coherent'])
    plt.ylabel('Osc amp')
    plt.xlabel('Photon number')
    
    
def compare_dephase_amp_coherent_thermal_justamp_withBroadbandThermal():
    plt.figure()
    
    n, amp = plot_ampsweep_dephaseAmp_thermal_justamp(fileno=302, ifplot=0, ifplotfinal=0)
    plt.plot(n, amp/np.max(amp), 'rx-')
    
    n, amp = plot_ampsweep_dephaseAmp(fileno=300, ifplot=0, ifplotfinal=0)
    plt.plot(n, amp/np.max(amp), 'bs-')
    
    n, amp = plot_powersweep_dephaseAmp_broadbandThermal(fileno=311,ifplot=0, ifplotfinal=0)
    plt.plot(n, amp/np.max(amp), 'go-')
    
    plt.legend(['Thermal','Coherent','BroadbandThermal'])
    plt.ylabel('Normalized amp')
    plt.xlabel('Photon number')


def compare_dephase_amp_withBroadbandThermal_withSinglePhoton():
    
    kappas = 4 * kappa * chi**2/(kappa**2 + 4 * chi**2)
    
    plt.figure()
    
    time = 1
    
    n, amp = plot_ampsweep_dephaseAmp_thermal_justamp(fileno=302, ifplot=0, ifplotfinal=0)
    plt.plot(n*kappas*time, amp/np.max(amp), 'rx-')
    
    n, amp = plot_ampsweep_dephaseAmp(fileno=300, ifplot=0, ifplotfinal=0)
    plt.plot(n*kappas*time, amp/np.max(amp), 'bs-')
    
    n, amp = plot_powersweep_dephaseAmp_broadbandThermal(fileno=311,ifplot=0, ifplotfinal=0)
    n = 2 * n
    plt.plot(n*kappas*time, amp/np.max(amp), 'go-')
    
    angle, _, amp =  plot_anglesweep_dephaseAmp(fileno=372,ifplot=0,ifplotfinal=0)
    n = np.sin(angle/2) ** 2
    plt.plot(n, amp/np.max(amp), 'yo-', mfc='w')
    
    plt.legend(['Thermal','Coherent','BroadbandThermal','SinglePhoton'])
    plt.ylabel('Normalized amp')
    plt.xlabel('Emitted Photon number')
    plt.xlim([0,6])

def compare_dephase_theory():
    
    kappas = 4 * kappa * chi**2/(kappa**2 + 4 * chi**2)
    
    plt.figure()
    # coherent state
    n = np.linspace(0.01,3,80)
    time = 2
    amp = np.exp(- kappas * time * n)
    plt.plot(n*kappas*time, amp, 'bx')
    
    #  thermal state
    step = 0.01
    alphalist = np.arange(0,4,step) + step/2
    amp_monoThermal = np.zeros(np.size(n))
#    amp_broadThermal = np.zeros(np.size(n))
    kappa_broadThermal = np.zeros(np.size(n))
    for k in np.arange(np.size(n)):
        for m in np.arange(np.size(alphalist)):
            if n[k] == 0:
                p = 1/(np.pi * n[k]) * np.exp(-alphalist[m]**2/n[k]) * ( 2 * 
                      np.pi * alphalist[m] * step)
            else:
                p = 1/(np.pi * n[k]) * np.exp(-alphalist[m]**2/n[k]) * ( 2 * 
                      np.pi * alphalist[m] * step)
            amp = np.exp(- kappas * time * alphalist[m]**2)
            amp_monoThermal[k] = amp_monoThermal[k] + amp * p
            kappa_broadThermal[k] = kappa_broadThermal[k] + p * kappas * alphalist[m]**2
            
    amp_broadThermal = np.exp(- kappa_broadThermal * time)
    
    plt.plot(n*kappas*time, amp_broadThermal, 'g')
    plt.plot(n*kappas*time, amp_monoThermal, 'r')
    
    
    # single photon
    theta = np.linspace(0,np.pi,100)
    n = np.sin(theta/2)**2
    amp  = np.cos(theta/2)
    plt.plot(n, amp, 'y')
    
    plt.xlim([0,6])
    
    plt.legend(['coherent','broad thermal','mono thermal', 'single photon'])
    
    plt.xlabel('Emitted Photon number')
    plt.ylabel('Osc amp')
    
def plot_thermal_photonDistribution(fileno=292, ifplot=1, ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    sweepfreq = data['sweepfreq']
    sweepfreq = sweepfreq.flatten()
    sweepparam = sweepparam.flatten()
    totprob = data['totprob']
    
    avephoton = np.zeros(np.shape(totprob)[0])
    for m in np.arange(np.shape(totprob)[0]):
#    for k in np.arange(4):
        prob = totprob[m,:]
        
        
        maxnum = 6
    
    
        chiv = chi * 1.0
            
            
        peak = np.zeros(maxnum)
        
        sep = chiv/(2*np.pi)*2
        width = sep/2
        shift = -0.0
        
        if ifplot:
            plt.figure()
            plt.plot(sweepfreq*1e3, prob, 'k.-')
            plt.xlabel('Detuning (MHz)')
            plt.ylabel('P$_e$')
            plt.ylim(plt.gca().get_ylim())
            for k in np.arange(maxnum):
                plt.plot(np.array([1,1])*(-k)*chiv/(2*np.pi)*2+shift, plt.gca().get_ylim(), 'r--')
            
        
            plt.title('Attenuation {} dB'.format(-sweepparam[m]))
            plt.show()
        
        xdata = sweepfreq*1e3
        ydata = prob
        for k in np.arange(maxnum):
        
            
            index = np.where(np.logical_and.reduce
                             ((xdata>-k*sep-width+shift,
                               xdata<-k*sep+width+shift)))[0]
            bgindex = np.where((xdata>sep))[0]
            
            
            peak[k] = np.sum(ydata[index] - np.mean(ydata[bgindex]))
            
#            avenum = np.sum(xdata * (ydata - np.mean(ydata[bgindex]))) / (-chi*2/(2*np.pi)*1e-3)
#            alpha_num = np.sqrt(avenum)
#            print([avenum, alpha_num])
        
        
        
        photonnum = np.arange(maxnum)
        
        startpoint = [1,0.5]
        fitfunc = thermalstate;
        para, pcov = opt.curve_fit(fitfunc, photonnum, peak, startpoint)
        
        xd = np.linspace(0, maxnum, 100)
        
        if ifplot:
            plt.figure()
            plt.plot(photonnum, peak, 'o')
            plt.plot(xd, fitfunc(xd, *para), 'r')
            plt.ylabel('Population')
            plt.xlabel('n')
        
        print(para[0])
        
        avephoton[m] = para[0]


    power = 10**(sweepparam/10)
    
    
    
    xdata = power
    fdata = avephoton
    startpoint = [40,15,1]
    fitfunc = alphamodel;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    xd = np.linspace(0,0.35,100)
    
    if ifplotfinal:
        plt.figure()
        plt.plot(power, avephoton, 'x')
        plt.plot(xd, alphamodel(xd,*para),'r') 
        
        plt.plot(0,0)
        print(para)
        
        plt.xlabel('Power')
        plt.ylabel('n')
    
    return para
    
def plot_powersweep_dephaseAmp_broadbandThermal(fileno=304,ifplot=0, ifplotfinal=0):
    
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    power = data['power']
    power = power.flatten()
    totprob = data['totprob']

    ave = np.size(totprob,0)
    
    
    amp = np.zeros([ave,np.size(totprob,1)])
    
    
    for m in np.arange(ave):
        for k in np.arange(np.size(totprob,1)):
            
            xdata = sweepparam.flatten()
            ydata = totprob[m,k,:]
            
            
            startpoint = [np.ptp(ydata), np.pi, 0.5]
            fitfunc = Osc;
            para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
            perr = np.sqrt(np.diag(pcov))
                     
            if ifplot:
                plt.figure()
                plt.plot(xdata, ydata, 'k.')
                plt.plot(xdata, fitfunc(xdata,*para), 'r-')
                plt.show()
            
            amp[m,k] = np.abs(para[0])
#        
        
    
    meanamp = np.mean(amp,axis=0)
    
    para = plot_thermal_photonDistribution(fileno=303, ifplot=0, ifplotfinal=0)
    photonnum = alphamodel(power,*para)
    if ifplotfinal:
        plt.figure()
        plt.plot(photonnum, meanamp, 'o')
        plt.xlabel('Photon number')
        plt.ylabel('Osc amp')
    
    return photonnum, meanamp

def plot_freqsweep_SNR(fileno=227, ifplot=0, ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    totxdata = data['totxdata']
    tothistg = data['tothistg']
    tothiste = data['tothiste']
    
    if fileno == 227:
        power1dB = np.arange(-35,-14,4)
        power = 10**(power1dB/10)
    elif fileno == 228:
        power1dB = np.arange(-35,-14,2)
        power = 10**(power1dB/10)
    else:
        power = data['power']
    
    freqrange = data['freqrange']
    ave =  data['ave']
    ave = ave[0,0]
    
    power =np.reshape(power,[np.size(power)])
    freqrange =np.reshape(freqrange,[np.size(freqrange)])
    
    SNR = np.zeros([ave,np.size(totxdata,1),np.size(totxdata,2)])
    
    
    for m in np.arange(ave):
        for k in np.arange(np.size(totxdata,1)):
            for l in np.arange(np.size(totxdata,2)):
            
                xdata = totxdata[m,k,l,:]
                ydata_g = tothistg[m,k,l,:]
                ydata_e = tothiste[m,k,l,:]
                
                
                
                startpoint = [np.max(ydata_g), 0, np.ptp(xdata)/4]
                fitfunc = Gaussian;
                para_g, pcov_g = opt.curve_fit(fitfunc, xdata, ydata_g, startpoint)
                perr_g = np.sqrt(np.diag(pcov_g))
                
                startpoint = [np.max(ydata_e), 0, np.ptp(xdata)/4]
                para_e, pcov_e = opt.curve_fit(fitfunc, xdata, ydata_e, startpoint)
                perr_e = np.sqrt(np.diag(pcov_e))
                
#                if ifplot:
#                    plt.figure()
#                    plt.plot(xdata, ydata_g, 'b.')
#                    plt.plot(xdata, ydata_e, 'r.')
#                    plt.plot(xdata, fitfunc(xdata,*para_g), 'b-')
#                    plt.plot(xdata, fitfunc(xdata,*para_e), 'r-')
#                    
#                    plt.show()
                
                SNR[m,k,l] = np.abs((para_e[1]-para_g[1]))/((np.abs(para_g[2])+np.abs(para_e[2]))/2)
        
    
    power = power/np.max(power)
    amp = np.sqrt(power)
    meanSNR = np.mean(SNR,axis=0)
    stdSNR = np.std(SNR, axis=0)
    
    slope = np.zeros(np.size(freqrange))
    
    for k in np.arange(np.size(slope)):
        startpoint = [0.1]
        ydata = meanSNR[:,k]
        xdata = amp
        fitfunc = Linear;
        para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
        perr = np.sqrt(np.diag(pcov))
        xd = np.linspace(0,np.max(xdata)*1.5,100)
        slope[k] = para[0]
    
#    print('slope is {}'.format(para[0]))
    
    if ifplot:
        plt.figure()
        plt.errorbar(amp, meanSNR, stdSNR, fmt='x')
        plt.plot(xd, fitfunc(xd,*para), 'k-')
        
        
        plt.ylabel('SNR')
        plt.xlabel('Drive amplitude')
        plt.ylim([0, np.max(SNR)*1.1])
        plt.xlim([0, np.max(amp)*1.1])
    #    plt.xlim([0, 0.4])
        autoscale_y(plt.gca())
    
    if ifplotfinal:
        plt.figure()
        plt.plot(freqrange*1e3, slope, 'x-')
        plt.xlabel('Freq (MHz)')
        plt.xlim([-5,5])        
    
    
    return freqrange, slope

def plot_freqsweep_efficiency(filenos=[236,234]):
    freqrange, slope = plot_freqsweep_SNR(fileno=filenos[0], ifplot=0, ifplotfinal=1)
    freqrange, sigma = plot_freqsweep_dephaseAmp(fileno=filenos[1], ifplot=0, ifplotfinal=1)
    
    efficiency = (slope * sigma)**2/4
    plt.figure()
    plt.plot(freqrange * 1e3, efficiency, 'x-')
    plt.ylim([0, 0.01])
    plt.xlabel('Freq (MHz)')
    plt.ylabel('Efficiency')

def plot_freqsweep_227to230():
    plt.figure()
    freqrange1, slope1 = plot_freqsweep_SNR(fileno=227, ifplotfinal=0)
    freqrange2, slope2 = plot_freqsweep_SNR(fileno=229, ifplotfinal=0)
    freqrange3, slope3 = plot_freqsweep_SNR(fileno=230, ifplotfinal=0)
    
    freqrange = np.stack([freqrange1,freqrange2,freqrange3]).flatten()
    slope = np.stack([slope1,slope2,slope3]).flatten()
    sindex = np.argsort(freqrange)
    freqrange = freqrange[sindex]
    slope = slope[sindex]
    plt.plot(freqrange*1e3, slope, 'x-')
    plt.xlabel('Freq (MHz)')
    plt.ylabel('SNR/power ratio')
    plt.xlim([-5,5]) 
    

def plot_powersweep_SNR_linearWithBg(fileno=64, ifplot=0, ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    totxdata = data['totxdata']
    tothistg = data['tothistg']
    tothiste = data['tothiste']
    power = data['power']
    
    ave =  data['ave']
    ave = ave[0,0]
    power =np.reshape(power,[np.size(power)])
    
    
#    print(10*np.log10(power))
    
    SNR = np.zeros([ave,np.size(totxdata,1)])
    
    
    for m in np.arange(ave):
        for k in np.arange(np.size(totxdata,1)):
            
            xdata = totxdata[m,k,:]
            ydata_g = tothistg[m,k,:]
            ydata_e = tothiste[m,k,:]
            
            
            
            startpoint = [np.max(ydata_g), 0, np.ptp(xdata)/4]
            fitfunc = Gaussian;
            para_g, pcov_g = opt.curve_fit(fitfunc, xdata, ydata_g, startpoint)
            perr_g = np.sqrt(np.diag(pcov_g))
            
            startpoint = [np.max(ydata_e), 0, np.ptp(xdata)/4]
            para_e, pcov_e = opt.curve_fit(fitfunc, xdata, ydata_e, startpoint)
            perr_e = np.sqrt(np.diag(pcov_e))
            
            if ifplot:
                plt.figure()
                plt.plot(xdata, ydata_g, 'b.')
                plt.plot(xdata, ydata_e, 'r.')
                plt.plot(xdata, fitfunc(xdata,*para_g), 'b-')
                plt.plot(xdata, fitfunc(xdata,*para_e), 'r-')
                
                plt.show()
            
            SNR[m,k] = np.abs((para_e[1]-para_g[1]))/((np.abs(para_g[2])+np.abs(para_e[2]))/2)
        
    
    power = power/np.max(power)
    amp = np.sqrt(power)
    meanSNR = np.mean(SNR,axis=0)
    stdSNR = np.std(SNR, axis=0)
    
#    for k in np.arange(ave):
#        plt.plot(power, SNR[k,:],'o')
    
    
    
    startpoint = [0.1, 0]
    ydata = meanSNR
    xdata = amp
    fitfunc = Linear_withbg;
    para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(0,np.max(xdata)*1.5,100)
    slope = para[0]
    
    print('slope is {}'.format(para[0]))
    
    if ifplotfinal:
        plt.figure()
        plt.errorbar(amp, meanSNR, stdSNR, fmt='x')
        plt.plot(xd, fitfunc(xd,*para), 'k-')
        
        
        plt.ylabel('SNR')
        plt.xlabel('Drive amplitude')
        plt.ylim([0, np.max(SNR)*1.1])
        plt.xlim([0, np.max(amp)*1.1])
    #    plt.xlim([0, 0.4])
        autoscale_y(plt.gca())
    
    return slope

def plot_powersweep_dephaseAmp(fileno=242,ifplot=0):
    
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    power = data['power']
    power = power.flatten()
    totprob = data['totprob']

    ave = np.size(totprob,0)
    
    
    amp = np.zeros([ave,np.size(totprob,1)])
    
    
    for m in np.arange(ave):
        for k in np.arange(np.size(totprob,1)):
            
            xdata = sweepparam.flatten()
            ydata = totprob[m,k,:]
            
            
            startpoint = [np.ptp(ydata), np.pi, 0.5]
            fitfunc = Osc;
            para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
            perr = np.sqrt(np.diag(pcov))
                     
            if ifplot:
                plt.figure()
                plt.plot(xdata, ydata, 'k.')
                plt.plot(xdata, fitfunc(xdata,*para), 'r-')
                plt.show()
            
            amp[m,k] = np.abs(para[0])
#        
    plt.figure()
    power = power/np.max(power)
    power = np.sqrt(power)
    meanamp = np.mean(amp,axis=0)
    stdamp = np.std(amp, axis=0)
#    for k in np.arange(ave):
#        plt.plot(power, amp[k,:],'o')
    
    plt.errorbar(power, meanamp, stdamp, fmt = 'x')        
    
    startpoint = [np.max(meanamp), 0.2]
    ydata = meanamp
    xdata = power
    fitfunc = Gaussian_zero;
    para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(0,np.max(xdata),100)
    plt.plot(xd, fitfunc(xd,*para), 'r-')
    
#    plt.plot(xd, fitfunc(xd,para[0],0.2), 'k-')
    
    print('sigma is {}'.format(para[1]))
    
    plt.ylabel('Osc amp')
    plt.xlabel('Drive amplitude')
#    plt.ylim([0, np.max(SNR)*1.1])
#    plt.xlim([0, np.max(power)*1.1])
#    plt.xlim([0, 0.4])
    autoscale_y(plt.gca())
    
def plot_freqsweep_dephaseAmp(fileno=231, ifplot=0, ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    power = data['power']
    power = power.flatten()
    totprob = data['totprob']

    freqrange = data['freqrange']
    freqrange = freqrange.flatten()
    
    ave = np.size(totprob,0)
    
    
    amp = np.zeros([ave,np.size(totprob,1),np.size(totprob,2)])
    
    
    for m in np.arange(ave):
        for k in np.arange(np.size(totprob,1)):
            for l in np.arange(np.size(totprob,2)):
            
                xdata = sweepparam.flatten()
                ydata = totprob[m,k,l,:]
                
                
                startpoint = [np.ptp(ydata), np.pi, 0.5]
                fitfunc = Osc;
                para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
                perr = np.sqrt(np.diag(pcov))
                         
#                if ifplot:
#                    plt.figure()
#                    plt.plot(xdata, ydata, 'k.')
#                    plt.plot(xdata, fitfunc(xdata,*para), 'r-')
#                    plt.show()
                
                amp[m,k,l] = np.abs(para[0])
      
    sigma = np.zeros(np.size(freqrange))    
#    print(sigma)
    for k in np.arange(np.size(freqrange)):
        
        power = power/np.max(power)
        poweramp = np.sqrt(power)
        meanamp = np.mean(amp,axis=0)
        stdamp = np.std(amp, axis=0)
    
               
    
        startpoint = [np.max(meanamp), 0.2]
        ydata = meanamp[:,k]
        xdata = poweramp
        fitfunc = Gaussian_zero;
        para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
        perr = np.sqrt(np.diag(pcov))
        sigma[k] = para[1]
#        print(sigma)
        
        if ifplot:
            plt.figure()
            plt.errorbar(poweramp, meanamp[:,k], stdamp[:,k], fmt = 'x') 
            xd = np.linspace(0,np.max(xdata),100)
            plt.plot(xd, fitfunc(xd,*para), 'r-')
            plt.ylabel('Osc amp')
            plt.xlabel('Drive amplitude')
            autoscale_y(plt.gca())
        

    if ifplotfinal:
        plt.figure()
        plt.plot(freqrange*1e3, 1/sigma, 'x-')
        plt.xlabel('Frequency (MHz)')
        plt.ylabel('1/Sigma')
        plt.xlim([-5,5])
        
    return freqrange, sigma

def plot_freqsweep_rabi(fileno=94, ifplot=0, ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    prob = data['prob']
    ssm = data['ssm']
    sweepparam = data['sweepparam']
    
    
    plt.figure()
    x = ssm[0,:]
    y = sweepparam[0,:]
    xd = np.append(x-(x[1]-x[0])/2,x[-1]+(x[1]-x[0])/2)
    yd = np.append(y-(y[1]-y[0])/2,y[-1]+(y[1]-y[0])/2)
    X, Y = np.meshgrid(xd, yd)

    print(np.shape(prob))
    plt.pcolormesh(X, Y, prob.T)
    
    plt.xlabel('SSM frequency (GHz)')
    plt.ylabel('Time (ns)')


def plot_freqsweep_ramsey(fileno=100, ifplot=0, ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    prob = data['prob']
    freq = data['freq']
    sweepparam = data['sweepparam']
    
    
    plt.figure()
    x = freq[0,:] 
    y = sweepparam[0,:]
    xd = np.append(x-(x[1]-x[0])/2,x[-1]+(x[1]-x[0])/2)
    yd = np.append(y-(y[1]-y[0])/2,y[-1]+(y[1]-y[0])/2)
    X, Y = np.meshgrid(xd, yd)

    print(np.shape(prob))
    plt.pcolormesh(X, Y, prob.T)
    
    plt.xlabel('frequency (GHz)')
    plt.ylabel('Time (ns)')
    
    T2 = np.zeros(np.size(freq))
    T2err = np.zeros(np.size(freq))
    for k in np.arange(np.size(freq)):
        xdata = sweepparam[0,:]
        fdata = prob[k,:]
        
        
        startpoint = [0.5, np.max(xdata)/2, np.min(fdata)]
        fitfunc = ExpDecay;
        para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
        perr = np.sqrt(np.diag(pcov))
        
        T2[k] = para[1]
        T2err[k] = perr[1]
        
        if ifplot:
            xd = np.linspace(0,np.max(xdata),200)
            fig = plt.figure()
            plt.plot(xdata, fdata, 'ko')
            plt.plot(xd, fitfunc(xd, *para), 'r-')
    
    plt.figure()
    plt.errorbar(freq[0,:], T2, T2err, fmt='ko-')
    plt.ylim([0,12])
    plt.plot([5.6185,5.6185], plt.gca().get_ylim(), 'b-')
    plt.plot([5.6067,5.6067], plt.gca().get_ylim(), 'r-')
    plt.plot(5.606*np.array([1,1]), plt.gca().get_ylim(), 'r--')
    plt.xlabel('Frequency (GHz)')
    plt.ylabel('T2* ($\mu$s)')
            

def plot_repeat_ramsey(fileno=1, ifplot=0, ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    totprob = data['totprob']
    repnum = data['repnum']
    sweepparam = data['sweepparam']
    
    
    plt.figure()
    x = sweepparam[0,:]
    y = np.arange(repnum)
    xd = np.append(x-(x[1]-x[0])/2,x[-1]+(x[1]-x[0])/2)
    yd = np.append(y-(y[1]-y[0])/2,y[-1]+(y[1]-y[0])/2)
    X, Y = np.meshgrid(xd, yd)

    plt.pcolormesh(X, Y, totprob)
    
    plt.xlabel('Time ($\mu$s)')
    plt.ylabel('data #')     

    

def plotrabisingle():
    fname = getsinglefile('016*')
    data = np.loadtxt(fname)
    xdata = data[:,0]
#    ydata = np.linspace(30,0,31)
    fdata = data[:,1]
    fig = plt.figure()
    plt.plot(xdata, fdata, 'o')
    startpoint = [0.5, 3/2/np.max(xdata), 0]
    fitfunc = RabiOsc;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    startpoint = [0.5, np.max(xdata)/2, 2/np.max(xdata), 0, 0.5, 1]
#    fitfunc = ExpOscDecay_n;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(0,np.max(xdata),200)
    plt.plot(xd, fitfunc(xd, *para), 'r-')
    print(para)
    print(perr)
    plt.xlabel('Time (ns)')
    plt.ylabel('$P_e$')

def plotT1single():
    fname = getsinglefile('148*')
    data = np.loadtxt(fname)
    xdata = data[:,0]
#    ydata = np.linspace(30,0,31)
    fdata = data[:,1]
    fig = plt.figure()
    plt.plot(xdata, fdata, 'ko')
    startpoint = [1, 1/2*np.max(xdata), fdata[-1]]
    fitfunc = ExpDecay;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    startpoint = [0.5, np.max(xdata)/2, 2/np.max(xdata), 0, 0.5, 1]
#    fitfunc = ExpOscDecay_n;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(0,np.max(xdata),200)
    plt.plot(xd, fitfunc(xd, *para), 'r-')
    print(para)
    print(perr)
    plt.xlabel('Time ($\mu$s)')
    plt.ylabel('$P_e$')
    
def plotramseysingle():
    fname = getsinglefile('158*')
    data = np.loadtxt(fname)
    xdata = data[:,0]
#    ydata = np.linspace(30,0,31)
    fdata = data[:,1]
    fig = plt.figure()
    plt.plot(xdata, fdata, 'ko')
    startpoint = [0.5, np.max(xdata)/2, np.min(fdata)]
    fitfunc = ExpDecay;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    startpoint = [0.5, np.max(xdata)/2, 2/np.max(xdata), 0, 0.5, 1]
#    fitfunc = ExpOscDecay_n;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(0,np.max(xdata),200)
    plt.plot(xd, fitfunc(xd, *para), 'r-')
    print(para)
    print(perr)
    plt.xlabel('Time ($\mu$s)')
    plt.ylabel('ch2 reading')
    
def plotramseysingle_osc():
    fname = getsinglefile('385*')
    data = np.loadtxt(fname)
    xdata = data[:,0]
#    ydata = np.linspace(30,0,31)
    fdata = data[:,1]
    fig = plt.figure()
    plt.plot(xdata, fdata, 'ko')
    startpoint = [np.ptp(fdata), np.max(xdata)/2, 6/np.max(xdata) ,0, np.mean(fdata)]
    fitfunc = ExpOscDecay;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    startpoint = [0.5, np.max(xdata)/2, 2/np.max(xdata), 0, 0.5, 1]
#    fitfunc = ExpOscDecay_n;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(0,np.max(xdata),200)
    plt.plot(xd, fitfunc(xd, *para), 'r-')
    print(para)
    print(perr)
    plt.xlabel('Time (ns)')
    plt.ylabel('Signal')
    
def plotramseysingle_coherentReadout():
    fname = getsinglefile('003*')
    data = np.loadtxt(fname)
    xdata = data[:,0]
#    ydata = np.linspace(30,0,31)
    fdata = data[:,1]
    fig = plt.figure()
    plt.plot(xdata, fdata, 'o')
    startpoint = [np.max(fdata)-np.min(fdata), np.max(xdata)/2, 1/0.1, 0, np.min(fdata)]
    fitfunc = ExpOscDecay;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    startpoint = [0.5, np.max(xdata)/2, 2/np.max(xdata), 0, 0.5, 1]
#    fitfunc = ExpOscDecay_n;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(0,np.max(xdata),200)
    plt.plot(xd, fitfunc(xd, *para), 'r-')
    print(para)
    print(perr)
    plt.xlabel('Time ($\mu$s)')
    plt.ylabel('FT signal')
    
def plotrabisingle_thermalReadout_ExpOscDecay():
    fname = getsinglefile('171*')
    data = np.loadtxt(fname)
    xdata = data[:,0]
#    ydata = np.linspace(30,0,31)
    fdata = data[:,1]
    fig = plt.figure()
    plt.plot(xdata, fdata, 'o')
    startpoint = [(np.max(fdata)-np.min(fdata))/2,1/2*np.max(xdata), 1/200, 0,(np.max(fdata)+np.min(fdata))/2]
    fitfunc = ExpOscDecay;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    startpoint = [0.5, np.max(xdata)/2, 2/np.max(xdata), 0, 0.5, 1]
#    fitfunc = ExpOscDecay_n;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(0,np.max(xdata),200)
    plt.plot(xd, fitfunc(xd, *para), 'r-')
    print(para)
    print(perr)
    plt.xlabel('Time (ns)')
    plt.ylabel('FT signal')

def plot_acStarkspectrum(fileno=261):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = np.loadtxt(fname)
    xdata = data[:,0]
    
    if fileno == 271:
        xdata = np.linspace(-0.07,0.03,101)
    ydata = data[:,1]
    
    
    
    maxnum = 6
    
    
    chiv = chi * 1.0
        
        
    peak = np.zeros(maxnum)
    
    sep = chiv/(2*np.pi)*2*1e-3
    width = sep/2
#    shift = -0.008 # for amp = 0.4
    shift = -0.0
    
    plt.figure()
    plt.plot(xdata, ydata, 'k.-')    
    plt.ylim(plt.gca().get_ylim())
    for k in np.arange(maxnum):
        plt.plot(np.array([1,1])*(-k)*chiv/(2*np.pi)*2*1e-3+shift, plt.gca().get_ylim(), 'r--')
    plt.xlabel('Detuning (GHz)')
    plt.ylabel('P$_e$')
        
        
    for k in np.arange(maxnum):
        
        
        index = np.where(np.logical_and.reduce
                         ((xdata>-k*sep-width+shift,
                           xdata<-k*sep+width+shift)))[0]
        bgindex = np.where((xdata>sep))[0]
        
        
        peak[k] = np.sum(ydata[index] - np.mean(ydata[bgindex]))
        
    avenum = np.sum(xdata * (ydata - np.mean(ydata[bgindex]))) / (-chi*2/(2*np.pi)*1e-3)
    alpha_num = np.sqrt(avenum)
    print([avenum, alpha_num])
    
    
    plt.figure()
    photonnum = np.arange(maxnum)
    plt.plot(photonnum, peak, 'o')
    startpoint = [1,1]
    fitfunc = coherentstate;
    para, pcov = opt.curve_fit(fitfunc, photonnum, peak, startpoint)
    
    xd = np.linspace(0, maxnum, 100)
    plt.plot(xd, coherentstate(xd, *para), 'r')
    plt.ylabel('Population')
    plt.xlabel('n')
    
    print(para[0])
    
    return xdata, ydata, peak


def plot_timeSweep_acStarkspectrum(fileno=7,ifplot=1,ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    sweepparam = sweepparam.flatten()
    start = data['start']
    start = start.flatten()
    totprob = data['totprob']
    
    totalpha = np.zeros(np.size(start))
    
    for m in np.arange(np.size(start)):
    
        ydata = totprob[m,:]
        xdata = sweepparam
        maxnum = 6
        
        chiv = chi * 1.0
            
        peak = np.zeros(maxnum)
        
        sep = chiv/(2*np.pi)*2*1e-3
        width = sep/3
        shift = -0.0
        
        plt.figure()
        plt.plot(xdata, ydata, 'k.-')    
        plt.ylim(plt.gca().get_ylim())
        for k in np.arange(maxnum):
            plt.plot(np.array([1,1])*(-k)*chiv/(2*np.pi)*2*1e-3+shift, plt.gca().get_ylim(), 'r--')
        plt.xlabel('Detuning (GHz)')
        plt.ylabel('P$_e$')
            
            
        for k in np.arange(maxnum):
            
            
            index = np.where(np.logical_and.reduce
                             ((xdata>-k*sep-width+shift,
                               xdata<-k*sep+width+shift)))[0]
            bgindex = np.where((xdata>sep))[0]
            
            
            peak[k] = np.sum(ydata[index] - np.mean(ydata[bgindex]))
            
#        avenum = np.sum(xdata * (ydata - np.mean(ydata[bgindex]))) / (-chi*2/(2*np.pi)*1e-3)
#        alpha_num = np.sqrt(avenum)
#        print([avenum, alpha_num])
        
        
        plt.figure()
        photonnum = np.arange(maxnum)
        plt.plot(photonnum, peak, 'o')
        startpoint = [1,1]
        fitfunc = coherentstate;
        para, pcov = opt.curve_fit(fitfunc, photonnum, peak, startpoint,bounds=(0,np.inf))
        
        xd = np.linspace(0, maxnum, 100)
        plt.plot(xd, coherentstate(xd, *para), 'r')
        plt.ylabel('Population')
        plt.xlabel('n')
        
        plt.title('alpha {}'.format(para[0]))
        
        totalpha[m] = para[0]
#        totalpha[m] = alpha_num
    
    if ifplotfinal:
        plt.figure()
        plt.plot(start, totalpha, 'k.-')
        plt.xlabel('Time')
        plt.ylabel('Alpha')
        plt.show()
        
    totphoton = np.sum((totalpha-0.15)**2 * kappa * 0.2)
    print(totphoton)
#    return xdata, ydata, peak
    
    
def plot_timeSweep_acStarkspectrum_GaussianFit(fileno=8,ifplot=1,ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    sweepparam = sweepparam.flatten()
    start = data['start']
    start = start.flatten()
    totprob = data['totprob']
    
    totalpha = np.zeros(np.size(start))
    totalphaErr = np.zeros(np.size(start))
    
    for m in np.arange(np.size(start)):
#    for m in np.arange(1):
    
        ydata = totprob[m,:]
        xdata = sweepparam
        maxnum = 6
        
        chiv = chi * 1.0
            
        peak = np.zeros(maxnum)
        
        sep = chiv/(2*np.pi)*2*1e-3
        width = sep/3
        shift = -0.0
        
        plt.figure()
        plt.plot(xdata, ydata, 'k.-')    
        plt.ylim(plt.gca().get_ylim())
        for k in np.arange(maxnum):
            plt.plot(np.array([1,1])*(-k)*chiv/(2*np.pi)*2*1e-3+shift, plt.gca().get_ylim(), 'r--')
        plt.xlabel('Detuning (GHz)')
        plt.ylabel('P$_e$')
            
        
        
        
        startpoint = [0,1,0.001,0]
        fitfunc = coherentstate_GaussianShape;
        para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint,bounds=(-0.3,np.inf))
        perr = np.sqrt(np.diag(pcov))
        xd = np.linspace(np.min(xdata), np.max(xdata), 200)
        plt.plot(xd, coherentstate_GaussianShape(xd, *para), 'r')
        plt.ylabel('Population')
        plt.xlabel('n')
        
        plt.title('alpha {}'.format(para[0]))
        
        totalpha[m] = para[0]
        totalphaErr[m] = perr[0]
#        totalpha[m] = alpha_num
    
    if ifplotfinal:
        plt.figure()
#        plt.errorbar(start, totalpha, 2*totalphaErr, fmt = 'ko-')
        plt.plot(start, totalpha, 'ko-')
        plt.xlabel('Time')
        plt.ylabel('Alpha')
        plt.show()
        
    totphoton = np.sum((totalpha[2:]-np.mean(totalpha[0:1]))**2 * kappa * 0.3)
#    totphoton = np.sum((totalpha[3:])**2 * kappa * 0.2)
    print(totphoton)
#    return xdata, ydata, peak
    
def plot_timeSweep_acStarkspectrum_GaussianFit_thermalState(fileno=23,ifplot=1,ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    sweepparam = sweepparam.flatten()
    start = data['start']
    start = start.flatten()
    totprob = data['totprob']
    
    totphoton = np.zeros(np.size(start))
    totphotonErr = np.zeros(np.size(start))
    
    for m in np.arange(np.size(start)):
#    for m in np.arange(1):
    
        ydata = totprob[m,:]
        xdata = sweepparam
        maxnum = 6
        
        chiv = chi * 1.0
            
        peak = np.zeros(maxnum)
        
        sep = chiv/(2*np.pi)*2*1e-3
        width = sep/3
        shift = -0.0
        
        plt.figure()
        plt.plot(xdata, ydata, 'k.-')    
        plt.ylim(plt.gca().get_ylim())
        for k in np.arange(maxnum):
            plt.plot(np.array([1,1])*(-k)*chiv/(2*np.pi)*2*1e-3+shift, plt.gca().get_ylim(), 'r--')
        plt.xlabel('Detuning (GHz)')
        plt.ylabel('P$_e$')
            
        
        
        
        startpoint = [0,1,0.001,0]
        fitfunc = thermalstate_GaussianShape;
        
        para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint,
                                   bounds=(0,10))
        
#        startpoint = [0,1,0.001,0.003,0]
#        fitfunc = thermalstate_GaussianShape_2width;
#        
#        
#        para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint,
#                                   bounds=((0,0,0,0,0),(3,3,0.01,0.01,0.1)))
        
        
        perr = np.sqrt(np.diag(pcov))
        xd = np.linspace(np.min(xdata), np.max(xdata), 200)
        plt.plot(xd, fitfunc(xd, *para), 'r')
        plt.ylabel('Population')
        plt.xlabel('n')
        
        
        plt.title('photon {}'.format(para[0]))
        plt.show()
        print(para)
        totphoton[m] = para[0]
        totphotonErr[m] = perr[0]
#        totalpha[m] = alpha_num
    
    if ifplotfinal:
        plt.figure()
#        plt.errorbar(start, totalpha, 2*totalphaErr, fmt = 'ko-')
        plt.plot(start, totphoton, 'ko-')
        plt.xlabel('Time')
        plt.ylabel('Alpha')
        plt.show()
        
    photonnum = np.sum(totphoton[2:] * kappa * 0.3)
#    totphoton = np.sum((totalpha[3:])**2 * kappa * 0.2)
    print(photonnum)
#    return xdata, ydata, peak
    
def plot_timeAmpSweep_acStarkspectrum_GaussianFit(fileno=14,ifplot=1,ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    sweepparam = sweepparam.flatten()
    start = data['start']
    start = start.flatten()
    amp = data['amp']
    amp = amp.flatten()
    totprob = data['totprob']
    
    totalpha = np.zeros(np.size(start))
    totalphaErr = np.zeros(np.size(start))
    
    totalnum = np.zeros(np.size(amp))
    
    for k in np.arange(np.size(amp)):
        for m in np.arange(np.size(start)):
        
            ydata = totprob[k,m,:]
            xdata = sweepparam
            maxnum = 6
            
            chiv = chi * 1.0
                
            peak = np.zeros(maxnum)
            
            sep = chiv/(2*np.pi)*2*1e-3
            width = sep/3
            shift = -0.0
            
           
                
            
            
            
            startpoint = [0,1,0.001,0]
            fitfunc = coherentstate_GaussianShape;
            para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint,bounds=(-0.3,np.inf))
            perr = np.sqrt(np.diag(pcov))
            xd = np.linspace(np.min(xdata), np.max(xdata), 200)
            
            if ifplot:
                
                plt.figure()
                plt.plot(xdata, ydata, 'k.-')    
                plt.ylim(plt.gca().get_ylim())
                for kn in np.arange(maxnum):
                    plt.plot(np.array([1,1])*(-kn)*chiv/(2*np.pi)*2*1e-3+shift, plt.gca().get_ylim(), 'r--')
                plt.xlabel('Detuning (GHz)')
                plt.ylabel('P$_e$')
                plt.plot(xd, coherentstate_GaussianShape(xd, *para), 'r')
                plt.ylabel('Population')
                plt.xlabel('n')
                
                plt.title('amp {:.2f}, time {} ns, alpha {:.2f}'.format(amp[k], start[m], para[0]))
                plt.show()
            
            totalpha[m] = para[0]
            totalphaErr[m] = perr[0]
    #        totalpha[m] = alpha_num
        
        if ifplotfinal:
            plt.figure()
#            plt.errorbar(start, totalpha, totalphaErr, fmt = 'ko-')
            plt.plot(start, totalpha, 'ko-')
            plt.xlabel('Time')
            plt.ylabel('Alpha')
            plt.show()
        
        duration  = 1e-3*(start[1]-start[0])
        totphoton = np.sum((totalpha[2:])**2 * kappa * duration)
    #    totphoton = np.sum((totalpha[3:])**2 * kappa * 0.2)
        print(totphoton)
        totalnum[k] = totphoton
        
    if ifplotfinal:
        plt.figure()
        plt.plot(amp**2, totalnum, 'ko-')
        plt.xlabel('power')
        plt.ylabel('photonNum')
        plt.show()
    print('Duration {}'.format(duration))
    return amp, totalnum

def plot_timeAmpSweep_acStarkspectrum_GaussianFit_thermal(fileno=25,ifplot=1,ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    sweepparam = sweepparam.flatten()
    start = data['start']
    start = start.flatten()
    att = data['att']
    print(att)
    att = att.flatten()
    power = 10**(-att/10)
    
    totprob = data['totprob']
    
    totphoton = np.zeros(np.size(start))
    totphotonErr = np.zeros(np.size(start))
    
    totalnum = np.zeros(np.size(power))
    
    print(np.size(power))
    print(np.shape(totphoton))
    for k in np.arange(np.size(power)):
        for m in np.arange(np.size(start)):
        
            ydata = totprob[k,m,:]
            xdata = sweepparam
            maxnum = 6
            
            chiv = chi * 1.0
                
            peak = np.zeros(maxnum)
            
            sep = chiv/(2*np.pi)*2*1e-3
            width = sep/3
            shift = -0.0
            
           
                
            
            
            
            startpoint = [0,1,0.001,0.003,0]
            fitfunc = thermalstate_GaussianShape_2width;
#            para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint,
#                                       bounds=((0,0,0,0,0),(10,10,0.01,0.01,0.1)))
            
            para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint,
                                       bounds=((0,0,0,0,0),(10,10,0.03,0.03,0.05)))
            
            if para[3] > 5*para[2]:
                para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint,
                                       bounds=((0,0,0,0,0),(10,10,0.01,0.01,0.05)))
                
            perr = np.sqrt(np.diag(pcov))
            xd = np.linspace(np.min(xdata), np.max(xdata), 200)
            
            if ifplot:
                
                plt.figure()
                plt.plot(xdata, ydata, 'k.-')    
                plt.ylim(plt.gca().get_ylim())
                for kn in np.arange(maxnum):
                    plt.plot(np.array([1,1])*(-kn)*chiv/(2*np.pi)*2*1e-3+shift, plt.gca().get_ylim(), 'r--')
                plt.xlabel('Detuning (GHz)')
                plt.ylabel('P$_e$')
                plt.plot(xd, fitfunc(xd, *para), 'r')
                plt.ylabel('Population')
                plt.xlabel('n')
                
                plt.title('power {:.2f}, time {} ns, alpha {:.2f}'.format(power[k], start[m], para[0]))
                plt.show()
            
            totphoton[m] = para[0]
            totphotonErr[m] = perr[0]
    #        totalpha[m] = alpha_num
        
        if ifplotfinal:
            plt.figure()
#            plt.errorbar(start, totalpha, totalphaErr, fmt = 'ko-')
            plt.plot(start, totphoton, 'ko-')
            plt.xlabel('Time')
            plt.ylabel('Alpha')
            plt.show()
        
        duration  = 1e-3*(start[1]-start[0])
        allphoton = np.sum(totphoton[2:] * kappa * duration)
        print(allphoton)
        totalnum[k] = allphoton
        
    if ifplotfinal:
        plt.figure()
        plt.plot(power, totalnum, 'ko-')
        plt.xlabel('power')
        plt.ylabel('photonNum')
        plt.show()
        plt.figure()
        plt.plot(att, totalnum, 'ko-')
        plt.xlabel('Attenuation')
        plt.ylabel('photonNum')
        plt.show()
    print('Duration {}'.format(duration))
    return power, totalnum

def compare_acStark_14():
    
    plt.figure()
    
    
    amp, totalnum = plot_timeAmpSweep_acStarkspectrum_GaussianFit(
            fileno=19,ifplot=0,ifplotfinal=0)
    plt.plot(amp**2, totalnum, 'go-')
    
    amp, totalnum = plot_timeAmpSweep_acStarkspectrum_GaussianFit(
            fileno=14,ifplot=0,ifplotfinal=0)
    
    
    plt.plot(amp**2, totalnum, 'ro-')
    
    amp, totalnum = plot_timeAmpSweep_acStarkspectrum_GaussianFit(
            fileno=15,ifplot=0,ifplotfinal=0)
    plt.plot(amp**2, totalnum, 'bo-')
    
    
    
    amp, totalnum = plot_timeAmpSweep_acStarkspectrum_GaussianFit(
            fileno=20,ifplot=0,ifplotfinal=0)
    plt.plot(amp**2, totalnum, 'co-')
    
    plt.xlabel('power')
    plt.ylabel('photon Num')
    
    plt.legend(['500 ns pulse','300 ns pulse','200 ns pulse','150 ns pulse'])
    
#    
def calculate_dephaseAmp_vs_photonNum():
    
    plt.figure()
    
    # Coherent
    para, fitfunc = plot_alpha_vs_amp(ifplot=0)
#   
    amp, dephaseAmp, dephaseAmpErr = plot_ampsweep_dephaseAmp(fileno=18,ifplot=0,ifplotfinal=0)
    photon = fitfunc(amp,*para)
    l1 = plt.errorbar(photon, dephaseAmp/np.max(dephaseAmp), 2*dephaseAmpErr/np.max(dephaseAmp), fmt = 'ko')
    
    n = np.linspace(0.01,10,80)
    amp = np.exp(-n/2)
    plt.plot(n, amp, 'k-')
    
    # Broadband thermal
    para, fitfunc = plot_photon_vs_power_thermal(ifplot=0)
    power, dephaseAmp, dephaseAmpErr = plot_ampsweep_dephaseAmp_thermal(fileno=26, ifplot=0, ifplotfinal=0)
    photon = fitfunc(power,*para)
    print(para)
    print(power)
    l2 = plt.errorbar(2*photon, dephaseAmp/np.max(dephaseAmp), 2*dephaseAmpErr/np.max(dephaseAmp), fmt = 'rx')
    
    n = np.linspace(0.01,10,80)
    amp = np.exp(-n/2)
    plt.plot(n, amp, 'r-')
    
    plt.xlabel('Photon Num')
    plt.ylabel('Dephasing Amp')
    
    # Single Photon
    angle, _, dephaseAmp = plot_anglesweep_dephaseAmp_old(fileno=0,ifplot=0,ifplotfinal=0)
    photon = np.sin(angle/2)**2
    l3, = plt.plot(photon, dephaseAmp/np.max(dephaseAmp), 'ys')
    theta = np.linspace(0,np.pi,100)
    n = np.sin(theta/2)**2
    amp  = np.cos(theta/2)
    plt.plot(n, amp, 'y-')
    
    
    
    # Mono thermal
    photon, dephaseAmp, dephaseAmpErr = plot_ampsweep_dephaseAmp_monothermal_justamp(
            fileno=18, ifplot=0, ifplotfinal=0)
    
    l4 = plt.errorbar(photon, dephaseAmp/np.max(dephaseAmp), 
                       2*dephaseAmpErr/np.max(dephaseAmp), fmt='gd')
    
#    n = np.linspace(0.01,10,80)
#    amp = np.exp(-np.sqrt(n)/2)
#    plt.plot(n, amp, 'g--')
    
    n = np.linspace(0.01,10,80)
    step = 0.01
    alphalist = np.arange(0,15,step) + step/2
    amp_monoThermal = np.zeros(np.size(n))
    
    for k in np.arange(np.size(n)):
        for m in np.arange(np.size(alphalist)):
            p = 1/(np.pi * n[k]) * np.exp(-alphalist[m]**2/n[k]) * ( 2 * 
                  np.pi * alphalist[m] * step)
            amp = np.exp(- alphalist[m]**2/2)
            amp_monoThermal[k] = amp_monoThermal[k] + amp * p
    plt.plot(n, amp_monoThermal, 'g')
    
    plt.legend([l1,l2,l3,l4],['coherent','broadband thermal','single photon','mono thermal'],
               loc='lower left',bbox_to_anchor=(1,0))
    
    plt.xlim([0, 8])
    
    plt.savefig('test.pdf',dpi=300,bbox_inches='tight')

    
def calculate_dephaseAmp_vs_photonNum_plotseparate(plotnum=1):
    
    plt.figure(figsize=(6,4.5))
    plt.rcParams.update({'font.size': 17})
    # Coherent
    
    
    para, fitfunc = plot_alpha_vs_amp(ifplot=0)
#   
    amp, dephaseAmp, dephaseAmpErr = plot_ampsweep_dephaseAmp(fileno=18,ifplot=0,ifplotfinal=0)
    photon = fitfunc(amp,*para)
    l1 = plt.errorbar(photon, dephaseAmp/np.max(dephaseAmp), 2*dephaseAmpErr/np.max(dephaseAmp), fmt = 'bo')
    
    n = np.linspace(0.01,10,80)
    amp = np.exp(-n/2)
    plt.plot(n, amp, 'b-')
    lgnum = [l1]
    lgname = ['coherent']
    
    n = np.linspace(0.01,10,80)
    amp = 1/(1+n)
    plt.plot(n, amp, 'k-')
    
    if plotnum > 1:
        # Mono thermal
        photon, dephaseAmp, dephaseAmpErr = plot_ampsweep_dephaseAmp_monothermal_justamp(
                fileno=18, ifplot=0, ifplotfinal=0)
        
        l2 = plt.errorbar(photon, dephaseAmp/np.max(dephaseAmp), 
                           2*dephaseAmpErr/np.max(dephaseAmp), fmt='gd')
        
    #    n = np.linspace(0.01,10,80)
    #    amp = np.sqrt(1/(n+1))
    #    plt.plot(n, amp, 'g--')
        
        n = np.linspace(0.01,10,80)
        step = 0.01
        alphalist = np.arange(0,15,step) + step/2
        amp_monoThermal = np.zeros(np.size(n))
        
        for k in np.arange(np.size(n)):
            for m in np.arange(np.size(alphalist)):
                p = 1/(np.pi * n[k]) * np.exp(-alphalist[m]**2/n[k]) * ( 2 * 
                      np.pi * alphalist[m] * step)
                amp = np.exp(- alphalist[m]**2/2)
                amp_monoThermal[k] = amp_monoThermal[k] + amp * p
        plt.plot(n, amp_monoThermal, 'g')
        
#        mono = 1/(1+n/2)
#        plt.plot(n, mono, 'r')
        
        lgnum = [l1, l2]
        lgname = ['coherent', 'mono. thermal']
        
        
    if plotnum > 2:
        # Broadband thermal
        
#        para, fitfunc = plot_photon_vs_power_thermal(ifplot=0)
#        power, dephaseAmp, dephaseAmpErr = plot_ampsweep_dephaseAmp_thermal(fileno=26, ifplot=0, ifplotfinal=0)
#        photon = fitfunc(power,*para)
#        print(para)
#        print(power)
#        l2 = plt.errorbar(2*photon, dephaseAmp/np.max(dephaseAmp), 2*dephaseAmpErr/np.max(dephaseAmp), fmt = 'rx')
        
        n = np.linspace(0.01,10,80)
        amp = np.exp(-n/2)
        plt.plot(n, amp, 'r-')
        
        para, fitfunc = plot_photon_vs_power_thermal(fileno=63, ifplot=0)
        power, dephaseAmp, dephaseAmpErr = plot_ampsweep_dephaseAmp_thermal(fileno=65, ifplot=0, ifplotfinal=0)
        photon = fitfunc(power,*para)
        l3 = plt.errorbar(2*photon, dephaseAmp/np.max(dephaseAmp), 2*dephaseAmpErr/np.max(dephaseAmp), fmt = 'rx')
        
        
        lgnum = [l1, l2, l3]
        lgname = ['coherent', 'mono. thermal', 'broadband thermal']
        
        
        
#        power, dephaseAmp, dephaseAmpErr = plot_ampsweep_dephaseAmp_thermal(fileno=64, ifplot=0, ifplotfinal=0)
#        power = power[:-2]
#        dephaseAmp = dephaseAmp[:-2]
#        dephaseAmpErr = dephaseAmpErr[:-2]
#        photon = get_photon_vs_power_thermal(power)
        
    
    # Single Photon
    if plotnum > 3:
#        angle, _, dephaseAmp = plot_anglesweep_dephaseAmp_old(fileno=0,ifplot=0,ifplotfinal=0)
        
        angle, dephaseAmp, dephaseAmperr = plot_anglesweep_dephaseAmp_withave(fileno=67,ifplot=0,ifplotfinal=0)
        print(dephaseAmp)
        photon = np.sin(angle/2)**2
        l4 = plt.errorbar(photon, dephaseAmp/np.max(dephaseAmp), 
                          2*dephaseAmperr/np.max(dephaseAmp), fmt='ys')
        theta = np.linspace(0,np.pi,100)
        n = np.sin(theta/2)**2
        amp  = np.cos(theta/2)
        plt.plot(n, amp, 'y-')
        lgnum = [l1, l2, l3, l4]
        lgname = ['coherent', 'mono. thermal', 'broadband thermal', 'single-photon']
    
    
    
    
    plt.xlabel('Emitted photon num')
    plt.ylabel('$|\\rho_{ge}(n)/\\rho_{ge}(0)|$')
    
#    plt.legend(lgnum,lgname,
#               loc='lower left',bbox_to_anchor=(1,0))

    plt.legend(lgnum,lgname,
               loc='upper right',frameon=False)
    
    
    plt.xlim([0, 8])
    plt.ylim([0, 1.1])
    
    plt.savefig('03_dephasing_all.pdf',dpi=300,bbox_inches='tight')
#    plt.rcParams.update({'ze': 1font.si3})
    
#    savename = 'dephasing_{}.pdf'.format(plotnum)
#    plt.savefig(savename,dpi=300,bbox_inches='tight')


def calculate_dephaseAmp_vs_photonNum_paper_SI():
    
    plt.figure(figsize=(6,4))
    plt.rcParams.update({'font.size': 14})
    # Coherent
    
    
    para, fitfunc = plot_alpha_vs_amp(ifplot=0)
#   
    amp, dephaseAmp, dephaseAmpErr = plot_ampsweep_dephaseAmp(fileno=18,ifplot=0,ifplotfinal=0)
    photon = fitfunc(amp,*para)
    l1 = plt.errorbar(photon, dephaseAmp/np.max(dephaseAmp), 
                      2*dephaseAmpErr/np.max(dephaseAmp), fmt = 'bo', mfc = 'w')
    
    n = np.linspace(0.01,10,80)
    amp = np.exp(-n/2)
    plt.plot(n, amp, 'b-')

    
   
        
    
    n = np.linspace(0.01,10,80)
    amp = np.exp(-n/2)
    plt.plot(n, amp, 'r-')
    
    para, fitfunc = plot_photon_vs_power_thermal(fileno=63, ifplot=0)
    power, dephaseAmp, dephaseAmpErr = plot_ampsweep_dephaseAmp_thermal(fileno=65, ifplot=0, ifplotfinal=0)
    photon = fitfunc(power,*para)
    l2 = plt.errorbar(2*photon, dephaseAmp/np.max(dephaseAmp), 2*dephaseAmpErr/np.max(dephaseAmp), fmt = 'rx')
    
    
        
    angle, dephaseAmp, dephaseAmperr = plot_anglesweep_dephaseAmp_withave(fileno=67,ifplot=0,ifplotfinal=0)
    print(dephaseAmp)
    photon = np.sin(angle/2)**2
    l3 = plt.errorbar(photon, dephaseAmp/np.max(dephaseAmp), 
                      2*dephaseAmperr/np.max(dephaseAmp), fmt='ys')
    theta = np.linspace(0,np.pi,100)
    n = np.sin(theta/2)**2
    amp  = np.cos(theta/2)
    plt.plot(n, amp, 'y-')
    
    
    
    
    
    photon, dephaseAmp, dephaseAmpErr = plot_ampsweep_dephaseAmp_monothermal_justamp(
                fileno=18, ifplot=0, ifplotfinal=0)
        
    l4 = plt.errorbar(photon, dephaseAmp/np.max(dephaseAmp), 
                       2*dephaseAmpErr/np.max(dephaseAmp), fmt='gd')
    

    
    n = np.linspace(0.01,10,80)
    step = 0.01
    alphalist = np.arange(0,15,step) + step/2
    amp_monoThermal = np.zeros(np.size(n))
    
    for k in np.arange(np.size(n)):
        for m in np.arange(np.size(alphalist)):
            p = 1/(np.pi * n[k]) * np.exp(-alphalist[m]**2/n[k]) * ( 2 * 
                  np.pi * alphalist[m] * step)
            amp = np.exp(- alphalist[m]**2/2)
            amp_monoThermal[k] = amp_monoThermal[k] + amp * p
    plt.plot(n, amp_monoThermal, 'g')


    
    
    lgnum = [l1, l2, l3, l4]
    lgname = ['coherent', 'thermal', 'single-photon', 'mono. thermal']
    
    
    
    
    plt.xlabel('$n^{\\mathrm{(emit)}}$')
    plt.ylabel('qubit coherence')
    
#    plt.legend(lgnum,lgname,
#               loc='lower left',bbox_to_anchor=(1,0))

    plt.legend(lgnum,lgname,
               loc='upper right',frameon=False)
    
    
    plt.xlim([0, 8])
    plt.ylim([0, 1.1])
    
    plt.savefig('03_SI_dephasing_all.pdf',dpi=300,bbox_inches='tight')
#    plt.rcParams.update({'ze': 1font.si3})
    
#    savename = 'dephasing_{}.pdf'.format(plotnum)
#    plt.savefig(savename,dpi=300,bbox_inches='tight')
    
    
def calculate_dephaseAmp_vs_photonNum_paper():
    
    plt.figure(figsize=(6,4.5))
    plt.rcParams.update({'font.size': 18})
    # Coherent
    
    
    para, fitfunc = plot_alpha_vs_amp(ifplot=0)
#   
    amp, dephaseAmp, dephaseAmpErr = plot_ampsweep_dephaseAmp(fileno=18,ifplot=0,ifplotfinal=0)
    photon = fitfunc(amp,*para)
    l1 = plt.errorbar(photon, dephaseAmp/np.max(dephaseAmp),
                      dephaseAmpErr/np.max(dephaseAmp), fmt = 'bo', mfc='w')
    
    n = np.linspace(0.01,10,80)
    amp = np.exp(-n/2)
    plt.plot(n, amp, 'b-')

    
   
        
    
    n = np.linspace(0.01,10,80)
    amp = np.exp(-n/2)
    plt.plot(n, amp, 'r-')
    
    para, fitfunc = plot_photon_vs_power_thermal(fileno=63, ifplot=0)
    power, dephaseAmp, dephaseAmpErr = plot_ampsweep_dephaseAmp_thermal(fileno=65, ifplot=0, ifplotfinal=0)
    photon = fitfunc(power,*para)
    l2 = plt.errorbar(2*photon, dephaseAmp/np.max(dephaseAmp), dephaseAmpErr/np.max(dephaseAmp), fmt = 'rx')
    
    
        
    angle, dephaseAmp, dephaseAmperr = plot_anglesweep_dephaseAmp_withave(fileno=67,ifplot=0,ifplotfinal=0)
    print(dephaseAmp)
    photon = np.sin(angle/2)**2
    l3 = plt.errorbar(photon, dephaseAmp/np.max(dephaseAmp), 
                      dephaseAmperr/np.max(dephaseAmp), fmt='ys')
    theta = np.linspace(0,np.pi,100)
    n = np.sin(theta/2)**2
    amp  = np.cos(theta/2)
    plt.plot(n, amp, 'y-')
    
    
    data = io.loadmat('folder05_short_thermal.mat')
    photon = np.ndarray.flatten(data['photon'])
    dephaseAmp = np.ndarray.flatten(data['dephaseAmp'])
    dephaseAmpErr = np.ndarray.flatten(data['dephaseAmpErr'])
    stopindex = -5
    l4 = plt.errorbar(2*photon[0:stopindex], dephaseAmp[0:stopindex]/np.max(dephaseAmp), 
                      dephaseAmpErr[0:stopindex]/np.max(dephaseAmp), fmt = 'gd')
    
    n = np.linspace(0.01,10,80)
    amp = 1/(1+n/2)
    plt.plot(n, amp, 'g--')
    
    
    lgnum = [l1, l2, l3, l4]
    lgname = ['coherent', 'thermal', 'single-photon', 'thermal (short)']
    
    
    
    
    plt.xlabel('$n^{\\mathrm{(emit)}}$')
    plt.ylabel('qubit coherence')
    
#    plt.legend(lgnum,lgname,
#               loc='lower left',bbox_to_anchor=(1,0))

    plt.legend(lgnum,lgname,
               loc='upper right',frameon=False)
    
    
    plt.xlim([0, 8])
    plt.ylim([0, 1.1])
    
    plt.savefig('03_dephasing_all.pdf',dpi=300,bbox_inches='tight')


def plot_SI_fig_AcStark():
    plt.rcParams.update({'font.size': 14})
    
    fileno = 63
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    sweepparam = sweepparam.flatten()
    start = data['start']
    start = start.flatten()

    totprob = data['totprob']
    
    att = data['att']
    att = att.flatten()
    power = 10**(-att/10)
    
    
    
    totalpha = np.zeros(np.size(start))
    totalphaErr = np.zeros(np.size(start))
    
    totalnum = np.zeros(np.size(power))
    
    print(power)
    print(start)
    
    k = np.size(power)-5
    m = 12
        
    ydata = totprob[k,m,:]
    xdata = sweepparam
    maxnum = 6
    
    chiv = chi * 1.0
        
    peak = np.zeros(maxnum)
    
    sep = chiv/(2*np.pi)*2*1e-3
    width = sep/3
    shift = -0.0
    
   
        
    
    
    
    startpoint = [0,1,0.001,0.003,0]
    fitfunc = thermalstate_GaussianShape_2width;   
    para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint,
                                       bounds=((0,0,0,0,0),(10,10,0.03,0.03,0.05)))
            
    if para[3] > 5*para[2]:
        para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint,
                               bounds=((0,0,0,0,0),(10,10,0.01,0.01,0.05)))
        
    print(para)
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(np.min(xdata), np.max(xdata), 200)
    
        
    plt.figure(figsize=(4.5,2.5))
    plt.plot(1e3*xdata, ydata, 'ko', ms =4)    
    plt.plot(1e3*xd, thermalstate_GaussianShape_2width(xd, *para), 'r')
    plt.ylim(plt.gca().get_ylim())
    plt.ylim([0.01,0.135])
    for kn in np.arange(maxnum):
        plt.plot(1e3*np.array([1,1])*(-kn)*chiv/(2*np.pi)*2*1e-3+shift, plt.gca().get_ylim(), 'r--')
    plt.xlabel('Detuning (MHz)')
    plt.ylabel('$P_e$')
    
#    plt.ylabel('Population')
#    plt.xlabel('n')
    plt.xlim([1e3*np.min(xd), 1e3*np.max(xd)])
    plt.savefig('03_SI_acstark_spectrum.pdf',dpi=300,bbox_inches='tight')
   
    
def plot_SI_fig_AcStark_within():
    plt.rcParams.update({'font.size': 14})
    fileno = 63
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    sweepparam = sweepparam.flatten()
    start = data['start']
    start = start.flatten()

    totprob = data['totprob']
    
    att = data['att']
    att = att.flatten()
    power = 10**(-att/10)
    
    
    
    totalpha = np.zeros(np.size(start))
    totalphaErr = np.zeros(np.size(start))
    
    totalnum = np.zeros(np.size(power))
    
    print(power)
    print(start)
    
    k = np.size(power)-5
    m = 10
        
    ydata = totprob[k,m,:]
    xdata = sweepparam
    maxnum = 6
    
    chiv = chi * 1.0
        
    peak = np.zeros(maxnum)
    
    sep = chiv/(2*np.pi)*2*1e-3
    width = sep/3
    shift = -0.0
    
   
        
    
    
    
    startpoint = [0,1,0.001,0.003,0]
    fitfunc = thermalstate_GaussianShape_2width;   
    para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint,
                                       bounds=((0,0,0,0,0),(10,10,0.03,0.03,0.05)))
            
    if para[3] > 5*para[2]:
        para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint,
                               bounds=((0,0,0,0,0),(10,10,0.01,0.01,0.05)))
        
    print(para)
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(np.min(xdata), np.max(xdata), 200)
    
        
    plt.figure(figsize=(4.5,2.5))
    plt.plot(1e3*xdata, ydata, 'ko', ms =4)    
    plt.plot(1e3*xd, thermalstate_GaussianShape_2width(xd, *para), 'r')
    plt.ylim(plt.gca().get_ylim())
    plt.ylim([0.01,0.09])
    for kn in np.arange(maxnum):
        plt.plot(1e3*np.array([1,1])*(-kn)*chiv/(2*np.pi)*2*1e-3+shift, plt.gca().get_ylim(), 'r--')
    plt.xlabel('Detuning (MHz)')
    plt.ylabel('$P_e$')
    
#    plt.ylabel('Population')
#    plt.xlabel('n')
    plt.xlim([1e3*np.min(xd), 1e3*np.max(xd)])
    plt.savefig('03_SI_acstark_spectrum_within2us.pdf',dpi=300,bbox_inches='tight')
    
def plot_SI_AcStark_full():
    fileno=63
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    sweepparam = sweepparam.flatten()
    start = data['start']
    start = start.flatten()
    
    att = data['att']
    att = att.flatten()
    power = 10**(-att/10)
    
    totprob = data['totprob']
    
#    totalpha = np.zeros(np.size(start))
#    totalphaErr = np.zeros(np.size(start))
    avenum = np.zeros(np.size(start))
    totalnum = np.zeros(np.size(power))
    
    for k in np.arange(np.size(power)):
        for m in np.arange(np.size(start)):
        
            ydata = totprob[k,m,:]
            xdata = sweepparam
            maxnum = 6
            
            chiv = chi * 1.0
                
            peak = np.zeros(maxnum)
            
            sep = chiv/(2*np.pi)*2*1e-3
            width = sep/3
            shift = -0.0
            
           
                
            
            
            
            startpoint = [0,1,0.001,0.003,0]
            fitfunc = thermalstate_GaussianShape_2width;   
            para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint,
                                               bounds=((0,0,0,0,0),(10,10,0.03,0.03,0.05)))
                    
            if para[3] > 5*para[2]:
                para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint,
                                       bounds=((0,0,0,0,0),(10,10,0.01,0.01,0.05)))
                
            xd = np.linspace(np.min(xdata), np.max(xdata), 200)
            
                        
            avenum[m] = para[0]
            
            
    #        totalpha[m] = alpha_num
        
        if k == np.size(power)-5:
            plt.figure(figsize=(4.5,2.5))
            plt.plot(start, avenum, 'ko-')
            plt.xlabel('t (ns)')
            plt.ylabel('$n^{(\\mathrm{c})}$')
#            plt.ylim([0, 1.6 ])
            plt.xlim([np.min(start), np.max(start)])
            plt.savefig('03_SI_photon_vs_time.pdf',dpi=300,bbox_inches='tight')
            
            
            plt.show()
        
        duration  = 1e-3*(start[1]-start[0])
        totphoton = np.sum(avenum[2:] * kappa * duration)
    #    totphoton = np.sum((totalpha[3:])**2 * kappa * 0.2)
        print(totphoton)
        totalnum[k] = totphoton
        
    
    plt.figure(figsize=(4.5,2.5))
    
    xdata = power
    fdata = totalnum
 
    startpoint = [60,1]
    fitfunc = photonmodel;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    xd = np.linspace(0,0.3,100)
    
    plt.plot(power/np.max(power), totalnum, 'ko')
    plt.plot(xd/np.max(power), fitfunc(xd,*para), 'r-')
    
    plt.xlim([0, 1.1])
#    plt.ylim([0, 12.5 ])
    plt.xlabel('$P_{\\mathrm{in}}$ (arb. unit)')
    plt.ylabel('$n^{(\\mathrm{emit})}$')
    plt.savefig('03_SI_photon_vs_power.pdf',dpi=300,bbox_inches='tight')
        
        
    plt.show()

def plot_fig2_AcStark():
    
    plt.rcParams.update({'font.size': 20})
    
    fileno = 15
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    sweepparam = sweepparam.flatten()
    start = data['start']
    start = start.flatten()
    amp = data['amp']
    amp = amp.flatten()
    totprob = data['totprob']
    
    totalpha = np.zeros(np.size(start))
    totalphaErr = np.zeros(np.size(start))
    
    totalnum = np.zeros(np.size(amp))
    print(amp)
    print(start)
    k = np.size(amp)-3
    m = 6
        
    ydata = totprob[k,m,:]
    xdata = sweepparam
    maxnum = 6
    
    chiv = chi * 1.0
        
    peak = np.zeros(maxnum)
    
    sep = chiv/(2*np.pi)*2*1e-3
    width = sep/3
    shift = -0.0
    
   
        
    
    
    
    startpoint = [0,1,0.001,0]
    fitfunc = coherentstate_GaussianShape;
    para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint,bounds=(-0.3,np.inf))
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(np.min(xdata), np.max(xdata), 200)
    
        
    plt.figure(figsize=(4.5,2))
    plt.plot(1e3*xdata, ydata, 'ko', ms =4)    
    plt.ylim(plt.gca().get_ylim())
    for kn in np.arange(maxnum):
        plt.plot(1e3*np.array([1,1])*(-kn)*chiv/(2*np.pi)*2*1e-3+shift, plt.gca().get_ylim(), 'r--')
    plt.xlabel('Detuning (MHz)')
    plt.ylabel('P$_e$')
    plt.plot(1e3*xd, coherentstate_GaussianShape(xd, *para), 'r')
#    plt.ylabel('Population')
#    plt.xlabel('n')
    plt.xlim([1e3*np.min(xd), 1e3*np.max(xd)])
    plt.savefig('03_acstark_spectrum.pdf',dpi=300,bbox_inches='tight')
   
    
    
def plot_fig2_AcStark_full():
    plt.rcParams.update({'font.size': 20})
    
    fileno=15
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    sweepparam = sweepparam.flatten()
    start = data['start']
    start = start.flatten()
    amp = data['amp']
    amp = amp.flatten()
    totprob = data['totprob']
    
    totalpha = np.zeros(np.size(start))
    totalphaErr = np.zeros(np.size(start))
    
    totalnum = np.zeros(np.size(amp))
    
    for k in np.arange(np.size(amp)):
        for m in np.arange(np.size(start)):
        
            ydata = totprob[k,m,:]
            xdata = sweepparam
            maxnum = 6
            
            chiv = chi * 1.0
                
            peak = np.zeros(maxnum)
            
            sep = chiv/(2*np.pi)*2*1e-3
            width = sep/3
            shift = -0.0
            
           
                
            
            
            
            startpoint = [0,1,0.001,0]
            fitfunc = coherentstate_GaussianShape;
            para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint,bounds=(-0.3,np.inf))
            perr = np.sqrt(np.diag(pcov))
            xd = np.linspace(np.min(xdata), np.max(xdata), 200)
            
                        
            totalpha[m] = para[0]
            totalphaErr[m] = perr[0]
    #        totalpha[m] = alpha_num
        
        if k == np.size(amp)-3:
            plt.figure(figsize=(4.5,2))
            plt.plot(start, totalpha**2, 'ko-')
            plt.xlabel('$t$ (ns)')
            plt.ylabel('$n^{\\mathrm{(c)}}$')
#            plt.ylim([0, 1.6 ])
            plt.xlim([np.min(start), np.max(start)])
            plt.savefig('03_photon_vs_time.pdf',dpi=300,bbox_inches='tight')
            
            
            plt.show()
        
        duration  = 1e-3*(start[1]-start[0])
        totphoton = np.sum((totalpha[2:])**2 * kappa * duration)
    #    totphoton = np.sum((totalpha[3:])**2 * kappa * 0.2)
        print(totphoton)
        totalnum[k] = totphoton
        
    
    print('Total photon number is {}'.format(totalnum[np.size(amp)-3]))
    plt.figure(figsize=(4.5,2))
    
    xdata = amp
    fdata = totalnum
 
    startpoint = [20,1]
    fitfunc = alphamodel;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    xd = np.linspace(0,1.5,100)
    
    plt.plot(amp**2/np.max(amp**2), totalnum, 'ko')
    plt.plot(xd**2/np.max(amp**2), fitfunc(xd,*para), 'r-')
    
    plt.xlim([0, 1.1])
#    plt.ylim([0, 12.5 ])
    plt.xlabel('$P_{\\mathrm{in}}$ (arb. unit)')
    plt.ylabel('$n^{\\mathrm{(emit)}}$')
    plt.savefig('03_photon_vs_power.pdf',dpi=300,bbox_inches='tight')
    plt.show()
    

def plot_fig3_oscillation():
    plt.rcParams.update({'font.size': 14})
    para, fitfunc = plot_alpha_vs_amp(ifplot=0)
    
    fileno=18
    
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    amp = data['amp']
    amp = amp.flatten()
    totprob = data['totprob']
    print(np.shape(totprob))
    ave = np.size(totprob,0)
    
    
    photon = fitfunc(amp,*para)
    print(photon)
    
    dephaseAmp = np.zeros([ave, np.size(totprob,1)])
    
    m = 0
    
    plt.figure(figsize=(2,1.1))
    
    colors = ['r','b','g','k']
    
    plotno = np.array([0,4,8,15])
    
    print(photon[plotno])
    for l in np.arange(np.size(plotno)):
        k = plotno[l]
#            print(k)
        xdata = sweepparam.flatten()
        ydata = totprob[m,k,:]
        
        
        startpoint = [np.ptp(ydata), np.pi, 0.5]
        fitfunc = Osc;
        para, pcov = opt.curve_fit(fitfunc, xdata, ydata, startpoint)
        perr = np.sqrt(np.diag(pcov))
         
        
        plt.plot(xdata, ydata, '.', color = colors[l],ms=3)
        plt.plot(xdata, fitfunc(xdata,*para), '-', color = colors[l])

        
        dephaseAmp[m,k] = np.abs(para[0])
        
    plt.xlim([0, 2*np.pi])
    plt.xlabel('Phase')
    plt.ylabel('$P_e$')
    plt.xticks([0, np.pi, 2*np.pi], ['0', '$\\pi$', '$2\\pi$'])
    
    plt.savefig('03_dephasing_osc.pdf',dpi=300,bbox_inches='tight')
        
    
def calculate_dephaseAmp_vs_photonNum_coherentstate():
    
    plt.figure()
    
    # Coherent
    para, fitfunc = plot_alpha_vs_amp(fileno=31, ifplot=0)
#   
    amp, dephaseAmp, dephaseAmpErr = plot_ampsweep_dephaseAmp(fileno=30,ifplot=0,ifplotfinal=0)
    photon = fitfunc(amp,*para)
    l1 = plt.errorbar(photon, dephaseAmp/np.max(dephaseAmp), 2*dephaseAmpErr/np.max(dephaseAmp), fmt = 'ko')
    
    n = np.linspace(0.01,10,80)
    amp = np.exp(-n/2)
    plt.plot(n, amp, 'k-')
    
        
    plt.xlim([0, 8])
    
#    plt.savefig('test.pdf',dpi=300,bbox_inches='tight')
   
    
def plot_SNR_vs_photonNum():
    
    
    plt.figure()
    
    photonnum, meanSNR, stdSNR = plot_ampsweep_SNR_coherent(
            fileno=47, ifplot=0, ifplotamp=0, ifplotfinal=0)
    
    l1 = plt.errorbar(photonnum, meanSNR, 2*stdSNR, fmt = 'ko',mfc='w')
    
#    photonnum, meanSNR, stdSNR = plot_ampsweep_SNR_coherent(
#            fileno=69, ifplot=0, ifplotamp=0, ifplotfinal=0)
#    
#    plt.errorbar(photonnum, meanSNR, 2*stdSNR, fmt = 'go')
    
#    index = np.where(photonnum<12)
#    xdata = photonnum[index]
#    fdata = meanSNR[index]
#    startpoint = [1]
#    fitfunc = squareroot;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    xd = np.linspace(0,12,100)
#    plt.plot(xd, fitfunc(xd,*para), 'k')
#    
    
    photonnum, meanSNR, stdSNR = plot_ampsweep_SNR_coherent(
            fileno=56, ifplot=0, ifplotamp=0, ifplotfinal=0)
    
    index = np.where(photonnum>1)
    
    l4 = plt.errorbar(photonnum[index], meanSNR[index], 2*stdSNR[index], fmt = 'co')
    
    
#    index = np.where(photonnum<12)
#    xdata = photonnum[index]
#    fdata = meanSNR[index]
#    startpoint = [1]
#    fitfunc = squareroot;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    xd = np.linspace(0,12,100)
#    plt.plot(xd, fitfunc(xd,*para), 'c')
    
#    photonnum, meanSNR, stdSNR = plot_ampsweep_SNR_coherent(
#            fileno=57, ifplot=0, ifplotamp=0, ifplotfinal=0)
#    
#    plt.errorbar(photonnum, meanSNR, 2*stdSNR, fmt = 'gx')
    

    photonnum, meanSNR, stdSNR = plot_powersweep_SNR_thermal_photonNumber(
            fileno=52, ifplot=0, ifplotfinal=0)

    index = np.where(photonnum>0.6)
    
    l2 = plt.errorbar(2*photonnum[index], meanSNR[index], 2*stdSNR[index], fmt = 'rx')
    
#    index = np.where(np.logical_and(photonnum>0.6,photonnum<12))
#    xdata = 2*photonnum[index[0]]
#    fdata = meanSNR[index[0]]
#    startpoint = [1]
#    fitfunc = squareroot;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    xd = np.linspace(0,12,100)
#    plt.plot(xd, fitfunc(xd,*para), 'r')
    
    [n, meanSNR, stdSNR, meanSNR_correct, 
     stdSNR_correct] = plot_ampsweep_SNR_thermalState(fileno=33, 
     ifplot=0, ifplotamp=0, ifplotfinal=0)
    
    l3 = plt.errorbar(n, meanSNR, 2*stdSNR, fmt='gs', mfc='w')
    
    [n, meanSNR, stdSNR] = plot_ampsweep_SNR_monothermalState_FTmethod(
           fileno=37, ifplot=0, ifplotamp=0, ifplotfinal=0)
    
    
    l5 = plt.errorbar(n, meanSNR, 2*stdSNR, fmt='gs')
    
#    xdata = n
#    fdata = meanSNR
#    startpoint = [1]
#    fitfunc = squareroot;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    xd = np.linspace(0,12,100)
#    plt.plot(xd, fitfunc(xd,*para), 'g')
#    
#    l4 = plt.errorbar(n, meanSNR_correct, 2*stdSNR_correct, fmt='s',color='b',mfc='w')
#    
#    xdata = n
#    fdata = meanSNR_correct
#    startpoint = [1]
#    fitfunc = squareroot;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    xd = np.linspace(0,12,100)
#    plt.plot(xd, fitfunc(xd,*para), 'b')
    
    plt.xlabel('Photon number')
    plt.ylabel('SNR')
    plt.xlim([0, 12])
    
    
    
    
    
    lgnum = [l1,l2,l3,l4, l5]
    lgname = ['coherent','broad thermal FT','mono thermal','coherent FT','mono thermal FT']
#    plt.legend(lgnum,lgname, loc='lower right')
#    plt.legend(lgnum,lgname, loc='lower left',bbox_to_anchor=(1,0))
    plt.legend(lgnum,lgname, bbox_to_anchor=(0., 1.02, 1., .102), loc='lower left',
           ncol=2, mode="expand", borderaxespad=0.)
    autoscale_y(plt.gca())
    
    plt.savefig('SNR.pdf',dpi=300,bbox_inches='tight')
  
    
def plot_SNR_vs_photonNum_paper():
    
    
    plt.figure(figsize=(6*1.1,4.2*1.1))
    plt.rcParams.update({'font.size': 15})
    # coherent homodyne
    
    photonnum, meanSNR, stdSNR = plot_ampsweep_SNR_coherent(
            fileno=47, ifplot=0, ifplotamp=0, ifplotfinal=0)
    
    l1 = plt.errorbar(photonnum, meanSNR, 2*stdSNR, fmt = 'ko',mfc='w')
    

    # coherent FT
    
    photonnum, meanSNR, stdSNR = plot_ampsweep_SNR_coherent(
            fileno=56, ifplot=0, ifplotamp=0, ifplotfinal=0)
    
    index = np.where(photonnum>1)
    
    l2 = plt.errorbar(photonnum[index], meanSNR[index], 2*stdSNR[index], fmt = 'co')
    
    

    # broadband thermal
    
    photonnum, meanSNR, stdSNR = plot_powersweep_SNR_thermal_photonNumber(
            fileno=52, ifplot=0, ifplotfinal=0)

    index = np.where(photonnum>0.6)
    
    l3 = plt.errorbar(2*photonnum[index], meanSNR[index], 2*stdSNR[index], fmt = 'rx')
    

    
    # mono thermal homodyne
#    [n, meanSNR, stdSNR, meanSNR_correct, 
#     stdSNR_correct] = plot_ampsweep_SNR_thermalState(fileno=33, 
#     ifplot=0, ifplotamp=0, ifplotfinal=0)
#    
#    l3 = plt.errorbar(n, meanSNR, 2*stdSNR, fmt='gs', mfc='w')
    
    
    # mono thermal FT
    [n, meanSNR, stdSNR] = plot_ampsweep_SNR_monothermalState_FTmethod(
           fileno=37, ifplot=0, ifplotamp=0, ifplotfinal=0)
    
    
    l4 = plt.errorbar(n, meanSNR, 2*stdSNR, fmt='gs')
    
#    xdata = n
#    fdata = meanSNR
#    startpoint = [1]
#    fitfunc = squareroot;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    xd = np.linspace(0,12,100)
#    plt.plot(xd, fitfunc(xd,*para), 'g')
#    
#    l4 = plt.errorbar(n, meanSNR_correct, 2*stdSNR_correct, fmt='s',color='b',mfc='w')
#    
#    xdata = n
#    fdata = meanSNR_correct
#    startpoint = [1]
#    fitfunc = squareroot;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    xd = np.linspace(0,12,100)
#    plt.plot(xd, fitfunc(xd,*para), 'b')
    
    plt.xlabel('Emitted photon number')
    plt.ylabel('SNR')
    plt.xlim([0, 12])
    
    
    
    
    
    lgnum = [l1,l2,l3,l4]
    lgname = ['coherent homodyne','coherent FT','broad thermal','mono thermal']
#    plt.legend(lgnum,lgname, loc='lower right')
#    plt.legend(lgnum,lgname, loc='lower left',bbox_to_anchor=(1,0))
    plt.legend(lgnum,lgname, bbox_to_anchor=(0., 1.02, 1., .102), loc='lower left',
           ncol=2, mode="expand", borderaxespad=0.)
    autoscale_y(plt.gca())
    
    plt.savefig('SNR.pdf',dpi=300,bbox_inches='tight')
    
def plot_SNR_vs_photonNum_paper_single():
    
    
    plt.figure(figsize=(6,4))
    plt.rcParams.update({'font.size': 14.})
    # coherent homodyne
    
    photonnum, meanSNR, stdSNR = plot_ampsweep_SNR_coherent(
            fileno=47, ifplot=0, ifplotamp=0, ifplotfinal=0)
    
    l1 = plt.errorbar(photonnum, meanSNR, 2*stdSNR, fmt = 'ko',mfc='w')
    
    xdata = photonnum
    fdata = meanSNR
    startpoint = [1]
    fitfunc = squareroot;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    eff = para[0]/np.sqrt(2)
    print('efficiency is {}'.format(para[0]/np.sqrt(2)))
    xd = np.linspace(0,12,100)
    plt.plot(xd, fitfunc(xd,*para), 'k')
    # coherent FT
    
#    photonnum, meanSNR, stdSNR = plot_ampsweep_SNR_coherent(
#            fileno=56, ifplot=0, ifplotamp=0, ifplotfinal=0)
#    
#    index = np.where(photonnum>1)
#    
#    l2 = plt.errorbar(photonnum[index], meanSNR[index], 2*stdSNR[index], fmt = 'co')
    
    

    # broadband thermal
    
    photonnum, meanSNR, stdSNR = plot_powersweep_SNR_thermal_photonNumber(
            fileno=52, ifplot=0, ifplotfinal=0)

    index = np.where(photonnum>0.6)
    
    l3 = plt.errorbar(2*photonnum[index], meanSNR[index], 2*stdSNR[index], fmt = 'rx')
    

    
    # mono thermal homodyne
#    [n, meanSNR, stdSNR, meanSNR_correct, 
#     stdSNR_correct] = plot_ampsweep_SNR_thermalState(fileno=33, 
#     ifplot=0, ifplotamp=0, ifplotfinal=0)
#    
#    l3 = plt.errorbar(n, meanSNR, 2*stdSNR, fmt='gs', mfc='w')
    
    
    # mono thermal FT
    
#    [n, meanSNR, stdSNR] = plot_ampsweep_SNR_monothermalState_FTmethod(
#           fileno=37, ifplot=0, ifplotamp=0, ifplotfinal=0)
#    
#    
#    l4 = plt.errorbar(n, meanSNR, 2*stdSNR, fmt='gs')
    
#    xdata = n
#    fdata = meanSNR
#    startpoint = [1]
#    fitfunc = squareroot;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    xd = np.linspace(0,12,100)
#    plt.plot(xd, fitfunc(xd,*para), 'g')
#    
#    l4 = plt.errorbar(n, meanSNR_correct, 2*stdSNR_correct, fmt='s',color='b',mfc='w')
#    
#    xdata = n
#    fdata = meanSNR_correct
#    startpoint = [1]
#    fitfunc = squareroot;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    xd = np.linspace(0,12,100)
#    plt.plot(xd, fitfunc(xd,*para), 'b')
    
    plt.xlabel('$n^{\\mathrm{(emit)}}$')
    plt.ylabel('SNR')
    plt.xlim([0, 12])
    
    
    
    
    
    lgnum = [l1,l3]
    lgname = ['coherent','thermal']
#    plt.legend(lgnum,lgname, loc='lower right')
    plt.legend(lgnum,lgname, loc='upper left', frameon=False)
#    plt.legend(lgnum,lgname, bbox_to_anchor=(0., 1.02, 1., .102), loc='lower left',
#           ncol=2, mode="expand", borderaxespad=0.)
    autoscale_y(plt.gca())
    
    plt.savefig('SNR_single.pdf',dpi=300,bbox_inches='tight')
    
    
def plot_SNR_vs_photonNum_paper_SI():
    
    
    plt.figure(figsize=(6,4))
    plt.rcParams.update({'font.size': 14.})
    # coherent homodyne
    
    photonnum, meanSNR, stdSNR = plot_ampsweep_SNR_coherent(
            fileno=47, ifplot=0, ifplotamp=0, ifplotfinal=0)
    
    l1 = plt.errorbar(photonnum, meanSNR, 2*stdSNR, fmt = 'bo')
    
    xdata = photonnum
    fdata = meanSNR
    startpoint = [1]
    fitfunc = squareroot;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    eff = para[0]/np.sqrt(2)
    print('efficiency is {}'.format(para[0]/np.sqrt(2)))
    xd = np.linspace(0,12,100)
    plt.plot(xd, fitfunc(xd,*para), 'b')
    # coherent FT
    
#    photonnum, meanSNR, stdSNR = plot_ampsweep_SNR_coherent(
#            fileno=56, ifplot=0, ifplotamp=0, ifplotfinal=0)
#    
#    index = np.where(photonnum>1)
#    
#    l2 = plt.errorbar(photonnum[index], meanSNR[index], 2*stdSNR[index], fmt = 'co')
    
    

    # broadband thermal
    
    photonnum, meanSNR, stdSNR = plot_powersweep_SNR_thermal_photonNumber(
            fileno=52, ifplot=0, ifplotfinal=0)

    index = np.where(photonnum>0.6)
    
    l3 = plt.errorbar(2*photonnum[index], meanSNR[index], 2*stdSNR[index], fmt = 'rx')
    

    
    # mono thermal homodyne
#    [n, meanSNR, stdSNR, meanSNR_correct, 
#     stdSNR_correct] = plot_ampsweep_SNR_thermalState(fileno=33, 
#     ifplot=0, ifplotamp=0, ifplotfinal=0)
#    
#    l3 = plt.errorbar(n, meanSNR, 2*stdSNR, fmt='gs', mfc='w')
    
    
#     mono thermal FT
    
    [n, meanSNR, stdSNR] = plot_ampsweep_SNR_monothermalState_FTmethod(
           fileno=37, ifplot=0, ifplotamp=0, ifplotfinal=0)
    
    
    l4 = plt.errorbar(n, meanSNR, 2*stdSNR, fmt='gd')
    
#    xdata = n
#    fdata = meanSNR
#    startpoint = [1]
#    fitfunc = squareroot;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    xd = np.linspace(0,12,100)
#    plt.plot(xd, fitfunc(xd,*para), 'g')
#    
#    l4 = plt.errorbar(n, meanSNR_correct, 2*stdSNR_correct, fmt='s',color='b',mfc='w')
#    
#    xdata = n
#    fdata = meanSNR_correct
#    startpoint = [1]
#    fitfunc = squareroot;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    xd = np.linspace(0,12,100)
#    plt.plot(xd, fitfunc(xd,*para), 'b')
    
    plt.xlabel('$n^{\\mathrm{(emit)}}$')
    plt.ylabel('SNR')
    plt.xlim([0, 12])
    
    
    
    
    
    lgnum = [l1,l3, l4]
    lgname = ['coherent','thermal','mono. thermal']
#    plt.legend(lgnum,lgname, loc='lower right')
    plt.legend(lgnum,lgname, loc='lower right', frameon=False)
#    plt.legend(lgnum,lgname, bbox_to_anchor=(0., 1.02, 1., .102), loc='lower left',
#           ncol=2, mode="expand", borderaxespad=0.)
    autoscale_y(plt.gca())
    
    plt.savefig('03_SI_SNR_all.pdf',dpi=300,bbox_inches='tight')
    
    
    
def plot_alpha_vs_amp(fileno=15, ifplot=1):
    
    amp, photon = plot_timeAmpSweep_acStarkspectrum_GaussianFit(fileno=fileno,ifplot=0,ifplotfinal=0)
    xdata = amp
    fdata = photon
    
    
    startpoint = [20,1]
    fitfunc = alphamodel;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    xd = np.linspace(0,1.5,100)
    
    if ifplot:
        plt.figure()
        plt.plot(amp**2,photon,'x')
        plt.plot(xd**2, alphamodel(xd,*para),'r') 
        
#        plt.plot(xd**2, xd**2*11, 'g')
        
        plt.plot(0,0)
        print(para)
        
        plt.xlabel('Power')
        plt.ylabel('Emitted photon number')
    
    return para, fitfunc

def plot_photon_vs_power_thermal(fileno=25, ifplot=1):
    
    power, photon = plot_timeAmpSweep_acStarkspectrum_GaussianFit_thermal(fileno=fileno,ifplot=0,ifplotfinal=0)
    
    xdata = power[0:]
    fdata = photon[0:]
    
    
#    startpoint = [50,50,1]
#    fitfunc = bi_Linear;
    startpoint = [60,1]
    fitfunc = photonmodel;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    xd = np.linspace(0,0.3,100)
    
    if ifplot:
        plt.figure()
        plt.plot(power,photon,'x')
        plt.plot(xd, fitfunc(xd,*para),'r') 
        
#        plt.plot(xd**2, xd**2*11, 'g')
        
        plt.plot(0,0)
        print(para)
        
        plt.xlabel('Power')
        plt.ylabel('Emitted photon number')
    
    return para, fitfunc


def get_photon_vs_power_thermal(inputpower):
    
    power, photon = plot_timeAmpSweep_acStarkspectrum_GaussianFit_thermal(fileno=63,ifplot=0,ifplotfinal=0)
    inputphoton = np.zeros(np.size(inputpower))
    
    
    for k in np.arange(np.size(inputpower)):
        index = np.where(power == inputpower[k])
        inputphoton[k] = photon[index]
    
    return inputphoton


#{'totspectrum_gstate':totspectrum_gstate,
#                'totspectrum_estate':totspectrum_estate,
#                'totspectrum_gstate_bg':totspectrum_gstate_bg,
#                'totspectrum_estate_bg':totspectrum_estate_bg,
#                'sig_gstate':sig_gstate,
#                'sig_estate':sig_estate,
#                'amp':amp, 'totrepnum':totrepnum, 'freq':freq,
#                'n':n, 'phase':phase}
def plot_mono_thermal_spectrum(fileno=45):
    plt.rcParams.update({'font.size': 14})
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    totspectrum_gstate = data['totspectrum_gstate']
    totspectrum_estate = data['totspectrum_estate']
    totspectrum_gstate_bg = data['totspectrum_gstate_bg']
    totspectrum_estate_bg = data['totspectrum_estate_bg']
    sig_gstate = data['sig_gstate']
    sig_gstate = sig_gstate.flatten()
    sig_estate = data['sig_estate']
    sig_estate = sig_estate.flatten()
    freq = data['freq']
    freq = freq.flatten()
    freq = freq*1e3
    print(np.size(sig_gstate))
    index = np.where(freq!=0)
    
    
    findex =np.where(np.abs(freq) <= 20)
    totnum = np.size(findex[0])
    print(totnum)
#    sig_gstate = sig_gstate/totnum
#    sig_estate = sig_estate/totnum
    
    plt.figure(figsize=(3.5,2.5))
    spectrum_g = np.mean(totspectrum_gstate, axis=0)
    spectrum_e = np.mean(totspectrum_estate, axis=0)
    spectrum_g_bg = np.mean(totspectrum_gstate_bg, axis=0)
    spectrum_e_bg = np.mean(totspectrum_estate_bg, axis=0)
    
    plt.plot(freq[index], spectrum_g[index] - spectrum_g_bg[index], 'b')
    plt.plot(freq[index], spectrum_e[index] - spectrum_e_bg[index], 'r')
    
    plt.xlim([-20,20])
    autoscale_y(plt.gca())
    plt.xlabel('Detuning (MHz)')
    plt.ylabel('Intensity')
    plt.savefig('03_monoThermal_spectrum.pdf',dpi=300,bbox_inches='tight')
    
    plt.show()
    
    lim = np.max(np.abs(np.append(sig_estate, sig_gstate)))*1.2   
    binnum = 50
    
    
    bins_y = np.linspace(-lim, lim, binnum)
    binwidth = bins_y[1] - bins_y[0]
    hist_g, bins = np.histogram(sig_gstate, bins=bins_y)
    hist_e, bins = np.histogram(sig_estate, bins=bins_y)
    
    voltage = bins_y[0:-1]+binwidth/2
   
    
    xdata = voltage
    ydata_g = hist_g
    ydata_e = hist_e
    
    startpoint = [np.max(ydata_g), 0, np.ptp(xdata)/4]
    fitfunc = Gaussian;
    para_g, pcov_g = opt.curve_fit(fitfunc, xdata, ydata_g, startpoint)
    perr_g = np.sqrt(np.diag(pcov_g))
    
    startpoint = [np.max(ydata_e), 0, np.ptp(xdata)/4]
    para_e, pcov_e = opt.curve_fit(fitfunc, xdata, ydata_e, startpoint)
    perr_e = np.sqrt(np.diag(pcov_e))

    SNR = np.abs((para_e[1]-para_g[1]))/((np.abs(para_g[2])+np.abs(para_e[2]))/2)
    plt.figure(figsize=(3.4,2.5))
    plt.plot(xdata, ydata_g, 'b.')
    plt.plot(xdata, ydata_e, 'r.')
    xd = np.linspace(xdata[0],xdata[-1],300)
    plt.plot(xd, fitfunc(xd,*para_g), 'b-')
    plt.plot(xd, fitfunc(xd,*para_e), 'r-')
    plt.xlabel('Signal')
    plt.ylabel('Count')
    plt.xlim([-10,250])
    plt.savefig('03_monoThermal_SNR.pdf',dpi=300,bbox_inches='tight')
    
    print('SNR is {}'.format(SNR))
    plt.show()
    
def plot_broadband_thermal_spectrum(fileno=51):
    plt.rcParams.update({'font.size': 14})
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    mean_spec_gstate = data['mean_spec_gstate']
    mean_spec_gstate = mean_spec_gstate.flatten()
    mean_spec_estate = data['mean_spec_estate']
    mean_spec_estate = mean_spec_estate.flatten()
    mean_spec_gstate_bg = data['mean_spec_gstate_bg']
    mean_spec_gstate_bg = mean_spec_gstate_bg.flatten()
    mean_spec_estate_bg = data['mean_spec_estate_bg']
    mean_spec_estate_bg = mean_spec_estate_bg.flatten()
    sig_gstate = data['sig_gstate']
    sig_gstate = sig_gstate.flatten()
    sig_estate = data['sig_estate']
    sig_estate = sig_estate.flatten()
    
    
    
    freq = data['freq']
    freq = freq.flatten()
    freq = freq*1e3
    
    
    
#    plt.figure()
#    plt.plot(freq)
#    plt.show()
    index = np.where(freq!=0)
    index = index[0]
    print(np.size(freq))
    
    findex =np.where(np.abs(freq) <= 20)
    totnum = np.size(findex[0])
    print(totnum)
    sig_gstate = sig_gstate/totnum
    sig_estate = sig_estate/totnum
    
    plt.figure(figsize=(3.5,2.5))
    spectrum_g = mean_spec_gstate
    spectrum_e = mean_spec_estate
    spectrum_g_bg = mean_spec_gstate_bg
    spectrum_e_bg = mean_spec_estate_bg
    
    print(np.shape(index))
#    
    plt.plot(freq[index], spectrum_g[index] - spectrum_g_bg[index], 'b')
    plt.plot(freq[index], spectrum_e[index] - spectrum_e_bg[index], 'r')
    
#    plt.plot(freq, spectrum_g - spectrum_g_bg, 'b')
#    plt.plot(freq, spectrum_e - spectrum_e_bg, 'r')
    
    plt.xlim([-20,20])
    autoscale_y(plt.gca())
    plt.xlabel('Detuning (MHz)')
    plt.ylabel('Amplitude')
    plt.savefig('03_broadThermal_single.pdf',dpi=300,bbox_inches='tight')
    plt.show()
    
    lim = np.max(np.abs(np.append(sig_estate, sig_gstate)))*1.2   
    binnum = 50
    
    
    bins_y = np.linspace(-lim, lim, binnum)
    binwidth = bins_y[1] - bins_y[0]
    hist_g, bins = np.histogram(sig_gstate, bins=bins_y)
    hist_e, bins = np.histogram(sig_estate, bins=bins_y)
    
    voltage = bins_y[0:-1]+binwidth/2
   
    
    xdata = voltage
    ydata_g = hist_g
    ydata_e = hist_e
    
    startpoint = [np.max(ydata_g), 0, np.ptp(xdata)/4]
    fitfunc = Gaussian;
    para_g, pcov_g = opt.curve_fit(fitfunc, xdata, ydata_g, startpoint)
    perr_g = np.sqrt(np.diag(pcov_g))
    
    startpoint = [np.max(ydata_e), 0, np.ptp(xdata)/4]
    para_e, pcov_e = opt.curve_fit(fitfunc, xdata, ydata_e, startpoint)
    perr_e = np.sqrt(np.diag(pcov_e))

    SNR = np.abs((para_e[1]-para_g[1]))/((np.abs(para_g[2])+np.abs(para_e[2]))/2)
    plt.figure(figsize=(3.4,2.5))
    plt.plot(xdata, ydata_g, 'b.')
    plt.plot(xdata, ydata_e, 'r.')
    xd = np.linspace(xdata[0],xdata[-1],300)
    plt.plot(xd, fitfunc(xd,*para_g), 'b-')
    plt.plot(xd, fitfunc(xd,*para_e), 'r-')
    plt.xlabel('Signal')
    plt.ylabel('Counts')
    plt.xlim([-500,2500])
    
    
    plt.savefig('03_broadThermal_SNR.pdf',dpi=300,bbox_inches='tight')
    plt.show()
    
    print('SNR is {}'.format(SNR))
    
    

def plot_coherent_FT_spectrum(fileno=59):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    mean_spec_gstate = data['mean_spec_gstate']
    mean_spec_gstate = mean_spec_gstate.flatten()
    mean_spec_estate = data['mean_spec_estate']
    mean_spec_estate = mean_spec_estate.flatten()
    mean_spec_gstate_bg = data['mean_spec_gstate_bg']
    mean_spec_gstate_bg = mean_spec_gstate_bg.flatten()
    mean_spec_estate_bg = data['mean_spec_estate_bg']
    mean_spec_estate_bg = mean_spec_estate_bg.flatten()
    sig_gstate = data['sig_gstate']
    sig_gstate = sig_gstate.flatten()
    sig_estate = data['sig_estate']
    sig_estate = sig_estate.flatten()
    freq = data['freq']
    freq = freq.flatten()
    freq = freq*1e3
#    plt.figure()
#    plt.plot(freq)
#    plt.show()
    index = np.where(freq!=0)
    index = index[0]
    print(np.size(sig_gstate))
    
    plt.figure(figsize=(3.7,2.5))
    spectrum_g = mean_spec_gstate
    spectrum_e = mean_spec_estate
    spectrum_g_bg = mean_spec_gstate_bg
    spectrum_e_bg = mean_spec_estate_bg
    
    print(np.shape(index))
#    
    plt.plot(freq[index], spectrum_g[index] - spectrum_g_bg[index], 'b')
    plt.plot(freq[index], spectrum_e[index] - spectrum_e_bg[index], 'r')
    
#    plt.plot(freq, spectrum_g - spectrum_g_bg, 'b')
#    plt.plot(freq, spectrum_e - spectrum_e_bg, 'r')
    
    plt.xlim([-20,20])
    autoscale_y(plt.gca())
    plt.xlabel('Detuning (MHz)')
    plt.ylabel('Averaged intensity')
    plt.savefig('03_coherent_single_FT.pdf',dpi=300,bbox_inches='tight')
    plt.show()
    
    lim = np.max(np.abs(np.append(sig_estate, sig_gstate)))*1.2   
    binnum = 50
    
    
    bins_y = np.linspace(-lim, lim, binnum)
    binwidth = bins_y[1] - bins_y[0]
    hist_g, bins = np.histogram(sig_gstate, bins=bins_y)
    hist_e, bins = np.histogram(sig_estate, bins=bins_y)
    
    voltage = bins_y[0:-1]+binwidth/2
   
    
    xdata = voltage
    ydata_g = hist_g
    ydata_e = hist_e
    
    startpoint = [np.max(ydata_g), 0, np.ptp(xdata)/4]
    fitfunc = Gaussian;
    para_g, pcov_g = opt.curve_fit(fitfunc, xdata, ydata_g, startpoint)
    perr_g = np.sqrt(np.diag(pcov_g))
    
    startpoint = [np.max(ydata_e), 0, np.ptp(xdata)/4]
    para_e, pcov_e = opt.curve_fit(fitfunc, xdata, ydata_e, startpoint)
    perr_e = np.sqrt(np.diag(pcov_e))

    SNR = np.abs((para_e[1]-para_g[1]))/((np.abs(para_g[2])+np.abs(para_e[2]))/2)
    plt.figure()
    plt.plot(xdata, ydata_g, 'bo')
    plt.plot(xdata, ydata_e, 'ro')
    xd = np.linspace(xdata[0],xdata[-1],300)
    plt.plot(xd, fitfunc(xd,*para_g), 'b-')
    plt.plot(xd, fitfunc(xd,*para_e), 'r-')
    plt.xlabel('FT signal')
    plt.ylabel('Count')
#    plt.xlim([0,300])
    print('SNR is {}'.format(SNR))
    plt.show()

#    data = {'ch_b_g':ch_b_g,'ch_b_e':ch_b_e,'ch_a_g':ch_a_g,'ch_a_e':ch_a_e}
def plot_coherent_readout(fileno=46, ifplot = 1, ifplotSNR=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    ch_b_g = data['ch_b_g']
    ch_b_g = ch_b_g.flatten()
    ch_b_e = data['ch_b_e']
    ch_b_e = ch_b_e.flatten()
    ch_a_g = data['ch_a_g']
    ch_a_g = ch_a_g.flatten()
    ch_a_e = data['ch_a_e']
    ch_a_e = ch_a_e.flatten()
    print(np.size(ch_a_g))
    lim = np.max(np.concatenate((np.abs(ch_a_g), np.abs(ch_a_e),
                                 np.abs(ch_b_g), np.abs(ch_b_e))))*1.2
    lim_x = np.max(np.concatenate((np.abs(ch_a_g), np.abs(ch_a_e))))*1.2
    lim_y = np.max(np.concatenate((np.abs(ch_b_g), np.abs(ch_b_e))))*1.2   
    
    vec = 1j * (np.mean(ch_b_e)-np.mean(ch_b_g)) +  (np.mean(ch_a_e)-np.mean(ch_a_g))
    angle_c = 180/np.pi * np.angle(vec)
    
    if ifplot:
#        ax = plt.figure()
#        plt.plot(rec_all_raw_ave[0][0,:],'r')
#        plt.plot(rec_all_raw_ave[1][0,:],'b')
        
        plt.figure(figsize=(4.5,2.5))
        ax_scatter = plt.axes()
        ax_scatter.scatter(ch_a_g, -ch_b_g, s=5, c='b', marker='.', alpha=0.05)
        ax_scatter.scatter(ch_a_e, -ch_b_e, s=5, c='r', marker='.', alpha=0.05)
    
        ax_scatter.set_xlim([-lim*1.4, lim*1.4])
        ax_scatter.set_ylim([-lim, lim])
        
        
#        ax_scatter.plot(np.mean(ch_a_g),np.mean(ch_b_g), 'bo')
#        ax_scatter.plot(np.mean(ch_a_e),np.mean(ch_b_e), 'kx')
        
        
        
        
        
#        print('Correct angle is {}'.format(np.mod(angle+90-angle_c,360)))
        
        plt.xlabel('$I$')
        plt.ylabel('$Q$')
        
        plt.gca().set_aspect('equal')
        
        plt.savefig('03_coherent_single_IQ2.png',dpi=300,bbox_inches='tight')
        plt.show()
    
    binnum = 50
    
    bins_x = np.linspace(-lim, lim, binnum)
    bins_y = np.linspace(-lim, lim, binnum)
    
    
    
    
    hist_g, bins = np.histogram(ch_b_g, bins=bins_y)
    hist_e, bins = np.histogram(ch_b_e, bins=bins_y)
    binwidth = bins[1]-bins[0]
    
    
    intcount_g = np.zeros(np.size(hist_g))
    intcount_e = np.zeros(np.size(hist_g))
    
    for k in np.arange(np.size(hist_g)):
        intcount_g[k] = np.sum(hist_g[0:k+1])
        intcount_e[k] = np.sum(hist_e[0:k+1])
    
    
    fid = intcount_g/np.max(intcount_g)-intcount_e/np.max(intcount_e)
    voltage = bins_y[0:-1]+binwidth/2
    index = np.argmax(fid)
    
    print('Readout fidelity is ' + str(fid[index]))
    print('Cutoff voltage is ' + str(voltage[index]))
    
    if 0:
        plt.figure()
        plt.hist(ch_b_g, bins=bins_y, color = 'b', histtype='step', orientation='vertical')
    
        plt.hist(ch_b_e, bins=bins_y, color = 'r', histtype='step', orientation='vertical')
        
        plt.xlabel('ch2 reading')
        plt.ylabel('Count')
        plt.legend(['g state', 'e state'],loc='upper left')    
        
        plt.title('Fidelity is {}'.format(fid[index]))
        
        plt.show()
    
    
    
    
    xdata = voltage
    ydata_g = hist_g
    ydata_e = hist_e
    
    
    if ifplotSNR:
        index = np.argmax(ydata_g)
        startpoint = [np.max(ydata_g), xdata[index], np.ptp(xdata)/6]
        fitfunc = Gaussian;
        para_g, pcov_g = opt.curve_fit(fitfunc, xdata, ydata_g, startpoint)
        perr_g = np.sqrt(np.diag(pcov_g))
        
        index = np.argmax(ydata_e)
        startpoint = [np.max(ydata_e), xdata[index], np.ptp(xdata)/6]
        para_e, pcov_e = opt.curve_fit(fitfunc, xdata, ydata_e, startpoint)
        perr_e = np.sqrt(np.diag(pcov_e))
    
        SNR = np.abs((para_e[1]-para_g[1]))/((np.abs(para_g[2])+np.abs(para_e[2]))/2)
        
        plt.figure(figsize=(1.5*1.3,1*1.3))
        plt.rcParams.update({'font.size': 14})
        plt.plot(-xdata, ydata_g, 'b.')
        plt.plot(-xdata, ydata_e, 'r.')
        plt.plot(-xdata, fitfunc(xdata,*para_g), 'b-')
        plt.plot(-xdata, fitfunc(xdata,*para_e), 'r-')
        
        print(startpoint)
        print(para_e)
        plt.xlim([-5.5,5.5])
#        plt.title('SNR is {}'.format(SNR))
        plt.ylabel('Counts')
        plt.xlabel('Signal')
        plt.savefig('03_coherent_single_SNR2.pdf',dpi=300,bbox_inches='tight')
        plt.show()
    
    
    

def plot_coherent_readout_SI(fileno=46, ifplot = 1, ifplotSNR=1):
    
    plt.rcParams.update({'font.size': 14})
    
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    ch_b_g = data['ch_b_g']
    ch_b_g = ch_b_g.flatten()
    ch_b_e = data['ch_b_e']
    ch_b_e = ch_b_e.flatten()
    ch_a_g = data['ch_a_g']
    ch_a_g = ch_a_g.flatten()
    ch_a_e = data['ch_a_e']
    ch_a_e = ch_a_e.flatten()
    print(np.size(ch_a_g))
    lim = np.max(np.concatenate((np.abs(ch_a_g), np.abs(ch_a_e),
                                 np.abs(ch_b_g), np.abs(ch_b_e))))*1.2
    lim_x = np.max(np.concatenate((np.abs(ch_a_g), np.abs(ch_a_e))))*1.2
    lim_y = np.max(np.concatenate((np.abs(ch_b_g), np.abs(ch_b_e))))*1.2   
    
    vec = 1j * (np.mean(ch_b_e)-np.mean(ch_b_g)) +  (np.mean(ch_a_e)-np.mean(ch_a_g))
    angle_c = 180/np.pi * np.angle(vec)
    
    
    
    binnum = 50
    
    bins_x = np.linspace(-lim, lim, binnum)
    bins_y = np.linspace(-lim, lim, binnum)
    
    
    
    
    hist_g, bins = np.histogram(ch_b_g, bins=bins_y)
    hist_e, bins = np.histogram(ch_b_e, bins=bins_y)
    binwidth = bins[1]-bins[0]
    
    
    intcount_g = np.zeros(np.size(hist_g))
    intcount_e = np.zeros(np.size(hist_g))
    
    for k in np.arange(np.size(hist_g)):
        intcount_g[k] = np.sum(hist_g[0:k+1])
        intcount_e[k] = np.sum(hist_e[0:k+1])
    
    
    fid = intcount_g/np.max(intcount_g)-intcount_e/np.max(intcount_e)
    voltage = bins_y[0:-1]+binwidth/2
    index = np.argmax(fid)
    
    print('Readout fidelity is ' + str(fid[index]))
    print('Cutoff voltage is ' + str(voltage[index]))
    
    if 0:
        plt.figure()
        plt.hist(ch_b_g, bins=bins_y, color = 'b', histtype='step', orientation='vertical')
    
        plt.hist(ch_b_e, bins=bins_y, color = 'r', histtype='step', orientation='vertical')
        
        plt.xlabel('ch2 reading')
        plt.ylabel('Count')
        plt.legend(['g state', 'e state'],loc='upper left')    
        
        plt.title('Fidelity is {}'.format(fid[index]))
        
        plt.show()
    
    
    
    
    xdata = voltage
    ydata_g = hist_g
    ydata_e = hist_e
    
    
    if ifplotSNR:
        index = np.argmax(ydata_g)
        startpoint = [np.max(ydata_g), xdata[index], np.ptp(xdata)/6]
        fitfunc = Gaussian;
        para_g, pcov_g = opt.curve_fit(fitfunc, xdata, ydata_g, startpoint)
        perr_g = np.sqrt(np.diag(pcov_g))
        
        index = np.argmax(ydata_e)
        startpoint = [np.max(ydata_e), xdata[index], np.ptp(xdata)/6]
        para_e, pcov_e = opt.curve_fit(fitfunc, xdata, ydata_e, startpoint)
        perr_e = np.sqrt(np.diag(pcov_e))
    
        SNR = np.abs((para_e[1]-para_g[1]))/((np.abs(para_g[2])+np.abs(para_e[2]))/2)
        
        plt.figure(figsize=(3.4,2.5))
        plt.plot(-xdata, ydata_g, 'b.')
        plt.plot(-xdata, ydata_e, 'r.')
        plt.plot(-xdata, fitfunc(xdata,*para_g), 'b-')
        plt.plot(-xdata, fitfunc(xdata,*para_e), 'r-')
        
        print(startpoint)
        print(para_e)
        plt.xlim([-5.5,5.5])
#        plt.title('SNR is {}'.format(SNR))
        plt.ylabel('Counts')
        plt.xlabel('Signal')
        plt.savefig('03_SI_coherent_single_SNR2.pdf',dpi=300,bbox_inches='tight')
        plt.show()
        
    if ifplot:
#        ax = plt.figure()
#        plt.plot(rec_all_raw_ave[0][0,:],'r')
#        plt.plot(rec_all_raw_ave[1][0,:],'b')
        
        plt.figure(figsize=(4.5,2.5))
        ax_scatter = plt.axes()
        ax_scatter.scatter(ch_a_g, -ch_b_g, s=5, c='b', marker='.', alpha=0.05)
        ax_scatter.scatter(ch_a_e, -ch_b_e, s=5, c='r', marker='.', alpha=0.05)
    
        ax_scatter.set_xlim([-lim*1.35, lim*1.35])
        ax_scatter.set_ylim([-lim, lim])
        
        
#        ax_scatter.plot(np.mean(ch_a_g),np.mean(ch_b_g), 'bo')
#        ax_scatter.plot(np.mean(ch_a_e),np.mean(ch_b_e), 'kx')
        
        
        
        
        
#        print('Correct angle is {}'.format(np.mod(angle+90-angle_c,360)))
        
        plt.xlabel('$I$')
        plt.ylabel('$Q$')
        
        plt.gca().set_aspect('equal')
        
        plt.savefig('03_SI_coherent_single_IQ2.png',dpi=300,bbox_inches='tight')
        plt.show()


def alphamodel(x,a,p):
    return a*x**2/(p + x**2)

def photonmodel(x,a,p):
    return a*x/(p + x)

def getampfromalpha(x, alpha, para):
    return alpha**2 - alphamodel(x, *para)

def test_getamp():
    para, fitfunc = plot_alpha_vs_amp(fileno=31, ifplot=1)
    alpha = np.arange(0,3+0.1,0.5) + 0.25
    amp = np.zeros(np.size(alpha))
    for k in np.arange(np.size(amp)):
        result = fsolve(getampfromalpha, [0.5], args=(alpha[k], para))
        amp[k] = result[0]
    plt.figure()
    plt.plot(amp**2, alpha**2, 'x')
    
    plt.figure()
    plt.plot(amp, alpha, 'x')
        

def plot_all_acStarkSpectrum():
    xdata, ydata0, peak0 = plot_acStarkspectrum(fileno=272)
    xdata, ydata1, peak1 = plot_acStarkspectrum(fileno=273)
    xdata, ydata2, peak2 = plot_acStarkspectrum(fileno=268)
    xdata, ydata3, peak3 = plot_acStarkspectrum(fileno=271)
    xdata, ydata4, peak4 = plot_acStarkspectrum(fileno=287)
    
    maxnum = 6
    photonnum = np.arange(maxnum)
    
    n=3
    alpha = [0.25,0.75,1.25,1.75,2.25]
    peak = (peak0*np.exp(-alpha[0]**2/n) * (alpha[0]) +
            peak1*np.exp(-alpha[1]**2/n) * (alpha[1]) +
            peak2*np.exp(-alpha[2]**2/n) * (alpha[2]) +
            peak3*np.exp(-alpha[3]**2/n) * (alpha[3]) +
            peak4*np.exp(-alpha[4]**2/n) * (alpha[4]))
    
    plt.figure()
    ydatathermal = (ydata0*np.exp(-alpha[0]**2/n) * (alpha[0]) +
            ydata1*np.exp(-alpha[1]**2/n) * (alpha[1]) +
            ydata2*np.exp(-alpha[2]**2/n) * (alpha[2]) +
            ydata3*np.exp(-alpha[3]**2/n) * (alpha[3]) +
            ydata4*np.exp(-alpha[4]**2/n) * (alpha[4]))
    
    plt.plot(xdata, ydatathermal, '.-')
    
#    plt.figure()
#    plt.plot(photonnum, peak,'o')
    
    
    
    
    chiv = chi * 1.0
        
        
    peak = np.zeros(maxnum)
    
    sep = chiv/(2*np.pi)*2*1e-3
    width = sep/2
#    shift = -0.005
    shift = -0.0
    
#    plt.figure()
#    plt.plot(xdata, ydata, 'k.-')    
    plt.ylim(plt.gca().get_ylim())
    for k in np.arange(maxnum):
        plt.plot(np.array([1,1])*(-k)*chiv/(2*np.pi)*2*1e-3+shift, plt.gca().get_ylim(), 'r--')
    plt.xlabel('Detuning (GHz)')
    plt.ylabel('P$_e$')
        
        
    for k in np.arange(maxnum):
        
        
        index = np.where(np.logical_and.reduce
                         ((xdata>-k*sep-width+shift,
                           xdata<-k*sep+width+shift)))[0]
        bgindex = np.where((xdata>sep))[0]
        
        
        peak[k] = np.sum(ydatathermal[index] - np.mean(ydatathermal[bgindex]))
        
    plt.figure()
    plt.plot(photonnum, peak, 'o')
    startpoint = [1,1]
    fitfunc = thermalstate;
    para, pcov = opt.curve_fit(fitfunc, photonnum, peak, startpoint)
    
    xd = np.linspace(0, maxnum, 100)
    plt.plot(xd, thermalstate(xd, *para), 'r')
    plt.ylabel('Population')
    plt.xlabel('n')
    
    plt.title(para[0])

    
def get_alpha_from_acStarkSpectrum(fileno=261, ifplot=0, ifplotfinal=1):
    fname = getsinglefile('{:03d}*'.format(fileno))
    data = io.loadmat(fname)
    sweepparam = data['sweepparam']
    xdata = data['sweepfreq']
    totprob = data['totprob']
    sweepname = data['sweepname']
    
    xdata = xdata.flatten()
    sweepparam = sweepparam.flatten()
    
    
    totalpha = np.zeros(np.size(sweepparam))
    
    for m in np.arange(np.size(sweepparam)):
        ydata = totprob[m,:]
        
        maxnum = 6
        chiv = chi * 1.0
        peak = np.zeros(maxnum)    
        sep = chiv/(2*np.pi)*2*1e-3
        width = sep/2
    #    shift = -0.005
        shift = -0.00
        
        if ifplot:
            plt.figure()
            plt.plot(xdata, ydata, 'k.-')    
            plt.ylim(plt.gca().get_ylim())
            for k in np.arange(maxnum):
                plt.plot(np.array([1,1])*(-k)*chiv/(2*np.pi)*2*1e-3+shift, plt.gca().get_ylim(), 'r--')
            plt.xlabel('Detuning (GHz)')
            plt.ylabel('P$_e$')
            
            
        for k in np.arange(maxnum):
            index = np.where(np.logical_and.reduce
                             ((xdata>-k*sep-width+shift,
                               xdata<-k*sep+width+shift)))[0]
            bgindex = np.where((xdata>sep))[0]
            peak[k] = np.sum(ydata[index] - np.mean(ydata[bgindex]))
        
        
        
        photonnum = np.arange(maxnum)
        
        startpoint = [1,1]
        fitfunc = coherentstate;
        para, pcov = opt.curve_fit(fitfunc, photonnum, peak, startpoint)
        
        xd = np.linspace(0, maxnum, 100)
        
        if ifplot:
            plt.figure()
            plt.plot(photonnum, peak, 'o')
            plt.plot(xd, coherentstate(xd, *para), 'r')
            plt.ylabel('Population')
            plt.xlabel('n')
        
        totalpha[m] = para[0]
    
    if ifplotfinal:
        if sweepname == 'start':
            plt.figure()
            plt.plot(sweepparam + 500/2, totalpha, 'rx')
            plt.bar(sweepparam+ 500/2,totalpha,width=500,color='y',edgecolor='b')
            
            
            plt.xlabel('Time (ns)')
            plt.ylabel('$\\alpha$')
            plt.ylim([0,2])
            plt.xlim([0,2000])
            

#peak = (peak0*np.exp(-alpha[0]**2/n) * (alpha[0]) +
#            peak0p05*np.exp(-alpha[1]**2/n) * (alpha[1]) +
#            peak0p1*np.exp(-alpha[2]**2/n) * (alpha[2]) +
#            peak0p15*np.exp(-alpha[3]**2/n) * (alpha[3])  )
            
def simulate_thermal_state():
#    alpha = [0.25,0.75,1.25,1.75,]
    step = 0.5
    alpha = np.arange(0,2.5,step)+step/2
    
    maxnum = 6
    photonnum = np.arange(maxnum)
    peak = np.zeros(maxnum)
    n = 2
    
    for k in np.arange(np.size(alpha)):
        peak = peak + coherentstate(photonnum, alpha[k], 1) * np.exp(-alpha[k]**2/n) * alpha[k]
    
#    peak = coherentstate(photonnum, 3, 1)
    
    peak = peak/np.size(alpha)
                
    plt.figure()
    plt.plot(photonnum, peak, 'o')
    startpoint = [1,1]
    fitfunc = thermalstate;
    para, pcov = opt.curve_fit(fitfunc, photonnum, peak, startpoint)
    
    xd = np.linspace(0, maxnum, 100)
    plt.plot(xd, fitfunc(xd, *para), 'r')
    plt.ylabel('Population')
    plt.xlabel('n')
    
    plt.title(para[0])        
#    plt.ylim([0,0.1])
#def plot_startSweep_acStark():    
        
        
def coherentstate(x, alpha, a, b):
    return a*np.exp(-alpha**2) * alpha**(2*x) / factorial(x) + b

def coherentstate_GaussianShape(x, alpha, height, sigma, bg):
    
    maxnum = 6
    sep = -chi/(2*np.pi)*2*1e-3
        
    prob = np.zeros(np.size(x))
    for k in np.arange(maxnum):
        prob = prob + np.exp(-(x-k*sep)**2/(2*sigma**2)) * (height * 
                            np.exp(-alpha**2) * alpha**(2*k) / factorial(k))
    
    prob = prob + bg
    return prob

def thermalstate(x, n, a):
    return a * 1/(n+1) * (n/(n+1))**x
        


def thermalstate_GaussianShape(x, n, height, sigma, bg):
    
    maxnum = 6
    sep = -chi/(2*np.pi)*2*1e-3
        
    prob = np.zeros(np.size(x))
    
    for k in np.arange(maxnum):
        prob = prob + np.exp(-(x-k*sep)**2/(2*sigma**2)) * (height * 
                            1/(n+1) * (n/(n+1))**k)
    
    prob = prob + bg
    return prob

def thermalstate_GaussianShape_2width(x, n, height, sigma, sigma2, bg):
    
    maxnum = 6
    sep = -chi/(2*np.pi)*2*1e-3
        
    prob = np.zeros(np.size(x))
    
    for k in np.arange(maxnum):
        if k == 0:
            prob = prob + np.exp(-(x-k*sep)**2/(2*sigma**2)) * (height * 
                                1/(n+1) * (n/(n+1))**k)
        if k > 0:
            prob = prob + np.exp(-(x-k*sep)**2/(2*sigma2**2)) * (height * sigma / sigma2 *
                                1/(n+1) * (n/(n+1))**k)
    
    prob = prob + bg
    return prob

def RabiOsc(x, A, w, bg):
    return A * np.sin(2*np.pi*w*x)**2 + bg

def Osc(x, A, phi, bg):
    return A * np.sin(x+phi) + bg

def Linear(x, A):
    return A * x

def Linear_withbg(x, A, b):
    return A * x + b

def squareroot(x, A):
    return A * np.sqrt(x)


def bi_Linear(x, a, b, c):
    return (a*x*(b*x+c))/(a*x + b*x + c)

def Gain_model(x, An, Ah):
    return 0.5/(An + Ah/x)

def Gain_model_phaseSensitive(x, eta, Ah=36):
    return 0.5/(0.5 + Ah/x)

def photonnum(x, A):
    return A * 10**(x/10)

def Gaussian(x, A, c, sigma):
    return A * np.exp(-(x-c)**2/(2*sigma**2))

def Gaussian_zero(x, A, sigma):
    return A * np.exp(-(x)**2/(2*sigma**2))

def saturation_curve(x, A, c, bg):
    return A/(1+c/x) + bg

def norm_Gaussian(x, c, sigma):
    return 1/(np.sqrt(2*np.pi)*sigma) * np.exp(-(x-c)**2/(2*sigma**2))

def ExpDecay(x, A, tau, bg):
    return A * np.exp(-(x/tau)) + bg    

def ExpOscDecay(x, A, tau, w, phi, bg):
    return A * np.cos(2*np.pi*w*x + phi) * np.exp(-(x/tau)) + bg


def lorentz(x, c, w, h, bg):
    return h * 1/((x-c)**2+(w/2)**2) + bg


def gaussianLine(x, c, sigma, h, bg):
    return h * np.exp(-(x-c)**2/(2*sigma**2)) + bg

def getsinglefile(fname):
    allname = glob.glob(fname)
    name = allname[0]
    if len(allname) > 1:
        raise MyError('Change the input so there is only one file!')
    return name

def compare_ge_spectrum(ave_n = None):
    
    
    start = 100
    duration = 2000
    bgstart = 7000
    
    # ---------------------------
    # g state
    
    fname = getsinglefile('173*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    freq, totsig, spec_g = get_dm_spectrum(rec_all_raw_ave, indexstart = start, indexend = start+duration, avenum = ave_n)
    freq, totsig_bg, spec_g_bg = get_dm_spectrum(rec_all_raw_ave, indexstart = bgstart, indexend = bgstart+duration, avenum = ave_n)
    
    sig_g = np.abs(totsig) - np.abs(totsig_bg)
    
    
  
    # ---------------------------
    # e state
    
    fname = getsinglefile('174*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    
    freq, totsig, spec_e = get_dm_spectrum(rec_all_raw_ave, indexstart = start, indexend = start+duration, avenum = ave_n)
    freq, totsig_bg, spec_e_bg = get_dm_spectrum(rec_all_raw_ave, indexstart = bgstart, indexend = bgstart+duration, avenum = ave_n)
    
    sig_e = np.abs(totsig) - np.abs(totsig_bg)
    
    spec = spec_e - spec_e_bg
    
   
    plt.figure()
    plt.plot(freq, sig_g, 'b.-')
    plt.plot(freq, sig_e, 'r.-')
    
    
    plt.xlabel('Freq (GHz)')
    plt.ylabel('Fourier transform')
    plt.xlim([0, 0.05])
    da.autoscale_y(plt.gca())
    
    
def get_single_spectrum(ave_n = None):
    
    
    start = 300
    duration = 2000
    bgstart = 9000
    
    # ---------------------------
    # g state
    
    fname = getsinglefile('183*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    freq, totsig, spec_g = get_dm_spectrum(rec_all_raw_ave, indexstart = start, indexend = start+duration, avenum = ave_n)
    freq, totsig_bg, spec_g_bg = get_dm_spectrum(rec_all_raw_ave, indexstart = bgstart, indexend = bgstart+duration, avenum = ave_n)
    
    sig_g = np.abs(totsig) - np.abs(totsig_bg)
    
    
  
    
    
   
    plt.figure()
    plt.plot(freq, sig_g, 'b.-')
    
    
    
    plt.xlabel('Freq (GHz)')
    plt.ylabel('Fourier transform')
    plt.xlim([0, 0.05])
    da.autoscale_y(plt.gca())
     
def compare_ge_spectrum_hist():
    
    ave_n = None
    # ---------------------------
    # g state
    
    fname = getsinglefile('173*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    start = 300
    duration = 2000
    startbg = 9000
    
    freq, totsig, spec_g = get_dm_spectrum(rec_all_raw_ave, indexstart = start,
                                           indexend = start+duration, avenum = ave_n)
    freq, totsig_bg, spec_g_bg = get_dm_spectrum(rec_all_raw_ave, indexstart = startbg,
                                                 indexend = startbg+duration, avenum = ave_n)
    
    sig_g = np.abs(totsig) - np.abs(totsig_bg)
#    sig_g = np.abs(totsig)
    
    spec = spec_g - spec_g_bg
#    spec = spec_g
    
    # integration region
#    freqstartg = 0.010
#    freqendg = 0.017
    
    freqstartg = 0.009
    freqendg = 0.012
    
    findex =  np.where(np.logical_and(freq>freqstartg,freq<freqendg))[0]
    sig_subBg_gstate = np.sum(spec[:,findex],axis=1)
    
    
#    freqstarte = 0.02
#    freqende = 0.023
    
    freqstarte = 0.019
    freqende = 0.022
    
    findex =  np.where(np.logical_and(freq>freqstarte,freq<freqende))[0]
    sig_subBg_estate = np.sum(spec[:,findex],axis=1)
    
    sig_g_spec = sig_subBg_gstate - 1*sig_subBg_estate
#    sig_g_spec = sig_subBg_gstate
    
    # ---------------------------
    # e state
    
    fname = getsinglefile('174*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    
    freq, totsig, spec_e = get_dm_spectrum(rec_all_raw_ave, indexstart = start,
                                           indexend = start+duration, avenum = ave_n)
    freq, totsig_bg, spec_e_bg = get_dm_spectrum(rec_all_raw_ave, indexstart = startbg,
                                                 indexend = startbg+duration, avenum = ave_n)    
    
    sig_e = np.abs(totsig) - np.abs(totsig_bg)
#    sig_e = np.abs(totsig)
    
    spec = spec_e - spec_e_bg
#    spec = spec_e
    
    # integration region
#    freqstartg = 0.007
#    freqendg = 0.012
    findex =  np.where(np.logical_and(freq>freqstartg,freq<freqendg))[0]
    sig_subBg_gstate = np.sum(spec[:,findex],axis=1)
    
    
#    freqstarte = 0.018
#    freqende = 0.023
    findex =  np.where(np.logical_and(freq>freqstarte,freq<freqende))[0]
    sig_subBg_estate = np.sum(spec[:,findex],axis=1)
    
    sig_e_spec = sig_subBg_gstate - 1*sig_subBg_estate
#    sig_e_spec = sig_subBg_gstate
    
    
    plt.figure()
    plt.plot(freq, sig_g, 'b')
    plt.plot(freq, sig_e, 'r')
    
    
    plt.xlabel('Freq (GHz)')
    plt.ylabel('Fourier transform')
    plt.xlim([0, 0.05])
    da.autoscale_y(plt.gca())
    
    plt.figure()
    
    bins_spec = np.linspace(np.min(sig_g_spec),np.max(sig_g_spec),50)
    [n1,bins,pa] = plt.hist(sig_g_spec, bins=bins_spec, color = 'b', histtype='step', orientation='vertical')
    print(np.sum(n1))
    
    
#    bins_spec = np.linspace(np.min(sig_g_spec),np.max(sig_g_spec),100)
    [n2,bins,pa] = plt.hist(sig_e_spec, bins=bins_spec, color = 'r', histtype='step', orientation='vertical')
    print(np.size(n2))
#    [hist,bins] = np.histogram(sig_e_spec, bins=bins_spec)
#    xd = (bins[:-1]+bins[1:])/2
#    plt.plot(xd, hist, 'ro')
    plt.legend(['g state','e state'])
    plt.xlabel('FT signal')
    plt.ylabel('Coincidence')
    
    plt.figure()
    plt.plot(freq, spec[1,:],color='r')
    plt.xlim([0,0.05])


def compare_ge_spectrum_hist_highPower():
    
    ave_n = None
    # ---------------------------
    # g state
    
    fname = getsinglefile('172*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    start = 500
    duration = 1000
    startbg = 4000
    
    freq, totsig, spec_g = get_dm_spectrum(rec_all_raw_ave, indexstart = start,
                                           indexend = start+duration, avenum = ave_n)
    freq, totsig_bg, spec_g_bg = get_dm_spectrum(rec_all_raw_ave, indexstart = startbg,
                                                 indexend = startbg+duration, avenum = ave_n)
    
    sig_g = np.abs(totsig) - np.abs(totsig_bg)
#    sig_g = np.abs(totsig)
    
    spec = spec_g - spec_g_bg
#    spec = spec_g
    
    # integration region
#    freqstartg = 0.010
#    freqendg = 0.017
    
    freqstartg = 0.02
    freqendg = 0.03
    
    findex =  np.where(np.logical_and(freq>freqstartg,freq<freqendg))[0]
    sig_subBg_gstate = np.max(spec[:,findex],axis=1)
    
    
#    freqstarte = 0.02
#    freqende = 0.023
    
#    freqstarte = 0.02
#    freqende = 0.03
#    
#    findex =  np.where(np.logical_and(freq>freqstarte,freq<freqende))[0]
#    sig_subBg_estate = np.sum(spec[:,findex],axis=1)
    
    sig_g_spec = sig_subBg_gstate 
#    sig_g_spec = sig_subBg_gstate
    
    # ---------------------------
    # e state
    
    fname = getsinglefile('173*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    
    freq, totsig, spec_e = get_dm_spectrum(rec_all_raw_ave, indexstart = start,
                                           indexend = start+duration, avenum = ave_n)
    freq, totsig_bg, spec_e_bg = get_dm_spectrum(rec_all_raw_ave, indexstart = startbg,
                                                 indexend = startbg+duration, avenum = ave_n)    
    
    sig_e = np.abs(totsig) - np.abs(totsig_bg)
#    sig_e = np.abs(totsig)
    
    spec = spec_e - spec_e_bg
#    spec = spec_e
    
    # integration region
#    freqstartg = 0.007
#    freqendg = 0.012
    findex =  np.where(np.logical_and(freq>freqstartg,freq<freqendg))[0]
    sig_subBg_gstate = np.max(spec[:,findex],axis=1)
    
    
#    freqstarte = 0.018
#    freqende = 0.023
#    findex =  np.where(np.logical_and(freq>freqstarte,freq<freqende))[0]
#    sig_subBg_estate = np.sum(spec[:,findex],axis=1)
    
    sig_e_spec = sig_subBg_gstate
#    sig_e_spec = sig_subBg_gstate
    
    
    plt.figure()
    plt.plot(freq, sig_g, 'b')
    plt.plot(freq, sig_e, 'r')
    
    
    plt.xlabel('Freq (GHz)')
    plt.ylabel('Fourier transform')
    plt.xlim([0, 0.05])
    da.autoscale_y(plt.gca())
    
    plt.figure()
    
    bins_spec = np.linspace(np.min(sig_g_spec),np.max(sig_g_spec),50)
    [n1,bins,pa] = plt.hist(sig_g_spec, bins=bins_spec, color = 'b', histtype='step', orientation='vertical')
    print(np.sum(n1))
    
    
#    bins_spec = np.linspace(np.min(sig_g_spec),np.max(sig_g_spec),100)
    [n2,bins,pa] = plt.hist(sig_e_spec, bins=bins_spec, color = 'r', histtype='step', orientation='vertical')
    print(np.size(n2))
#    [hist,bins] = np.histogram(sig_e_spec, bins=bins_spec)
#    xd = (bins[:-1]+bins[1:])/2
#    plt.plot(xd, hist, 'ro')
    plt.legend(['g state','e state'])
    plt.xlabel('FT signal')
    plt.ylabel('Coincidence')
    
    plt.figure()
    plt.plot(freq, spec[1,:],color='r')
    plt.xlim([0,0.05])

def compare_ge_spectrum_hist_zeroDetuning():
    
    ave_n = None
    # ---------------------------
    # g state
    
    fname = getsinglefile('159*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    start = 0
    duration = 3000
    startbg = 6000
    
    totsig = np.sum(rec_all_raw_ave[:,:,start:start+duration],axis=2)
    totsig_bg = np.sum(rec_all_raw_ave[:,:,startbg:startbg+duration],axis=2)
    
    totsig_subbg = np.abs(totsig - totsig_bg)
    sig_g = totsig_subbg[0,:]**2+totsig_subbg[1,:]**2
    ch_a_g = totsig[0,:] - totsig_bg[0,:]
    ch_b_g = totsig[1,:] - totsig_bg[1,:]
    
    
    
#    sig_g = np.abs(totsig)
  
    # ---------------------------
    # e state
    
    fname = getsinglefile('160*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    
    totsig = np.sum(rec_all_raw_ave[:,:,start:start+duration],axis=2)
    totsig_bg = np.sum(rec_all_raw_ave[:,:,startbg:startbg+duration],axis=2)
    
    totsig_subbg = np.abs(totsig - totsig_bg)
    sig_e = totsig_subbg[0,:]**2+totsig_subbg[1,:]**2
    
    
    ch_a_e = totsig[0,:] - totsig_bg[0,:]
    ch_b_e = totsig[1,:] - totsig_bg[1,:]
    
    
    
    plt.figure()
    ax_scatter = plt.axes()
    ax_scatter.scatter(ch_a_g, ch_b_g, c='r', marker='.', alpha=0.5)
    
    ax_scatter.scatter(ch_a_e, ch_b_e, c='b', marker='.', alpha=0.5)

    lim = np.max(np.concatenate((np.abs(ch_a_g),np.abs(ch_b_g))))*1.2
    ax_scatter.set_xlim([-lim, lim])
    ax_scatter.set_ylim([-lim, lim])
    
    ax_scatter.set_aspect(aspect=1)
    plt.xlabel('ch0 read')
    plt.ylabel('ch1 read')
    plt.show()
    
    
    plt.figure()
    
    bins_spec = np.linspace(np.min(sig_g)*1.5,np.max(sig_g)*1.5,50)
    [n1,bins,pa] = plt.hist(sig_g, bins=bins_spec, color = 'b', histtype='step', orientation='vertical')
    print(np.sum(n1))
    
    
#    bins_spec = np.linspace(np.min(sig_g_spec),np.max(sig_g_spec),100)
    [n2,bins,pa] = plt.hist(sig_e, bins=bins_spec, color = 'r', histtype='step', orientation='vertical')
    print(np.sum(n2))
    
    plt.legend(['g state','e state'])
    plt.xlabel('FT signal')
    plt.ylabel('Coincidence')
    plt.show()
    
    
def compare_ge_spectrum_hist_short():
    
    ave_n = None
    # ---------------------------
    # g state
    
    fname = getsinglefile('159*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    start = 300
    duration = 1000
    startbg = 4000
    
    freq, totsig, spec_g = get_dm_spectrum_short(rec_all_raw_ave, indexstart = start,
                                           indexend = start+duration, avenum = ave_n)
    freq, totsig_bg, spec_g_bg = get_dm_spectrum(rec_all_raw_ave, indexstart = startbg,
                                                 indexend = startbg+2000, avenum = ave_n)
    
    sig_g = np.abs(totsig) - np.abs(totsig_bg)
#    sig_g = np.abs(totsig)
    
    spec = spec_g - spec_g_bg
#    spec = spec_g
    
    # integration region
#    freqstartg = 0.010
#    freqendg = 0.017
    
    freqstartg = 0.009
    freqendg = 0.011
    
    findex =  np.where(np.logical_and(freq>freqstartg,freq<freqendg))[0]
    sig_subBg_gstate = np.mean(spec[:,findex],axis=1)
    
    
#    freqstarte = 0.02
#    freqende = 0.023
    
    freqstarte = 0.02
    freqende = 0.022
    
    findex =  np.where(np.logical_and(freq>freqstarte,freq<freqende))[0]
    sig_subBg_estate = np.mean(spec[:,findex],axis=1)
    
    sig_g_spec = sig_subBg_gstate - 1*sig_subBg_estate
#    sig_g_spec = sig_subBg_gstate
    
    # ---------------------------
    # e state
    
    fname = getsinglefile('160*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    
    freq, totsig, spec_e = get_dm_spectrum_short(rec_all_raw_ave, indexstart = start,
                                           indexend = start+duration, avenum = ave_n)
    freq, totsig_bg, spec_e_bg = get_dm_spectrum(rec_all_raw_ave, indexstart = startbg,
                                                 indexend = startbg+2000, avenum = ave_n)    
    
    sig_e = np.abs(totsig) - np.abs(totsig_bg)
#    sig_e = np.abs(totsig)
    
    spec = spec_e - spec_e_bg
#    spec = spec_e
    
    # integration region
#    freqstartg = 0.007
#    freqendg = 0.012
    findex =  np.where(np.logical_and(freq>freqstartg,freq<freqendg))[0]
    sig_subBg_gstate = np.mean(spec[:,findex],axis=1)
    
    
#    freqstarte = 0.018
#    freqende = 0.023
    findex =  np.where(np.logical_and(freq>freqstarte,freq<freqende))[0]
    sig_subBg_estate = np.mean(spec[:,findex],axis=1)
    
    sig_e_spec = sig_subBg_gstate - 1*sig_subBg_estate
#    sig_e_spec = sig_subBg_gstate
    
    
    plt.figure()
    plt.plot(freq, sig_g, 'b')
    plt.plot(freq, sig_e, 'r')
    
    
    plt.xlabel('Freq (GHz)')
    plt.ylabel('Fourier transform')
    plt.xlim([0, 0.05])
    da.autoscale_y(plt.gca())
    
    plt.figure()
    
    bins_spec = np.linspace(np.min(sig_g_spec),np.max(sig_g_spec),50)
    [n1,bins,pa] = plt.hist(sig_g_spec, bins=bins_spec, color = 'b', histtype='step', orientation='vertical')
    print(np.sum(n1))
    
    
#    bins_spec = np.linspace(np.min(sig_g_spec),np.max(sig_g_spec),50)
    [n2,bins,pa] = plt.hist(sig_e_spec, bins=bins_spec, color = 'r', histtype='step', orientation='vertical')
    print(np.sum(n2))
    
    plt.legend(['g state','e state'])
    plt.xlabel('FT signal')
    plt.ylabel('Coincidence')
    
    plt.figure()
    plt.plot(freq, spec[1,:],color='r')
    plt.xlim([0,0.05])

def plot_S_vs_time(ifsave=0):
    
    time = np.append([20, 50, 100, 200, 300, 400], np.arange(500,5001,500))
#    time = [100, 500]
    S = np.zeros(np.size(time))
    for k in np.arange(np.size(time)):
        
        print('===============')
        print('Finish ' + str(k) + ' in ' + str(np.size(time)))
        print('Time @ ' + str(time[k]) + ' ns')
        
        
#        [S[k], p_g, p_e] = get_dm_hist(fileno = [159,160], duration = time[k], 
#                intregion = [0.009, 0.012, 0.019, 0.022], start = 300, startbg = 6000)
#        [S[k], p_g, p_e] = get_dm_hist(fileno = [163,164], duration = time[k], 
#                intregion = [0.008,0.015,0.018,0.021], start = 300, startbg = 6000)
        [S[k], p_g, p_e] = get_coherentReadout_hist(fileno = [12,13], duration = time[k], 
                start = 300, startbg = 6000)
#        [S[k], p_g, p_e] = get_dm_hist(fileno = [165,166], duration = time[k], 
#                intregion = [0.01,0.015,0.018,0.021], start = 300, startbg = 6000)
        
#        [S[k], p_g, p_e] = get_dm_hist(fileno = [167,168], duration = time[k], 
#                intregion = [0.009, 0.012, 0.019, 0.022], start = 300, startbg = 6000)
        
#        [S[k], p_g, p_e] = get_dm_hist(fileno = [169,170], duration = time[k], 
#                intregion = [0.009, 0.012, 0.019, 0.022], start = 300, startbg = 6000)
        
#        [0.008,0.013,0.018,0.022]
        
        
        
    plt.figure()
    plt.plot(time, S, 'ko-')
    
    plt.xlabel('Integration (ns)')
    plt.ylabel('S')
    
    if ifsave:
        root = Tk()
        root.wm_attributes('-topmost', 1)
        savename = asksaveasfile(initialdir='C:\\Data\\2020\\201021_thermal_readout\\02_coherent_readout',parent=root)
        root.destroy() 
        np.savetxt(savename.name, np.array([time,S]).T)

def Bayesian_analyze_theory(ifplot=0):
    [S, p_g, p_e] = get_dm_hist(fileno = [173,174], duration = 2000, 
                intregion = [0.009, 0.012, 0.019, 0.022], start = 300, startbg = 9000)
    sigma = np.abs(p_g[2])
    xd = np.linspace(-sigma*4,sigma*4,500)
    
    
    curve_g = norm_Gaussian(xd, p_g[1], p_g[2])
    curve_e = norm_Gaussian(xd, p_e[1], p_e[2])
        
    if ifplot:
        plt.figure()
        
        
        plt.plot(xd, curve_g/np.max(curve_g), 'b')
        plt.plot(xd, curve_e/np.max(curve_e), 'r')
        
    #    plt.figure()
        
        plt.plot(xd, curve_e/(curve_g+curve_e),'k')
        
        plt.xlabel('FT signal')
        plt.ylabel('probability')
    
    Bcurve = curve_e/(curve_g+curve_e)
    
    return xd, Bcurve

def Bayesian_analyze_Experiment():
    [xd, Bcurve] = Bayesian_analyze_theory(ifplot=0)
    [xdExp, BcurveExp] = get_dm_hist_singlefile(fileno = 172, duration = 2000, 
                intregion = [0.009, 0.012, 0.019, 0.022], 
                start = 1300, startbg = 9000)
    # remember to change the setting for high-power readout in function get_HP_readout()
    
    
    plt.figure()
    plt.plot(xdExp, BcurveExp, 'ko')
    plt.plot(xd, Bcurve, 'r-')
    plt.legend(['Exp','Theory'])
    
    plt.xlabel('FT signal')
    plt.ylabel('prob_e')
    
def plot_S_vs_time_differentPower():
    fileno = np.array([159,163,165,167,169])
    power = np.array([-15,0,-5,-10,-20])
    
    index = np.argsort(power)
    power = power[index]
    fileno = fileno[index]
    
    plt.figure()
    

    for k in np.arange(np.size(fileno)):
        fname = getsinglefile('analyze_'+str(fileno[k])+'*')
        data = np.loadtxt(fname)
        time = data[:,0]
        S = data[:,1]
        plt.plot(time, S, 'o-')
        
    plt.xlabel('Integration (ns)')
    plt.ylabel('S')
    
    plt.legend(['-20 dB','-15 dB','-10 dB','-5 dB','0 dB'])
    
    
def plot_S_vs_time_linearfit():
    fileno = 12
    fitnum = 4
    
#    print('analyze_{fileno:02d}*'.format(fileno=fileno))
    
    fname = getsinglefile('analyze_{fileno:03d}*'.format(fileno=fileno))
    data = np.loadtxt(fname)
    time = data[:,0]
    S = data[:,1]
    plt.plot(time, S, 'o-')
    
    xdata = time[0:fitnum]
    fdata = S[0:fitnum]
    
    startpoint = [1]
    fitfunc = Linear;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(0,500,200)
    plt.plot(xd, fitfunc(xd, *para), 'r-')
    print(para)
    print(perr)
        
    plt.xlabel('Integration (ns)')
    plt.ylabel('S')
    
#    plt.legend(['-20 dB','-15 dB','-10 dB','-5 dB','0 dB'])

def get_coherentReadout_hist(fileno = [12,13], duration =1000, 
                 start = 0, startbg = 7000):
    angle = 95
    
    
    
    startindex = start
    duration = duration
    endindex = startindex + duration
    bgstartindex = startbg
    bgendindex = bgstartindex + duration
    
    fname = getsinglefile('{fileno:03d}*'.format(fileno=fileno[0]))
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    # Rotation angle in iq plane (unit: degree)
#    plt.figure()
    ch0subbg = np.mean(rec_all_raw_ave[0][:,:],axis=0)-np.mean(np.mean(rec_all_raw_ave[0][:,6000:8000],axis=1))
    ch1subbg = np.mean(rec_all_raw_ave[1][:,:],axis=0)-np.mean(np.mean(rec_all_raw_ave[1][:,6000:8000],axis=1))
#    plt.xlim([0,8000])
#    plt.plot(ch0subbg,'r')
#    plt.plot(ch1subbg,'b')
#    plt.xlabel('Time ($\mu$s)')
#    plt.ylabel('Voltage')
#    plt.show()
    
    chg = ch1subbg
   
    rec_int = np.mean(rec_all_raw_ave[:,:,startindex:endindex],axis=2) - np.mean(rec_all_raw_ave[:,:,bgstartindex:bgendindex],axis=2)

    rec_rot = rotate_iq(angle, rec_int) 
    
    ch_a = rec_rot[0]
    ch_b = rec_rot[1]
    
    ch_a_g = ch_a
    ch_b_g = ch_b
    
    fname = getsinglefile('{fileno:03d}*'.format(fileno=fileno[1]))
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    
    plt.figure()
    ch0subbg = np.mean(rec_all_raw_ave[0][:,:],axis=0)-np.mean(np.mean(rec_all_raw_ave[0][:,6000:8000],axis=1))
    ch1subbg = np.mean(rec_all_raw_ave[1][:,:],axis=0)-np.mean(np.mean(rec_all_raw_ave[1][:,6000:8000],axis=1))
    
    ch0subbg_single = rec_all_raw_ave[0][0,:]-np.mean(np.mean(rec_all_raw_ave[0][:,6000:8000],axis=1))
    ch1subbg_single = rec_all_raw_ave[1][20,:]-np.mean(np.mean(rec_all_raw_ave[1][:,6000:8000],axis=1))
    che_single =  ch1subbg_single 
#    plt.xlim([0,8000])
#    plt.plot(ch0subbg,'r')
#    plt.plot(ch1subbg,'b')
#    plt.xlabel('Time ($\mu$s)')
#    plt.ylabel('Voltage')
#    plt.show()
    che = ch1subbg
    
#    plt.plot(che_single,'r-',alpha=0.1)
    
    plt.plot(chg,'b')
    plt.plot(che,'r')
    
    plt.xlabel('Time ($\mu$s)')
    plt.ylabel('Voltage')
    plt.xlim([0,8000])
    plt.show()
    
    
    rec_int = np.mean(rec_all_raw_ave[:,:,startindex:endindex],axis=2) - np.mean(rec_all_raw_ave[:,:,bgstartindex:bgendindex],axis=2)

    rec_rot = rotate_iq(angle, rec_int) 
    
    ch_a = rec_rot[0]
    ch_b = rec_rot[1]
    
    ch_a_e = ch_a
    ch_b_e = ch_b
    
    plt.figure()

    ax_scatter = plt.axes()
    ax_scatter.scatter(ch_a_g, ch_b_g, s=0.5, c='b', marker='.', alpha=0.2)
    ax_scatter.scatter(ch_a_e, ch_b_e, s=0.5, c='r', marker='.', alpha=0.2)
    
    lim = np.max(np.concatenate((np.abs(ch_a_g), np.abs(ch_a_e),
                                 np.abs(ch_b_g), np.abs(ch_b_e))))*1.2
    lim_x = np.max(np.concatenate((np.abs(ch_a_g), np.abs(ch_a_e))))*1.2
    lim_y = np.max(np.concatenate((np.abs(ch_b_g), np.abs(ch_b_e))))*1.2                             
    
    plt.xlabel('ch0')
    plt.ylabel('ch1')
#    lim = 5
    ax_scatter.set_xlim([-lim, lim])
    ax_scatter.set_ylim([-lim, lim])
    plt.gca().set_aspect('equal')
    
    plt.figure()
    sig_g_spec = ch_b_g
    sig_e_spec = ch_b_e
    
    bmin = np.min([np.min(sig_g_spec),np.min(sig_e_spec)])
    bmax = np.max([np.max(sig_g_spec),np.max(sig_e_spec)])
    bins_spec = np.linspace(bmin,bmax,50)
    
    [hist_g,bins] = np.histogram(sig_g_spec, bins=bins_spec)
    [hist_e,bins] = np.histogram(sig_e_spec, bins=bins_spec)
    
    xd = (bins[:-1]+bins[1:])/2
    
    plt.plot(xd, hist_g, 'b.-')
    plt.plot(xd, hist_e, 'r.-')
    plt.legend(['g state','e state'])
    

    plt.xlabel('FT signal')
    plt.ylabel('Coincidence')
    
    startpoint = [np.max(hist_g), 0, np.ptp(xd)/4]
    fitfunc = Gaussian;
    para_g, pcov_g = opt.curve_fit(fitfunc, xd, hist_g, startpoint)
    perr_g = np.sqrt(np.diag(pcov_g))
    
    plt.plot(xd, fitfunc(xd, *para_g), 'b-')
    
    para_e, pcov_e = opt.curve_fit(fitfunc, xd, hist_e, startpoint)
    perr_e = np.sqrt(np.diag(pcov_e))
    
    plt.plot(xd, fitfunc(xd, *para_e), 'r-')
    
    
    S = (2*(para_g[1]-para_e[1])/(np.abs(para_g[2])+np.abs(para_e[2])))**2
    
    print('S = ' + str(S))
    plt.show()
    
    return S, para_g, para_e


def getWeight_afterRot(fileno = [12,13], duration =1000, 
                 start = 100, startbg = 7000, angle = 95, ifplot=0):
    startindex = start
    duration = duration
    endindex = startindex + duration
    bgstartindex = startbg
    bgendindex = bgstartindex + duration
    
    fname = getsinglefile('{fileno:03d}*'.format(fileno=fileno[0]))
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    meanrec = np.mean(rec_all_raw_ave[:,:,:],axis=1)
    meanrec_rot = rotate_iq(angle, meanrec)
    meanch_b_g = meanrec_rot[1] - np.mean(meanrec_rot[1][bgstartindex:bgendindex])
    
    
    fname = getsinglefile('{fileno:03d}*'.format(fileno=fileno[1]))
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    meanrec = np.mean(rec_all_raw_ave[:,:,:],axis=1)
    meanrec_rot = rotate_iq(angle, meanrec)
    meanch_b_e = meanrec_rot[1] - np.mean(meanrec_rot[1][bgstartindex:bgendindex])
    weight = meanch_b_e - meanch_b_g
    if ifplot:
        plt.figure()
        plt.plot(meanch_b_e,'r')
        plt.plot(meanch_b_g,'b')
        plt.xlim([0,2000])
    
    
        plt.plot(weight,'k')

    return weight

def getWeight_beforeRot(fileno = [12,13], duration =1000, 
                 start = 100, startbg = 7000, angle = 95, ifplot=0):
    startindex = start
    duration = duration
    endindex = startindex + duration
    bgstartindex = startbg
    bgendindex = bgstartindex + duration
    
    fname = getsinglefile('{fileno:03d}*'.format(fileno=fileno[0]))
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    meanrec = np.mean(rec_all_raw_ave[:,:,:],axis=1)
    bg = np.mean(meanrec[:,bgstartindex:bgendindex],axis=1)
    bg = np.reshape(bg,[np.shape(bg)[0],1])
    bgmatrix = np.tile(bg, (1,np.shape(meanrec)[1]))
    mean_g = meanrec[:] - bgmatrix
    
    
    fname = getsinglefile('{fileno:03d}*'.format(fileno=fileno[1]))
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    meanrec = np.mean(rec_all_raw_ave[:,:,:],axis=1)
    bg = np.mean(meanrec[:,bgstartindex:bgendindex],axis=1)
    bg = np.reshape(bg,[np.shape(bg)[0],1])
    bgmatrix = np.tile(bg, (1,np.shape(meanrec)[1]))
    mean_e = meanrec[:] - bgmatrix
    
    weight = mean_e - mean_g
    
    print(np.shape(bgmatrix))
    if ifplot:
        plt.figure()
    
        plt.plot(weight[0,:],'r')
        plt.plot(weight[1,:],'b')
        plt.legend(['ch0','ch1'])

    return weight

def get_coherentReadout_hist_withWeight_afterRot(fileno = [12,13], duration =1000, 
                 start = 0, startbg = 7000):
    angle = 95
    
    
    
    startindex = start
    duration = duration
    endindex = startindex + duration
    bgstartindex = startbg
    bgendindex = bgstartindex + duration
    
    
    
    
    
    fname = getsinglefile('{fileno:03d}*'.format(fileno=fileno[0]))
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    weight = getWeight_afterRot(fileno, duration, 
                 start, startbg, angle)
    wd = np.reshape(weight,(1,1,np.shape(rec_all_raw_ave)[2]))
    print(np.shape(wd))
    print(np.shape(rec_all_raw_ave))
    weightmatrix = np.tile(wd,(np.shape(rec_all_raw_ave)[0],np.shape(rec_all_raw_ave)[1],1))
    bg = np.mean(rec_all_raw_ave[:,:,bgstartindex:bgendindex],axis=2)
    bg = np.reshape(bg,[np.shape(bg)[0],np.shape(bg)[1],1])
    bgmatrix = np.tile(bg,(1,1,np.shape(rec_all_raw_ave)[2]))
    rec_all_raw_ave = (rec_all_raw_ave-bgmatrix) * weightmatrix
    
    rec_int = np.mean(rec_all_raw_ave[:,:,startindex:endindex],axis=2) - np.mean(rec_all_raw_ave[:,:,bgstartindex:bgendindex],axis=2)

    rec_rot = rotate_iq(angle, rec_int) 

    
    ch_a = rec_rot[0]
    ch_b = rec_rot[1]
    
    ch_a_g = ch_a
    ch_b_g = ch_b
    
    fname = getsinglefile('{fileno:03d}*'.format(fileno=fileno[1]))
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    bg = np.mean(rec_all_raw_ave[:,:,bgstartindex:bgendindex],axis=2)
    bg = np.reshape(bg,[np.shape(bg)[0],np.shape(bg)[1],1])
    bgmatrix = np.tile(bg,(1,1,np.shape(rec_all_raw_ave)[2]))
    rec_all_raw_ave = (rec_all_raw_ave-bgmatrix) * weightmatrix

    
    plt.figure()
    plt.plot(rec_all_raw_ave[0,0,:],'r')
    plt.plot(rec_all_raw_ave[0,1,:],'b')
    plt.show()
    
    rec_int = np.mean(rec_all_raw_ave[:,:,startindex:endindex],axis=2) - np.mean(rec_all_raw_ave[:,:,bgstartindex:bgendindex],axis=2)

    rec_rot = rotate_iq(angle, rec_int) 
    
    ch_a = rec_rot[0]
    ch_b = rec_rot[1]
    
    ch_a_e = ch_a
    ch_b_e = ch_b
    
    plt.figure()

    ax_scatter = plt.axes()
    ax_scatter.scatter(ch_a_g, ch_b_g, s=0.5, c='b', marker='.', alpha=0.2)
    ax_scatter.scatter(ch_a_e, ch_b_e, s=0.5, c='r', marker='.', alpha=0.2)
    
    lim = np.max(np.concatenate((np.abs(ch_a_g), np.abs(ch_a_e),
                                 np.abs(ch_b_g), np.abs(ch_b_e))))*1.2
    lim_x = np.max(np.concatenate((np.abs(ch_a_g), np.abs(ch_a_e))))*1.2
    lim_y = np.max(np.concatenate((np.abs(ch_b_g), np.abs(ch_b_e))))*1.2                             
    
    plt.xlabel('ch0')
    plt.ylabel('ch1')
#    lim = 5
    ax_scatter.set_xlim([-lim, lim])
    ax_scatter.set_ylim([-lim, lim])
    plt.gca().set_aspect('equal')
    
    plt.figure()
    sig_g_spec = ch_b_g
    sig_e_spec = ch_b_e
    
    bmin = np.min([np.min(sig_g_spec),np.min(sig_e_spec)])
    bmax = np.max([np.max(sig_g_spec),np.max(sig_e_spec)])
    bins_spec = np.linspace(bmin,bmax,50)
    
    [hist_g,bins] = np.histogram(sig_g_spec, bins=bins_spec)
    [hist_e,bins] = np.histogram(sig_e_spec, bins=bins_spec)
    
    xd = (bins[:-1]+bins[1:])/2
    
    plt.plot(xd, hist_g, 'b.-')
    plt.plot(xd, hist_e, 'r.-')
    plt.legend(['g state','e state'])
    

    plt.xlabel('FT signal')
    plt.ylabel('Coincidence')
    
    startpoint = [np.max(hist_g), 0, np.ptp(xd)/4]
    fitfunc = Gaussian;
    para_g, pcov_g = opt.curve_fit(fitfunc, xd, hist_g, startpoint)
    perr_g = np.sqrt(np.diag(pcov_g))
    
    plt.plot(xd, fitfunc(xd, *para_g), 'b-')
    
    para_e, pcov_e = opt.curve_fit(fitfunc, xd, hist_e, startpoint)
    perr_e = np.sqrt(np.diag(pcov_e))
    
    plt.plot(xd, fitfunc(xd, *para_e), 'r-')
    
    
    S = (2*(para_g[1]-para_e[1])/(np.abs(para_g[2])+np.abs(para_e[2])))**2
    
    print('S = ' + str(S))
    plt.show()
    
    return S, para_g, para_e

def get_coherentReadout_hist_withWeight_beforeRot(fileno = [12,13], duration =1000, 
                 start = 0, startbg = 7000):
    angle = 95
    
    
    
    startindex = start
    duration = duration
    endindex = startindex + duration
    bgstartindex = startbg
    bgendindex = bgstartindex + duration
    
    
    
    
    
    fname = getsinglefile('{fileno:03d}*'.format(fileno=fileno[0]))
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    weight = getWeight_beforeRot(fileno, duration, 
                 start, startbg, angle)
    wd = np.reshape(weight,(np.shape(rec_all_raw_ave)[0],1,np.shape(rec_all_raw_ave)[2]))
    print(np.shape(wd))
    print(np.shape(rec_all_raw_ave))
    weightmatrix = np.tile(wd,(1,np.shape(rec_all_raw_ave)[1],1))
    bg = np.mean(rec_all_raw_ave[:,:,bgstartindex:bgendindex],axis=2)
    bg = np.reshape(bg,[np.shape(bg)[0],np.shape(bg)[1],1])
    bgmatrix = np.tile(bg,(1,1,np.shape(rec_all_raw_ave)[2]))
    rec_all_raw_ave = (rec_all_raw_ave-bgmatrix) * weightmatrix
    
    rec_int = np.mean(rec_all_raw_ave[:,:,startindex:endindex],axis=2) - np.mean(rec_all_raw_ave[:,:,bgstartindex:bgendindex],axis=2)

    rec_rot = rotate_iq(angle, rec_int) 

    
    ch_a = rec_rot[0]
    ch_b = rec_rot[1]
    
    ch_a_g = ch_a
    ch_b_g = ch_b
    
    fname = getsinglefile('{fileno:03d}*'.format(fileno=fileno[1]))
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    bg = np.mean(rec_all_raw_ave[:,:,bgstartindex:bgendindex],axis=2)
    bg = np.reshape(bg,[np.shape(bg)[0],np.shape(bg)[1],1])
    bgmatrix = np.tile(bg,(1,1,np.shape(rec_all_raw_ave)[2]))
    rec_all_raw_ave = (rec_all_raw_ave-bgmatrix) * weightmatrix

    
    plt.figure()
    plt.plot(rec_all_raw_ave[0,0,:],'r')
    plt.plot(rec_all_raw_ave[0,1,:],'b')
    plt.show()
    
    rec_int = np.mean(rec_all_raw_ave[:,:,startindex:endindex],axis=2) - np.mean(rec_all_raw_ave[:,:,bgstartindex:bgendindex],axis=2)

    rec_rot = rotate_iq(angle, rec_int) 
    
    ch_a = rec_rot[0]
    ch_b = rec_rot[1]
    
    ch_a_e = ch_a
    ch_b_e = ch_b
    
    plt.figure()

    ax_scatter = plt.axes()
    ax_scatter.scatter(ch_a_g, ch_b_g, s=0.5, c='b', marker='.', alpha=0.2)
    ax_scatter.scatter(ch_a_e, ch_b_e, s=0.5, c='r', marker='.', alpha=0.2)
    
    lim = np.max(np.concatenate((np.abs(ch_a_g), np.abs(ch_a_e),
                                 np.abs(ch_b_g), np.abs(ch_b_e))))*1.2
    lim_x = np.max(np.concatenate((np.abs(ch_a_g), np.abs(ch_a_e))))*1.2
    lim_y = np.max(np.concatenate((np.abs(ch_b_g), np.abs(ch_b_e))))*1.2                             
    
#    lim = 5
    
    plt.xlabel('ch0')
    plt.ylabel('ch1')
    ax_scatter.set_xlim([-lim, lim])
    ax_scatter.set_ylim([-lim, lim])
    plt.gca().set_aspect('equal')
    
    plt.figure()
    sig_g_spec = ch_b_g
    sig_e_spec = ch_b_e
    
    bmin = np.min([np.min(sig_g_spec),np.min(sig_e_spec)])
    bmax = np.max([np.max(sig_g_spec),np.max(sig_e_spec)])
    bins_spec = np.linspace(bmin,bmax,50)
    
    [hist_g,bins] = np.histogram(sig_g_spec, bins=bins_spec)
    [hist_e,bins] = np.histogram(sig_e_spec, bins=bins_spec)
    
    xd = (bins[:-1]+bins[1:])/2
    
    plt.plot(xd, hist_g, 'b.-')
    plt.plot(xd, hist_e, 'r.-')
    plt.legend(['g state','e state'])
    

    plt.xlabel('FT signal')
    plt.ylabel('Coincidence')
    
    startpoint = [np.max(hist_g), 0, np.ptp(xd)/4]
    fitfunc = Gaussian;
    para_g, pcov_g = opt.curve_fit(fitfunc, xd, hist_g, startpoint)
    perr_g = np.sqrt(np.diag(pcov_g))
    
    plt.plot(xd, fitfunc(xd, *para_g), 'b-')
    
    para_e, pcov_e = opt.curve_fit(fitfunc, xd, hist_e, startpoint)
    perr_e = np.sqrt(np.diag(pcov_e))
    
    plt.plot(xd, fitfunc(xd, *para_e), 'r-')
    
    
    S = (2*(para_g[1]-para_e[1])/(np.abs(para_g[2])+np.abs(para_e[2])))**2
    
    print('S = ' + str(S))
    plt.show()
    
    return S, para_g, para_e

def checknoise(fileno = [4,5], duration = 1000, 
                 start = 6000,startbg=6000):
    angle = 110
    
    
    startindex = start
    duration = duration
    endindex = startindex + duration
    bgstartindex = startbg
    bgendindex = bgstartindex + duration
    
    fname = getsinglefile('{fileno:03d}*'.format(fileno=fileno[0]))
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    # Rotation angle in iq plane (unit: degree)
    
   
    rec_int = np.mean(rec_all_raw_ave[:,:,startindex:endindex],axis=2)

#    rec_rot = rotate_iq(angle, rec_int) 
    
    ch_a = rec_int[0]-np.mean(np.mean(rec_all_raw_ave[0,:,bgstartindex:bgendindex],axis=1))
    ch_b = rec_int[1]-np.mean(np.mean(rec_all_raw_ave[1,:,bgstartindex:bgendindex],axis=1))
    
    ch_a_g = ch_a
    ch_b_g = ch_b
    
    
    ch_a_e = ch_a
    ch_b_e = ch_b
    
    plt.figure()

    ax_scatter = plt.axes()
    ax_scatter.scatter(ch_a_g, ch_b_g, s=0.5, c='b', marker='.', alpha=0.2)
    ax_scatter.scatter(ch_a_e, ch_b_e, s=0.5, c='r', marker='.', alpha=0.2)
    
    lim = np.max(np.concatenate((np.abs(ch_a_g), np.abs(ch_a_e),
                                 np.abs(ch_b_g), np.abs(ch_b_e))))*1.2
    lim_x = np.max(np.concatenate((np.abs(ch_a_g), np.abs(ch_a_e))))*1.2
    lim_y = np.max(np.concatenate((np.abs(ch_b_g), np.abs(ch_b_e))))*1.2                             
    
#    lim = 5
    ax_scatter.set_xlim([-lim, lim])
    ax_scatter.set_ylim([-lim, lim])
    plt.gca().set_aspect('equal')
    
    plt.figure()
    sig_g_spec = ch_b_g
    sig_e_spec = ch_b_e
    
    bmin = np.min([np.min(sig_g_spec),np.min(sig_e_spec)])
    bmax = np.max([np.max(sig_g_spec),np.max(sig_e_spec)])
    bins_spec = np.linspace(bmin,bmax,50)
    
    [hist_g,bins] = np.histogram(sig_g_spec, bins=bins_spec)
    [hist_e,bins] = np.histogram(sig_e_spec, bins=bins_spec)
    
    xd = (bins[:-1]+bins[1:])/2
    
    plt.plot(xd, hist_g, 'b.-')
    plt.plot(xd, hist_e, 'r.-')
    plt.legend(['g state','e state'])
    

    plt.xlabel('FT signal')
    plt.ylabel('Coincidence')
    
#    startpoint = [np.max(hist_g), 0, np.ptp(xd)/4]
#    fitfunc = Gaussian;
#    para_g, pcov_g = opt.curve_fit(fitfunc, xd, hist_g, startpoint)
#    perr_g = np.sqrt(np.diag(pcov_g))
#    
#    plt.plot(xd, fitfunc(xd, *para_g), 'b-')
#    
#    para_e, pcov_e = opt.curve_fit(fitfunc, xd, hist_e, startpoint)
#    perr_e = np.sqrt(np.diag(pcov_e))
#    
#    plt.plot(xd, fitfunc(xd, *para_e), 'r-')
#    
#    
#    S = (2*(para_g[1]-para_e[1])/(np.abs(para_g[2])+np.abs(para_e[2])))**2
#    
#    print('S = ' + str(S))
#    plt.show()
    


def get_dm_hist(fileno = [159,160], duration = 1000, 
                intregion = [0.009, 0.012, 0.019, 0.022], start = 300, startbg = 6000):
    
    ave_n = None
    
    # =================
    # g state
    
    fname = getsinglefile(str(fileno[0])+'*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    
    freq, totsig, spec_g = get_dm_spectrum(rec_all_raw_ave, indexstart = start,
                                           indexend = start+duration, avenum = ave_n)
    freq, totsig_bg, spec_g_bg = get_dm_spectrum(rec_all_raw_ave, indexstart = startbg,
                                                 indexend = startbg+duration, avenum = ave_n)
    
    sig_g = np.abs(totsig) - np.abs(totsig_bg)
    
    spec = spec_g - spec_g_bg
       
    freqstartg = intregion[0]
    freqendg = intregion[1]
    
    findex =  np.where(np.logical_and(freq>freqstartg,freq<freqendg))[0]
    sig_subBg_gstate = np.sum(spec[:,findex],axis=1)
    
    
    freqstarte = intregion[2]
    freqende = intregion[3]
    
    findex =  np.where(np.logical_and(freq>freqstarte,freq<freqende))[0]
    sig_subBg_estate = np.sum(spec[:,findex],axis=1)
    
    sig_g_spec = sig_subBg_gstate - sig_subBg_estate
    
    # =================
    # e state
    
    fname = getsinglefile(str(fileno[1])+'*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    
    freq, totsig, spec_e = get_dm_spectrum(rec_all_raw_ave, indexstart = start,
                                           indexend = start+duration, avenum = ave_n)
    freq, totsig_bg, spec_e_bg = get_dm_spectrum(rec_all_raw_ave, indexstart = startbg,
                                                 indexend = startbg+duration, avenum = ave_n)
    
    sig_e = np.abs(totsig) - np.abs(totsig_bg)
    
    spec = spec_e - spec_e_bg
       
    
    findex =  np.where(np.logical_and(freq>freqstartg,freq<freqendg))[0]
    sig_subBg_gstate = np.sum(spec[:,findex],axis=1)
    
    
    
    findex =  np.where(np.logical_and(freq>freqstarte,freq<freqende))[0]
    sig_subBg_estate = np.sum(spec[:,findex],axis=1)
    
    sig_e_spec = sig_subBg_gstate - sig_subBg_estate

    
   
    plt.figure()
    plt.plot(freq, sig_g, 'b.-')
    plt.plot(freq, sig_e, 'r.-')
    
    
    plt.xlabel('Freq (GHz)')
    plt.ylabel('Fourier transform')
    plt.xlim([0, 0.05])
    
    plt.legend(['g state','e state'])
    
    da.autoscale_y(plt.gca())
    
    plt.figure()
    bmin = np.min([np.min(sig_g_spec),np.min(sig_e_spec)])
    bmax = np.max([np.max(sig_g_spec),np.max(sig_e_spec)])
    bins_spec = np.linspace(bmin,bmax,50)
    
    [hist_g,bins] = np.histogram(sig_g_spec, bins=bins_spec)
    [hist_e,bins] = np.histogram(sig_e_spec, bins=bins_spec)
    
    xd = (bins[:-1]+bins[1:])/2
    
    plt.plot(xd, hist_g, 'b.-')
    plt.plot(xd, hist_e, 'r.-')
    plt.legend(['g state','e state'])
    

    plt.xlabel('FT signal')
    plt.ylabel('Coincidence')
    
    startpoint = [np.max(hist_g), 0, np.ptp(xd)/4]
    fitfunc = Gaussian;
    para_g, pcov_g = opt.curve_fit(fitfunc, xd, hist_g, startpoint)
    perr_g = np.sqrt(np.diag(pcov_g))
    
    plt.plot(xd, fitfunc(xd, *para_g), 'b-')
    
    para_e, pcov_e = opt.curve_fit(fitfunc, xd, hist_e, startpoint)
    perr_e = np.sqrt(np.diag(pcov_e))
    
    plt.plot(xd, fitfunc(xd, *para_e), 'r-')
    
    
    S = (2*(para_g[1]-para_e[1])/(np.abs(para_g[2])+np.abs(para_e[2])))**2
    
    print('S = ' + str(S))
    plt.show()
    
    return S, para_g, para_e

def get_dm_hist_singlefile(fileno = 172, duration = 2000, 
                intregion = [0.009, 0.012, 0.019, 0.022], 
                start = 1300, startbg = 9000, ifplot=0):
    
    ave_n = None
    
    # =================
    # g state
    
    fname = getsinglefile(str(fileno)+'*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    
    freq, totsig, spec_g = get_dm_spectrum(rec_all_raw_ave, indexstart = start,
                                           indexend = start+duration, avenum = ave_n)
    freq, totsig_bg, spec_g_bg = get_dm_spectrum(rec_all_raw_ave, indexstart = startbg,
                                                 indexend = startbg+duration, avenum = ave_n)
    
    sig_g = np.abs(totsig) - np.abs(totsig_bg)
    
    spec = spec_g - spec_g_bg
       
    freqstartg = intregion[0]
    freqendg = intregion[1]
    
    findex =  np.where(np.logical_and(freq>freqstartg,freq<freqendg))[0]
    sig_subBg_gstate = np.sum(spec[:,findex],axis=1)
    
    
    freqstarte = intregion[2]
    freqende = intregion[3]
    
    findex =  np.where(np.logical_and(freq>freqstarte,freq<freqende))[0]
    sig_subBg_estate = np.sum(spec[:,findex],axis=1)
    
    sig_g_spec = sig_subBg_gstate - sig_subBg_estate
    
    
    if ifplot:
        plt.figure()
        plt.plot(freq, sig_g, 'b.-')
    #    plt.plot(freq, sig_e, 'r.-')
        
        
        plt.xlabel('Freq (GHz)')
        plt.ylabel('Fourier transform')
        plt.xlim([0, 0.05])
        
        plt.legend(['g state','e state'])
        
        da.autoscale_y(plt.gca())
        
    
    bmin = np.min(sig_g_spec)
    bmax = np.max(sig_g_spec)
    bins_spec = np.linspace(bmin,bmax,50)
    
    [hist_g,bins] = np.histogram(sig_g_spec, bins=bins_spec)
#    [hist_e,bins] = np.histogram(sig_e_spec, bins=bins_spec)
    
    xd = (bins[:-1]+bins[1:])/2
    
    if ifplot:
        plt.figure()
        plt.plot(xd, hist_g, 'b.-')
        
    
        plt.xlabel('FT signal')
        plt.ylabel('Coincidence')
    
    state = get_HP_readout()
    
    prob_e = np.zeros(np.size(hist_g))
    for k in np.arange(np.size(hist_g)):
        index = np.where(np.logical_and(
                sig_g_spec>=bins[k],sig_g_spec<bins[k+1]))
        if k == np.size(hist_g)-1:
            index = np.where(np.logical_and(
                sig_g_spec>=bins[k],sig_g_spec<=bins[k+1]))
        substate = state[index]
        if np.size(substate)>0:
            prob_e[k] = np.size(np.where(substate==1))/np.size(substate)
        else:   
            prob_e[k] = 0
    
    if ifplot:    
        plt.figure()
        plt.plot(xd, prob_e)
        
    return xd, prob_e


def get_HP_readout(fileno = 172, startindex = 4100, 
                   duration = 500, bgstartindex = 9000, ifplot=0):
    
    fname = getsinglefile(str(fileno)+'*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    endindex = startindex + duration
    bgendindex = bgstartindex + duration
    
    # Rotation angle in iq plane (unit: degree)
    angle = -170
    
    # cutoff value to determine qubit in g or e state (run compare_ge_readout to get this value)
    cutoff = 10.7
   
    rec_int = np.mean(rec_all_raw_ave[:,:,startindex:endindex],axis=2) - np.mean(rec_all_raw_ave[:,:,bgstartindex:bgendindex],axis=2)

    rec_rot = rotate_iq(angle, rec_int) 
    
    ch_a = rec_rot[0]
    ch_b = rec_rot[1]
    
   
    prob_g = np.size(np.where(ch_b<=cutoff))/np.size(ch_b)
    prob_e = 1-prob_g
    
    state = ch_b
    index_g = np.where(ch_b<=cutoff)[0]
    index_e = np.where(ch_b>cutoff)[0]
        
    state[index_g] = 0
    state[index_e] = 1
    
    if ifplot:
        plt.figure()
        plt.plot(state)  
        plt.xlim([0,100])
    
    print(prob_e)
        
        
    return state
    
def get_dm_spectrum(data, indexstart = 0, indexend = 3000, avenum = None):

    rec_all_raw_ave = data
    print(np.shape(rec_all_raw_ave))   
    xdata = np.arange(np.shape(rec_all_raw_ave)[2])
    index = np.where(np.logical_and(xdata>indexstart,xdata<indexend))
    xdata = xdata[index[0]]
    
    if avenum==None:
        avenum = np.shape(rec_all_raw_ave)[1]
    sig_g = np.zeros(avenum)
    sig_e = np.zeros(avenum)
    
    spec = np.zeros((avenum, np.size(xdata)))
    for k in np.arange(avenum):
        xdata = np.arange(np.shape(rec_all_raw_ave)[2])
        signal_i = rec_all_raw_ave[0][k,:]
        signal_q = rec_all_raw_ave[1][k,:]        
        index = np.where(np.logical_and(xdata>indexstart,xdata<indexend))
        xdata = xdata[index[0]]
        
       
        
        signal = signal_i[index[0]] + 1j * signal_q[index[0]]
#        signal = signal_q[index[0]]
        
        fourier = np.fft.fft(signal)
        n = signal.size
        timestep = xdata[2]-xdata[1]
        freq = np.fft.fftfreq(n, d=timestep)
        spec[k,:] = np.abs(fourier)
        if k == 0:
            totsig = np.abs(fourier)
#            print(index[0])

        else:
            totsig = totsig + np.abs(fourier)
        
            
    totsig = totsig/avenum
    index = np.where(freq>=0)
    freq = freq[index[0]]
    totsig = totsig[index[0]] + totsig[np.size(xdata)-1-index[0]]
    spec = spec[:,index[0]] + spec[:,np.size(xdata)-1-index[0]]
    
    
    return freq, totsig, spec


def compare_ge_spectrum_short(ave_n = None):
    
    
    start = 300
    duration = 500
    bgstart = 4000
    
    # ---------------------------
    # g state
    
    fname = getsinglefile('163*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    freq, totsig, spec_g = get_dm_spectrum_short(rec_all_raw_ave, indexstart = start, indexend = start+duration, avenum = ave_n)
    freq, totsig_bg, spec_g_bg = get_dm_spectrum(rec_all_raw_ave, indexstart = 4000, indexend = 6000, avenum = ave_n)
    
    print([np.size(totsig), np.size(totsig_bg)])
    sig_g = np.abs(totsig) - np.abs(totsig_bg)
    
    
  
    # ---------------------------
    # e state
    
    fname = getsinglefile('164*')
    data = io.loadmat(fname)
    rec_all_raw_ave = data['rec_all_raw_ave']
    
    
    freq, totsig, spec_e = get_dm_spectrum_short(rec_all_raw_ave, indexstart = start, indexend = start+duration, avenum = ave_n)
    freq, totsig_bg, spec_e_bg = get_dm_spectrum(rec_all_raw_ave, indexstart = 4000, indexend = 6000, avenum = ave_n)
    
    sig_e = np.abs(totsig) - np.abs(totsig_bg)
    
    spec = spec_e - spec_e_bg
    
   
    plt.figure()
    plt.plot(freq, sig_g, 'b.-')
    plt.plot(freq, sig_e, 'r.-')
    
    
    plt.xlabel('Freq (GHz)')
    plt.ylabel('Fourier transform')
    plt.xlim([0, 0.05])
    da.autoscale_y(plt.gca())
    
def get_dm_spectrum_short(data, indexstart = 0, indexend = 300, duration=2000, avenum = None):

    rec_all_raw_ave = data
    print(np.shape(rec_all_raw_ave))   
    xdata_i = np.arange(np.shape(rec_all_raw_ave)[2])
    index1 = np.where(np.logical_and(xdata_i>indexstart,xdata_i<indexend))    
    index2 = np.where(np.logical_and(xdata_i>4000,xdata_i<4000+duration-np.size(index1[0])))
    index = np.append(index1[0],index2[0])
    xdata = xdata_i[index]
    
    if avenum==None:
        avenum = np.shape(rec_all_raw_ave)[1]
    sig_g = np.zeros(avenum)
    sig_e = np.zeros(avenum)
    
    spec = np.zeros((avenum, np.size(xdata)))
    for k in np.arange(avenum):
        xdata_i = np.arange(np.shape(rec_all_raw_ave)[2])
        signal_i = rec_all_raw_ave[0][k,:]
        signal_q = rec_all_raw_ave[1][k,:]        
        index1 = np.where(np.logical_and(xdata_i>indexstart,xdata_i<indexend))
        
        
        
        index2 = np.where(np.logical_and(xdata_i>4000,xdata_i<4000+duration-np.size(index1[0])))
        index = np.append(index1[0],index2[0])
        xdata = xdata_i[index]
        
        signal = signal_i[index] + 1j * signal_q[index]
        fourier = np.fft.fft(signal)
        n = signal.size
        timestep = xdata[2]-xdata[1]
        freq = np.fft.fftfreq(n, d=timestep)
        spec[k,:] = np.abs(fourier)
        if k == 0:
            totsig = np.abs(fourier)
#            print(index[0])
        else:
            totsig = totsig + np.abs(fourier)
        
            
    totsig = totsig/avenum
    index = np.where(freq>0)
    freq = freq[index[0]]
    totsig = totsig[index[0]] + totsig[np.size(xdata)-1-index[0]]
    spec = spec[:,index[0]] + spec[:,np.size(xdata)-1-index[0]]
    return freq, totsig, spec

    
def plotFTspectrum147():
    fname = getsinglefile('146*')
    
    data = io.loadmat(fname)
    
    xdata = data['freq']
    ydata = data['mean_spec']
    xdata = np.reshape(xdata, np.size(xdata))
    ydata = np.reshape(ydata, np.size(ydata))
    
    print(np.shape(ydata))
    plt.figure()
    plt.plot(xdata,ydata,'r')
    
    fname = getsinglefile('147*')
    
    data = io.loadmat(fname)
    
    xdata = data['freq']
    ydata = data['mean_spec']
    xdata = np.reshape(xdata, np.size(xdata))
    ydata = np.reshape(ydata, np.size(ydata))

    plt.plot(xdata,ydata,'b')
    
    plt.xlim([-0.05,0.05])
    autoscale_y(plt.gca())
    
    plt.legend(['0 dB', '-60 dB'])
    plt.xlabel('Freq (GHz)')
    plt.ylabel('FT signal')
    plt.show()
    
def plotvaccum_fluctuation_T1single():
    fname = getsinglefile('148*')
    data = np.loadtxt(fname)
    xdata = data[:,0]
#    ydata = np.linspace(30,0,31)
    fdata = data[:,1]
    fig = plt.figure()
    l1, = plt.plot(xdata, fdata, 'ko')
    startpoint = [1, 1/2*np.max(xdata), fdata[-1]]
    fitfunc = ExpDecay;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    startpoint = [0.5, np.max(xdata)/2, 2/np.max(xdata), 0, 0.5, 1]
#    fitfunc = ExpOscDecay_n;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(0,np.max(xdata),200)
    plt.plot(xd, fitfunc(xd, *para), 'r-')
    print(para)
    print(perr)
    plt.xlabel('Time ($\mu$s)')
    plt.ylabel('FT signal')    
    
    fname = getsinglefile('149*')
    data = np.loadtxt(fname)
    xdata = data[:,0]
#    ydata = np.linspace(30,0,31)
    fdata = data[:,1]
    
    l2, = plt.plot(xdata, fdata, 'bo')
    
    plt.legend([l1,l2],['qubit in e','qubit in g'])
    

def plotspectrum():
    fname = getsinglefile('175*')
    data = np.loadtxt(fname)
    xdata = np.linspace(5.64609, 5.746, np.size(data))
    plt.figure()
    plt.plot(xdata,data,'r')
    
    fname = getsinglefile('176*')
    data = np.loadtxt(fname)
    xdata = np.linspace(5.64609, 5.746, np.size(data))
    plt.plot(xdata,data,'b')
    
    plt.xlabel('Frequency (GHz)')
    plt.ylabel('Signal (dB)')
    
    plt.figure()
    
    fname = getsinglefile('176*')
    data = np.loadtxt(fname)
    
    fname = getsinglefile('175*')
    databg = np.loadtxt(fname)
    xdata = np.linspace(5.64609, 5.746, np.size(data))
    plt.plot(xdata,data-databg,'k')
    
    plt.xlabel('Frequency (GHz)')
    plt.ylabel('Signal (dB)')
    
    fname = getsinglefile('177*')
    gain = np.loadtxt(fname)
    freq = np.linspace(5.65,5.75,np.size(gain))
    
    gain = 10**(gain/10)
    T_pa =0.5
    T_Hemt = 10
    expectNoise = 10 * np.log10( (gain*T_pa+T_Hemt)/(T_Hemt) )
    
    plt.plot(freq, expectNoise, 'r')


def plotspectrum_099():
    fname = getsinglefile('099*')
    data = np.loadtxt(fname)
    xdata = np.linspace(5.456, 5.756, np.size(data))
    plt.figure()
    plt.plot(xdata,data,'k')
    plt.ylim([0,20])
    plt.plot(5.606*np.array([1,1]), plt.gca().get_ylim(), 'r--')
    plt.plot(5.6185*np.array([1,1]), plt.gca().get_ylim(), 'b--')
    plt.xlabel('Frequency (GHz)')
    plt.ylabel('Signal (dB)')
    
 

def plot_single_acStark():
    fname = getsinglefile('028*')
    data = np.loadtxt(fname)
    freq = data[:,0]
    prob = data[:,1]
    
    plt.figure()
    plt.plot(freq,prob,'k.-')
    
#    xdata = freq
#    fdata = prob
#    startpoint = [5.014, 0.001, np.ptp(fdata), np.min(fdata)]
    
    fname = getsinglefile('029*')
    data = np.loadtxt(fname)
    freq = data[:,0]
    prob = data[:,1]

    plt.plot(freq,prob,'r.-')
    
    
    fname = getsinglefile('030*')
    data = np.loadtxt(fname)
    freq = data[:,0]
    prob = data[:,1]

    plt.plot(freq,prob,'b.-')
    
    plt.legend(['No noise','-20 dB','-10 dB'])
    plt.xlabel('$\Delta f$ (GHz)')
    plt.ylabel('Population e')
    
    
    
    
    xdata = freq
    fdata = prob
    startpoint = [5.014, 0.001, np.ptp(fdata), np.min(fdata)]
    
#    fitfunc = lorentz;
#    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
#    
#    perr = np.sqrt(np.diag(pcov))
#    xd = np.linspace(np.min(xdata),np.max(xdata),200)
#    l1, = plt.plot(xd, fitfunc(xd, *para), 'r-')
#    print(para)
#    
#    c0 = para[0]
    
def plot_acStark_spectrum():
    fname = getsinglefile('016*')
    data = np.loadtxt(fname)
    freq = data[:,0]
    prob = data[:,1]
    
    plt.figure()
    plt.plot(freq,prob,'r.')
    
    xdata = freq
    fdata = prob
    startpoint = [5.014, 0.001, np.ptp(fdata), np.min(fdata)]
    
    fitfunc = lorentz;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(np.min(xdata),np.max(xdata),200)
    l1, = plt.plot(xd, fitfunc(xd, *para), 'r-')
    print(para)
    
    c0 = para[0]
    
    fname = getsinglefile('017*')
    data = np.loadtxt(fname)
    freq = data[:,0]
    prob = data[:,1]
    
    
    plt.plot(freq,prob,'b.')
    
    xdata = freq
    fdata = prob
    startpoint = [5.014, 0.005, np.ptp(fdata), np.min(fdata)]
    fitfunc = lorentz;
    para, pcov = opt.curve_fit(fitfunc, xdata, fdata, startpoint)
    
    perr = np.sqrt(np.diag(pcov))
    xd = np.linspace(np.min(xdata),np.max(xdata),200)
    l2, = plt.plot(xd, fitfunc(xd, *para), 'b-')
    
    plt.xlabel('Freq (GHz)')
    plt.ylabel('Signal')
    plt.legend([l1,l2],['3 $\mu$s drive on','3 $\mu$s drive off'])
    print(para)
    
    c1 = para[0]
    
    nphoton = 1e3*np.abs(c1-c0)*2*np.pi/(2*chi)
    
    print('photon number is ' + str(nphoton))
    
def plotspectrum_singlePump():
    fname = getsinglefile('178*')
    data = np.loadtxt(fname)
    xdata = np.linspace(5.64609, 5.746, np.size(data))
    plt.figure()
    plt.plot(xdata,data,'r')
    
    fname = getsinglefile('175*')
    data = np.loadtxt(fname)
    xdata = np.linspace(5.64609, 5.746, np.size(data))
    plt.plot(xdata,data,'b')
    
    fname = getsinglefile('180*')
    data = np.loadtxt(fname)
    xdata = np.linspace(5.64609, 5.746, np.size(data))
    plt.plot(xdata,data,'g')
    
    fname = getsinglefile('182*')
    data = np.loadtxt(fname)
    xdata = np.linspace(5.64609, 5.746, np.size(data))
    plt.plot(xdata,data,'k')
    
    plt.xlabel('Frequency (GHz)')
    plt.ylabel('Signal (dB)')
    
    plt.figure()
    
    fname = getsinglefile('178*')
    data = np.loadtxt(fname)
    
    fname = getsinglefile('175*')
    databg = np.loadtxt(fname)
    xdata = np.linspace(5.64609, 5.746, np.size(data))
    plt.plot(xdata,data-databg,'k')
    
    plt.xlabel('Frequency (GHz)')
    plt.ylabel('Signal (dB)')
    
    fname = getsinglefile('179*')
    gain = np.loadtxt(fname)
    freq = np.linspace(5.65,5.75,np.size(gain))
    
    gain = 10**(gain/10)
    T_pa =0.8
    T_pa =0.5
    T_Hemt = 10
    expectNoise = 10 * np.log10( (gain*T_pa+T_Hemt)/(T_Hemt) )
    
    plt.plot(freq, expectNoise, 'r')
    
    
    plt.figure()
    
    fname = getsinglefile('180*')
    data = np.loadtxt(fname)
    
    fname = getsinglefile('178*')
    databg = np.loadtxt(fname)
    xdata = np.linspace(5.64609, 5.746, np.size(data))
    plt.plot(xdata,data-databg,'k')
    
    plt.xlabel('Frequency (GHz)')
    plt.ylabel('Signal (dB)')
    plt.show()
    
    T_th = 0.1 
    gain = 10**(20/10)
    expectThermal = 10 * np.log10( (gain*(T_pa+T_th)+T_Hemt)/(gain*T_pa+T_Hemt) )
    
    print('Expected thermal drive signal:' + str(expectThermal) + ' dB')
    
def autoscale_y(ax,margin=0.05):
    """This function rescales the y-axis based on the data that is visible given the current xlim of the axis.
    ax -- a matplotlib axes object
    margin -- the fraction of the total height of the y-data to pad the upper and lower ylims"""

    import numpy as np

    def get_bottom_top(line):
        xd = line.get_xdata()
        yd = line.get_ydata()
        lo,hi = ax.get_xlim()
        y_displayed = yd[((xd>=lo) & (xd<=hi))]
        h = np.max(y_displayed) - np.min(y_displayed)
        bot = np.min(y_displayed)-margin*h
        top = np.max(y_displayed)+margin*h
        return bot,top

    lines = ax.get_lines()
    bot,top = np.inf, -np.inf

    for line in lines:
        new_bot, new_top = get_bottom_top(line)
        if new_bot < bot: bot = new_bot
        if new_top > top: top = new_top

    ax.set_ylim(bot,top)

class MyError(Exception):
     def __init__(self, value):
         self.value = value
     def __str__(self):
         return repr(self.value)